// nuxt.config.ts
export default defineNuxtConfig({
  app: {
    head: {
      meta: [
        { name: 'viewport', content: 'width=device-width, initial-scale=1' }
      ]
    }
  },
  css: ['@/assets/css/tailwind.css'],
  modules: [
    '@nuxtjs/tailwindcss'
  ],
  tailwindcss: { viewer: false }
})
