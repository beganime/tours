<!-- // Generated from project/aside/aside.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Aside Menu \u2014 Collapsible", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/aside-1.js", "defer": true}] });
</script>

<template>
  <div>
<div class="min-h-screen flex">
        <!-- ASIDE -->
        <aside class="w-[280px] shrink-0 border-r border-[color:var(--border)] bg-white">
            <div class="px-4 py-6">
                <nav class="space-y-2">
                    <!-- Личный кабинет -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[color:var(--ink)] hover:bg-slate-50 transition">
                        <!-- heroicon: user -->
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
                        </svg>
                        <span class="font-medium">Личный кабинет</span>
                    </NuxtLink>
                    <!-- Центр уведомлений -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[color:var(--ink)] hover:bg-slate-50 transition">
                        <!-- heroicon: bell -->
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M14.857 17.082a23.848 23.848 0 0 0 5.454-1.31A8.967 8.967 0 0 1 18 9.75V9A6 6 0 0 0 6 9v.75a8.967 8.967 0 0 1-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 0 1-5.714 0m5.714 0a3 3 0 1 1-5.714 0" />
                        </svg>
                        <span class="font-medium">Центр уведомлений</span>
                    </NuxtLink>
                    <!-- Мои туры -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg text-[color:var(--ink)] hover:bg-slate-50 transition">
                        <!-- heroicon: clock -->
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
                        </svg>
                        <span class="font-medium">Мои туры</span>
                    </NuxtLink>
                    <!-- Заказы (collapsible) -->
                    <div class="rounded-lg">
                        <button type="button" class="w-full flex items-center justify-between gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 transition" data-collapse-btn aria-expanded="true" aria-controls="orders-sub">
                            <span class="flex items-center gap-3">
                                <!-- heroicon: clipboard-document-list -->
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5" />
                                </svg>
                                <span class="font-medium">Заказы</span>
                            </span>
                            <!-- chevron -->
                            <svg class="h-5 w-5 text-slate-400 transition-transform" data-chevron fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m6 9 6 6 6-6" />
                            </svg>
                        </button>
                        <div id="orders-sub" class="mt-1 pl-11 space-y-1">
                            <a href="#" class="block px-3 py-[6px] rounded-md text-[color:var(--primary)] bg-[color:var(--primary-50)] font-medium">
                                Заявки на бронирования
                            </NuxtLink>
                            <a href="#" class="block px-3 py-[6px] rounded-md text-slate-600 hover:bg-slate-50">
                                Оплаты
                            </NuxtLink>
                            <a href="#" class="block px-3 py-[6px] rounded-md text-slate-600 hover:bg-slate-50">
                                Путешественники
                            </NuxtLink>
                            <a href="#" class="block px-3 py-[6px] rounded-md text-slate-600 hover:bg-slate-50">
                                Урегулирование
                            </NuxtLink>
                        </div>
                    </div>
                    <!-- Мои отзывы -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 transition">
                        <!-- heroicon: chat-bubble-left-right -->
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 17.25v1.007a3 3 0 0 1-.879 2.122L7.5 21h9l-.621-.621A3 3 0 0 1 15 18.257V17.25m6-12V15a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 15V5.25m18 0A2.25 2.25 0 0 0 18.75 3H5.25A2.25 2.25 0 0 0 3 5.25m18 0V12a2.25 2.25 0 0 1-2.25 2.25H5.25A2.25 2.25 0 0 1 3 12V5.25" />
                        </svg>
                        <span class="font-medium">Мои отзывы</span>
                    </NuxtLink>
                    <!-- Счета и Платежи (collapsible) -->
                    <div class="rounded-lg">
                        <button type="button" class="w-full flex items-center justify-between gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 transition" data-collapse-btn aria-expanded="false" aria-controls="billing-sub">
                            <span class="flex items-center gap-3">
                                <!-- heroicon: credit-card -->
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 0 0 2.25-2.25V6.75A2.25 2.25 0 0 0 19.5 4.5h-15a2.25 2.25 0 0 0-2.25 2.25v10.5A2.25 2.25 0 0 0 4.5 19.5Z" />
                                </svg>
                                <span class="font-medium">Счета и Платежи</span>
                            </span>
                            <svg class="h-5 w-5 text-slate-400 transition-transform" data-chevron fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                                <path stroke-linecap="round" stroke-linejoin="round" d="m6 9 6 6 6-6" />
                            </svg>
                        </button>
                        <div id="billing-sub" class="hidden mt-1 pl-11 space-y-1">
                            <a href="#" class="block px-3 py-[6px] rounded-md text-slate-600 hover:bg-slate-50">Счета</NuxtLink>
                            <a href="#" class="block px-3 py-[6px] rounded-md text-slate-600 hover:bg-slate-50">Платежи</NuxtLink>
                        </div>
                    </div>
                    <!-- Заказать продвижение -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 transition">
                        <!-- heroicon: megaphone -->
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875 0 1 1 2.652 2.652L10.582 16.07a4.5 4.5 0 0 1-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 0 1 1.13-1.897l8.932-8.931Zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0 1 15.75 21H5.25A2.25 2.25 0 0 1 3 18.75V8.25A2.25 2.25 0 0 1 5.25 6H10" />
                        </svg>
                        <span class="font-medium">Заказать продвижение</span>
                    </NuxtLink>
                    <!-- Интеграции -->
                    <a href="#" class="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-slate-50 transition">
                        <!-- heroicon: puzzle-piece -->
                        <svg class="h-5 w-5 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 3.75a2.25 2.25 0 0 0-4.5 0V6H5.25A2.25 2.25 0 0 0 3 8.25V9a2.25 2.25 0 0 0 2.25 2.25H7.5V15H5.25A2.25 2.25 0 0 0 3 17.25V18a2.25 2.25 0 0 0 2.25 2.25H6v2.25a2.25 2.25 0 0 0 4.5 0V20.25h2.25A2.25 2.25 0 0 0 15 18v-.75A2.25 2.25 0 0 0 12.75 15H10.5v-3.75h2.25A2.25 2.25 0 0 0 15 9V8.25A2.25 2.25 0 0 0 12.75 6H10.5V3.75Z" />
                        </svg>
                        <span class="font-medium">Интеграции</span>
                    </NuxtLink>
                </nav>
            </div>
            <!-- Card -->
            <div class="w-full max-w-sm bg-white rounded-xl shadow-[0_6px_22px_rgba(20,28,38,.08)] border border-gray-100">
                <ul class="p-4 space-y-3">
                    <!-- Facebook -->
                    <li>
                        <a href="#" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                            <!-- fb icon -->
                            <span aria-hidden="true" class="inline-flex w-9 h-9 rounded-full bg-[#1877F2] text-white items-center justify-center">
                                <span class="sr-only">Facebook</span>
                                <span class="text-lg leading-none font-bold -mt-[1px]">f</span>
                            </span>
                            <div class="leading-tight">
                                <div class="text-sm font-medium text-gray-900">Facebook</div>
                                <div class="text-xs text-gray-500">Подключить</div>
                            </div>
                        </NuxtLink>
                    </li>
                    <!-- Google -->
                    <li>
                        <a href="#" class="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition">
                            <!-- google G (многоцветный SVG) -->
                            <span aria-hidden="true" class="inline-flex w-9 h-9 rounded-full items-center justify-center bg-white border border-gray-200">
                                <svg width="20" height="20" viewBox="0 0 48 48" aria-hidden="true">
                                    <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.6 32.8 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.7 1.1 7.7 3l5.7-5.7C33.7 5.7 29.1 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20c10 0 19-7.3 19-20 0-1.2-.1-2.3-.4-3.5z" />
                                    <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.2 16.3 18.7 12 24 12c3 0 5.7 1.1 7.7 3l5.7-5.7C33.7 5.7 29.1 4 24 4 16 4 9.2 8.5 6.3 14.7z" />
                                    <path fill="#4CAF50" d="M24 44c5.2 0 9.9-1.7 13.5-4.7l-6.2-5.1c-2 1.4-4.6 2.3-7.3 2.3-5.2 0-9.6-3.5-11.2-8.2l-6.6 5.1C9 39.6 15.9 44 24 44z" />
                                    <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-1 3-3.2 5.1-6 6.2l6.2 5.1C38.4 36.7 44 32 44 24c0-1.2-.1-2.3-.4-3.5z" />
                                </svg>
                            </span>
                            <div class="leading-tight">
                                <div class="text-sm font-medium text-gray-900">Google</div>
                                <div class="text-xs text-gray-500">Подключить</div>
                            </div>
                        </NuxtLink>
                    </li>
                </ul>
            </div>
        </aside>
        <!-- DEMO CONTENT -->
        <main class="flex-1 p-10 bg-slate-50">
            <div class="max-w-3xl mx-auto">
                <h1 class="text-2xl font-semibold mb-2">Контент</h1>
                <p class="text-slate-600">
                    Это демонстрационная область. Слева — сайдбар с раскрывающимися разделами, цвета и активное состояние
                    совпадают со скрином: активный подпункт имеет синий текст и мягкий голубой фон.
                </p>
            </div>
        </main>
    </div>
    <!-- Мини-скрипт для открытия/закрытия как на скрине -->
  </div>
</template>
