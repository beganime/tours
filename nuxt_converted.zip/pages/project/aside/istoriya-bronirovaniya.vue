<!-- // Generated from project/aside/istoriya-bronirovaniya.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0418\u0441\u0442\u043e\u0440\u0438\u044f \u0431\u0440\u043e\u043d\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u2014 \u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Компонент -->
    <section class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h2 class="text-xl sm:text-2xl font-extrabold text-[#6f3bd2]">
            История бронирования
        </h2>
        <div class="mt-8 flex justify-center">
            <p class="text-xs sm:text-sm uppercase tracking-[0.3em] text-gray-400">
                У ВАС НЕТ АКТИВНЫХ ЗАЯВОК
            </p>
        </div>
    </section>
  </div>
</template>
