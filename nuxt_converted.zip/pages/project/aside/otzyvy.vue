<!-- // Generated from project/aside/otzyvy.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Otzyvy", link: [], script: [] });
</script>

<template>
  <div>

  </div>
</template>
