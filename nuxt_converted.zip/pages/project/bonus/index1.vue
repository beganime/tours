<!-- // Generated from project/bonus/index1.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a \u043e\u043f\u043b\u0430\u0442\u0438\u0442\u044c \u043f\u0443\u0442\u0435\u0448\u0435\u0441\u0442\u0432\u0438\u0435 \u0431\u043e\u043d\u0443\u0441\u0430\u043c\u0438? \u2014 \u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <div class="bg-white rounded-2xl shadow-[var(--cardshadow)] ring-1 ring-gray-100 p-5 sm:p-6">
            <h2 class="text-[22px] sm:text-[24px] font-extrabold mb-3">
                Как оплатить путешествие бонусами?
            </h2>
            <ul class="space-y-3 sm:space-y-3.5 mt-2">
                <!-- item -->
                <li class="flex items-start gap-3">
                    <!-- Иконка из сервиса (Heroicons) -->
                    <span class="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full" style="background:var(--green-50); border:1px solid var(--border); color:var(--green);">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                    </span>
                    <p class="text-[15px] text-[var(--muted)]">
                        При расчёте стоимости тура вы увидите, сколько бонусов на вашем счёте
                    </p>
                </li>
                <!-- item -->
                <li class="flex items-start gap-3">
                    <span class="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full" style="background:var(--green-50); border:1px solid var(--border); color:var(--green);">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                    </span>
                    <p class="text-[15px] text-[var(--muted)]">
                        Вы сами решаете, списывать бонусы или продолжать копить
                    </p>
                </li>
                <!-- item -->
                <li class="flex items-start gap-3">
                    <span class="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full" style="background:var(--green-50); border:1px solid var(--border); color:var(--green);">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                    </span>
                    <p class="text-[15px] text-[var(--muted)]">
                        Вы можете оплатить бонусами не более 10% от общей суммы
                    </p>
                </li>
                <!-- item -->
                <li class="flex items-start gap-3">
                    <span class="mt-0.5 inline-flex items-center justify-center w-5 h-5 rounded-full" style="background:var(--green-50); border:1px solid var(--border); color:var(--green);">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                    </span>
                    <p class="text-[15px] text-[var(--muted)]">
                        Бонусы хранятся 1 год с момента начисления
                    </p>
                </li>
            </ul>
        </div>
    </section>
  </div>
</template>
