<!-- // Generated from project/career/index2.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "WeRoad \u2014 Text Block", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="bg-[#151515] text-white">
    
    <section class="py-10 md:py-20">
    <div class="mx-auto px-4 md:px-8 max-w-[1120px]">
        <!-- Small intro text -->
        <p class="text-[15px] md:text-[16px] leading-relaxed text-[#cfcfcf] md:max-w-[980px]">
            We are a team of over 200 talented individuals from diverse backgrounds all united by our passion for
            travel, cultures and connecting people! And guess what – we’re just getting started!
        </p>
        <!-- Big headline -->
        <h1 class="mt-5 md:mt-8 font-extrabold tracking-[-0.015em] leading-[1.1]
                 text-[28px] md:text-[44px] md:max-w-[1000px]">
            We are building an incredible team that is
            revolutionising the way millennials discover the
            world.<br class="block" />
            Come and join the adventure!
        </h1>
        <!-- Bottom paragraph -->
        <p class="mt-6 md:mt-8 text-[15px] md:text-[16px] leading-relaxed text-[#b8b8b8] md:max-w-[980px]">
            Not enough experience? No problem! Here at WeRoad we value potential, talent, and culture fit over
            what’s on your CV. So if you love to travel and are ready for the job of a lifetime, apply now and
            join our team in Milan, Madrid, London, Paris or Berlin!
        </p>
    </div>
</section>
  </section>
    <!-- Mobile spacing tuning (keeps desktop unchanged) -->
    <style>
    @media (max-width: 767px) {

        /* match tight mobile look from screenshots */
        h1 {
            word-spacing: 1px;
        }

        p {
            word-spacing: 0.2px;
        }
    }
    </style>
  </div>
</template>
