<!-- // Generated from project/career/index3.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Job Openings \u2014 Replica", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/index3-1.js", "defer": true}] });
</script>

<template>
  <div>
<section class="bg-white">
		
   <main class="max-w-4xl mx-auto px-5 md:px-6 lg:px-8 py-8 md:py-12">
    <!-- Header row -->
    <div class="flex flex-col md:flex-row  items-start md:items-center justify-between gap-4">
        <h1 class="text-[28px] md:text-[34px] lg:text-[38px] font-extrabold leading-tight">Job Openings</h1>
        <!-- Filters -->
        <!-- Mobile: две кнопки рядом (как на 3-м скрине). Десктоп: справа от заголовка -->
        <div class="w-full sm:w-auto grid grid-cols-2 gap-2 sm:grid-cols-2 sm:gap-2 md:grid-cols-2 md:gap-2 lg:grid-cols-2 ">
            <!-- Teams -->
            <div class="relative" data-dropdown="teams">
                <button class="menu-btn w-full sm:w-[180px]" data-btn="teams">
                    <span>All Teams</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="6 9 12 15 18 9" /></svg>
                </button>
                <div class="menu absolute right-0 mt-2 hidden z-20" data-menu="teams">
                    <a href="#" data-value="all">All Teams</NuxtLink>
                    <a href="#" data-value="ABC (Company)">ABC (Company)</NuxtLink>
                    <a href="#" data-value="Ambassador & Community">Ambassador & Community</NuxtLink>
                    <a href="#" data-value="Commercial">Commercial</NuxtLink>
                    <a href="#" data-value="Finance">Finance</NuxtLink>
                    <a href="#" data-value="Growth">Growth</NuxtLink>
                    <a href="#" data-value="Marketing">Marketing</NuxtLink>
                    <a href="#" data-value="People">People</NuxtLink>
                    <a href="#" data-value="Tech&Product (aka Monkeys)">Tech&Product (aka Monkeys)</NuxtLink>
                    <a href="#" data-value="Tour Operator">Tour Operator</NuxtLink>
                    <a href="#" data-value="WeRoad X">WeRoad X</NuxtLink>
                </div>
            </div>
            <!-- Locations -->
            <div class="relative" data-dropdown="locations">
                <button class="menu-btn w-full sm:w-[180px]" data-btn="locations">
                    <span>All locations</span>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                        <polyline points="6 9 12 15 18 9" /></svg>
                </button>
                <div class="menu absolute right-0 mt-2 hidden z-20" data-menu="locations">
                    <a href="#" data-value="all">All locations</NuxtLink>
                    <a href="#" data-value="Amsterdam">Amsterdam</NuxtLink>
                    <a href="#" data-value="Around the World">Around the World</NuxtLink>
                    <a href="#" data-value="Barcelona">Barcelona</NuxtLink>
                    <a href="#" data-value="Berlin">Berlin</NuxtLink>
                    <a href="#" data-value="Chiasso">Chiasso</NuxtLink>
                    <a href="#" data-value="Full Remote">Full Remote</NuxtLink>
                    <a href="#" data-value="London">London</NuxtLink>
                    <a href="#" data-value="Madrid">Madrid</NuxtLink>
                    <a href="#" data-value="Manchester">Manchester</NuxtLink>
                    <a href="#" data-value="Milan">Milan</NuxtLink>
                    <a href="#" data-value="Munich">Munich</NuxtLink>
                    <a href="#" data-value="Paris">Paris</NuxtLink>
                </div>
            </div>
        </div>
    </div>
    <!-- List -->
    <section id="jobs" class="mt-4 md:mt-6">
        <!-- каждая строка = вакансия -->
        <div class="job" data-team="Commercial" data-location="Milan">
            <a href="#">
                <h3>Customer Care Assistant</h3>
                <p>Commercial · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Commercial" data-location="London">
            <a href="#">
                <h3>Sales &amp; Customer Care Manager</h3>
                <p>Commercial · London</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Finance" data-location="Milan">
            <a href="#">
                <h3>Senior Accountant</h3>
                <p>Finance · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Tech&Product (aka Monkeys)" data-location="Full Remote">
            <a href="#">
                <h3>Senior Full Stack Engineer</h3>
                <p>Tech&amp;Product (aka Monkeys) · Full Remote</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Commercial" data-location="Paris">
            <a href="#">
                <h3>Customer Care Assistant (Alternance)</h3>
                <p>Commercial · Paris</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Tech&Product (aka Monkeys)" data-location="Milan">
            <a href="#">
                <h3>Staff Full Stack Engineer</h3>
                <p>Tech&amp;Product (aka Monkeys) · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="People" data-location="Milan">
            <a href="#">
                <h3>AI Native Builder (People)</h3>
                <p>People · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Commercial" data-location="Milan">
            <a href="#">
                <h3>Sales Specialist</h3>
                <p>Commercial · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Commercial" data-location="Paris">
            <a href="#">
                <h3>Business Development Manager – FRANCE area</h3>
                <p>Commercial · Paris</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Commercial" data-location="Berlin">
            <a href="#">
                <h3>Business Development Manager – DACH area</h3>
                <p>Commercial · Berlin</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Finance" data-location="Milan">
            <a href="#">
                <h3>Treasury Manager</h3>
                <p>Finance · Milan</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Marketing" data-location="Berlin">
            <a href="#">
                <h3>Intern / Working Student Marketing &amp; Event</h3>
                <p>Marketing · Berlin</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Ambassador & Community" data-location="Around the World">
            <a href="#">
                <h3>Travel Coordinator – DACH Community</h3>
                <p>Ambassador &amp; Community · Around the World</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Ambassador & Community" data-location="Around the World">
            <a href="#">
                <h3>Travel Coordinator – French Community</h3>
                <p>Ambassador &amp; Community · Around the World</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Ambassador & Community" data-location="Around the World">
            <a href="#">
                <h3>Travel Coordinator – World English Community</h3>
                <p>Ambassador &amp; Community · Around the World</p>
            </NuxtLink>
        </div>
        <div class="job" data-team="Ambassador & Community" data-location="Around the World">
            <a href="#">
                <h3>Travel Coordinator | Italian Community</h3>
                <p>Ambassador &amp; Community · Around the World</p>
            </NuxtLink>
        </div>
    </section>
</main>
	</section>
  </div>
</template>
