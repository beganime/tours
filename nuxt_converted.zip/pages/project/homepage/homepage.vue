<!-- // Generated from project/homepage/homepage.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Document", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/homepage-1.js", "defer": true}] });
</script>

<template>
  <div>
<section class='flex flex-col items-center justify-center pb-12'>
        <h2 class='mb-10 text-3xl font-extrabold text-gray-900'>Don’t know where to start? Our best sellers are always a good idea.</h2>
        <div class="flex flex-wrap justify-center gap-6">
            <!-- Card 1 -->
            <div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80" alt="Italy coast" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                    <div class="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-lg flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.233 3.787a1 1 0 00.95.69h3.992c.969 0 1.371 1.24.588 1.81l-3.232 2.35a1 1 0 00-.364 1.118l1.233 3.787c.3.921-.755 1.688-1.54 1.118l-3.232-2.35a1 1 0 00-1.176 0l-3.232 2.35c-.785.57-1.84-.197-1.54-1.118l1.233-3.787a1 1 0 00-.364-1.118L2.28 9.214c-.783-.57-.38-1.81.588-1.81h3.992a1 1 0 00.95-.69l1.233-3.787z" />
                        </svg>
                        4.7
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-gray-900 text-base mb-1">
                        Italy Express: Naples and the Amalfi Coast
                    </h3>
                    <p class="text-sm text-gray-700">
                        From <span class="text-green-600 font-semibold">$637</span>
                        <span class="line-through text-gray-400 ml-1">$696</span>
                        <span class="text-green-600 font-semibold ml-1">-8%</span>
                    </p>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80" alt="Matterhorn" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-gray-900 text-base mb-1">
                        Matterhorn: snow adventures in Cervinia and Zermatt
                    </h3>
                    <p class="text-sm text-gray-700">
                        From <span class="text-gray-900 font-semibold">$1,118</span>
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="hero">
        <!-- Верхний блок с текстом -->
        <div class="bg-[#eaf4fb] pt-10 pb-4 relative z-10">
            <h2 class="text-2xl md:text-3xl font-extrabold text-gray-900 mb-1">
                Seasons in motion
            </h2>
            <p class="text-gray-600 text-sm md:text-base">
                Adventure through changing seasons, with new friends by your side.
            </p>
        </div>
        <!-- Фото с мягким переходом -->
        <div class="hero-image"></div>
    </section>
    <section class='flex flex-col items-center justify-center pb-12 bg-black'>
        <div class="flex flex-wrap justify-center gap-6">
            <!-- Card 1 -->
            <div class="w-72 bg-black rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80" alt="Italy coast" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                    <div class="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-lg flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.233 3.787a1 1 0 00.95.69h3.992c.969 0 1.371 1.24.588 1.81l-3.232 2.35a1 1 0 00-.364 1.118l1.233 3.787c.3.921-.755 1.688-1.54 1.118l-3.232-2.35a1 1 0 00-1.176 0l-3.232 2.35c-.785.57-1.84-.197-1.54-1.118l1.233-3.787a1 1 0 00-.364-1.118L2.28 9.214c-.783-.57-.38-1.81.588-1.81h3.992a1 1 0 00.95-.69l1.233-3.787z" />
                        </svg>
                        4.7
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-white text-base mb-1">
                        Italy Express: Naples and the Amalfi Coast
                    </h3>
                    <p class="text-sm text-white">
                        From <span class="text-green-600 font-semibold">$637</span>
                        <span class="line-through text-gray-400 ml-1">$696</span>
                        <span class="text-green-600 font-semibold ml-1">-8%</span>
                    </p>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="w-72 bg-black rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80" alt="Matterhorn" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-white text-base mb-1">
                        Matterhorn: snow adventures in Cervinia and Zermatt
                    </h3>
                    <p class="text-sm text-white">
                        From <span class="text-gray-500 font-semibold">$1,118</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="mt-10">
            <a href="#" class="inline-flex  items-center justify-center rounded-md bg-white  px-7 py-3 text-blue-500 font-semibold shadow-sm
		                hover:bg-blue-600 hover:text-white transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                See trips here
            </NuxtLink>
        </div>
    </section>
    <section class="heroo">
        <!-- Верхняя текстовая часть -->
        <div class="bg-[#f9f4df] pt-10 pb-4 relative z-10">
            <h2 class="text-2xl md:text-3xl font-extrabold text-gray-900 mb-1">
                Winter warmers
            </h2>
            <p class="text-gray-600 text-sm md:text-base max-w-2xl mx-auto">
                Follow the sun to unforgettable adventures, and meet new friends along the way.
            </p>
        </div>
        <!-- Фото с плавным переходом -->
        <div class="heroo-image"></div>
    </section>
    <section class='flex flex-col items-center justify-center pb-12 bg-black'>
        <div class="flex flex-wrap justify-center gap-6">
            <!-- Card 1 -->
            <div class="w-72 bg-black rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80" alt="Italy coast" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                    <div class="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-lg flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.233 3.787a1 1 0 00.95.69h3.992c.969 0 1.371 1.24.588 1.81l-3.232 2.35a1 1 0 00-.364 1.118l1.233 3.787c.3.921-.755 1.688-1.54 1.118l-3.232-2.35a1 1 0 00-1.176 0l-3.232 2.35c-.785.57-1.84-.197-1.54-1.118l1.233-3.787a1 1 0 00-.364-1.118L2.28 9.214c-.783-.57-.38-1.81.588-1.81h3.992a1 1 0 00.95-.69l1.233-3.787z" />
                        </svg>
                        4.7
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-white text-base mb-1">
                        Italy Express: Naples and the Amalfi Coast
                    </h3>
                    <p class="text-sm text-white">
                        From <span class="text-green-600 font-semibold">$637</span>
                        <span class="line-through text-gray-400 ml-1">$696</span>
                        <span class="text-green-600 font-semibold ml-1">-8%</span>
                    </p>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="w-72 bg-black rounded-xl shadow-md overflow-hidden relative">
                <div class="relative">
                    <img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80" alt="Matterhorn" class="w-full h-48 object-cover">
                    <button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
                        </svg>
                    </button>
                    <div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-white text-base mb-1">
                        Matterhorn: snow adventures in Cervinia and Zermatt
                    </h3>
                    <p class="text-sm text-white">
                        From <span class="text-gray-500 font-semibold">$1,118</span>
                    </p>
                </div>
            </div>
        </div>
        <div class="mt-10">
            <a href="#" class="inline-flex  items-center justify-center rounded-md bg-white  px-7 py-3 text-blue-500 font-semibold shadow-sm
		                hover:bg-blue-600 hover:text-white transition focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-400">
                See itineraries
            </NuxtLink>
        </div>
    </section>
    <section class="flex items-center justify-center min-h-screen p-6">
        <div class="grid grid-cols-2 lg:grid-cols-4 gap-3 max-w-6xl w-full">
            <!-- LEFT BIG -->
            <div class="relative card rounded-xl overflow-hidden lg:col-span-1 lg:row-span-2">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/69001/.webp" class="w-full h-full object-cover" alt="Last minute deals">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-5 text-white">
                    <h3 class="font-bold text-lg md:text-xl mb-1">Last minute deals</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90 w-[90%]">Need to escape? Check out last minute deals here!</p>
                        <button class="arrow-btn w-8 h-8 flex items-center justify-center rounded-md text-lg ml-2">›</button>
                    </div>
                </div>
            </div>
            <!-- MIDDLE TALL -->
            <div class="relative card rounded-xl overflow-hidden lg:row-span-2">
                <img src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&w=900&q=80" class="w-full h-full object-cover" alt="Northern Lights">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-5 text-white">
                    <h3 class="font-bold text-lg md:text-xl mb-1">Northern Lights</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90">Chase the lights</p>
                        <button class="arrow-btn w-8 h-8 flex items-center justify-center rounded-md text-lg ml-2">›</button>
                    </div>
                </div>
            </div>
            <!-- RIGHT TOP -->
            <div class="relative card rounded-xl overflow-hidden lg:col-span-1">
                <img src="https://images.unsplash.com/photo-1513875528452-39400945934d?auto=format&fit=crop&w=900&q=80" class="w-full h-full object-cover" alt="Christmas">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-5 text-white">
                    <h3 class="font-bold text-lg md:text-xl mb-1">Christmas & New Year's Eve</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90">Celebrate & travel</p>
                        <button class="arrow-btn w-8 h-8 flex items-center justify-center rounded-md text-lg ml-2">›</button>
                    </div>
                </div>
            </div>
            <!-- BOTTOM LEFT SMALL -->
            <div class="relative card rounded-xl overflow-hidden">
                <img src="https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=900&q=80" class="w-full h-52 object-cover" alt="Ski itineraries">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-4 text-white">
                    <h3 class="font-bold text-lg mb-1">Ski itineraries</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90">Let's hit the slopes</p>
                        <button class="arrow-btn w-7 h-7 flex items-center justify-center rounded-md text-base ml-2">›</button>
                    </div>
                </div>
            </div>
            <!-- BOTTOM CENTER SMALL -->
            <div class="relative card rounded-xl overflow-hidden">
                <img src="https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=900&q=80" class="w-full h-52 object-cover" alt="Trekking season">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-4 text-white">
                    <h3 class="font-bold text-lg mb-1">Trekking season</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90">Step into adventure</p>
                        <button class="arrow-btn w-7 h-7 flex items-center justify-center rounded-md text-base ml-2">›</button>
                    </div>
                </div>
            </div>
            <!-- BOTTOM RIGHT SMALL -->
            <div class="relative card rounded-xl overflow-hidden">
                <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=900&q=80" class="w-full h-52 object-cover" alt="New to WeRoad">
                <div class="absolute inset-0 overlay flex flex-col justify-end p-4 text-white">
                    <h3 class="font-bold text-lg mb-1">New to WeRoad?</h3>
                    <div class="flex items-center justify-between">
                        <p class="text-sm opacity-90">How it works</p>
                        <button class="arrow-btn w-7 h-7 flex items-center justify-center rounded-md text-base ml-2">›</button>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center min-h-screen p-4">
        <section class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl w-full">
            <!-- WHO -->
            <div class="bg-[#d8efff] rounded-2xl overflow-hidden shadow-sm text-center flex flex-col">
                <div class="p-6 flex flex-col items-center flex-grow">
                    <span class="text-xs font-bold uppercase bg-gray-900 text-white px-2 py-1 rounded mb-2 tracking-wider">
                        Who?
                    </span>
                    <h3 class="text-xl font-extrabold mb-2">A community</h3>
                    <p class="text-gray-800 text-sm leading-relaxed">
                        Meet new friends by travelling in small groups with people like you
                        (always accompanied by a Coordinator!) and become part of the largest
                        travel community in Europe.
                    </p>
                </div>
                <img src="https://cdn.weroad.io/common/images/company-values/jpg/friends.jpg" alt="Group of friends jumping" class="w-full h-48 object-cover">
            </div>
            <!-- WHAT -->
            <div class="bg-[#ffe9d9] rounded-2xl overflow-hidden shadow-sm text-center flex flex-col">
                <div class="p-6 flex flex-col items-center flex-grow">
                    <span class="text-xs font-bold uppercase bg-gray-900 text-white px-2 py-1 rounded mb-2 tracking-wider">
                        What?
                    </span>
                    <h3 class="text-xl font-extrabold mb-2">Endless trips</h3>
                    <p class="text-gray-800 text-sm leading-relaxed">
                        Live unique experiences in more than 100 countries around the world.
                        Choose the right mood for you be it an event lasting a few hours,
                        a weekend away, a themed trip or a 360° trip to discover a distant place and new culture.
                    </p>
                </div>
                <img src="https://cdn.weroad.io/common/images/company-values/jpg/coordinator.jpg" alt="Coordinator sunset" class="w-full h-48 object-cover">
            </div>
            <!-- HOW -->
            <div class="bg-[#ffe4ef] rounded-2xl overflow-hidden shadow-sm text-center flex flex-col">
                <div class="p-6 flex flex-col items-center flex-grow">
                    <span class="text-xs font-bold uppercase bg-gray-900 text-white px-2 py-1 rounded mb-2 tracking-wider">
                        How?
                    </span>
                    <h3 class="text-xl font-extrabold mb-2">Super flexible</h3>
                    <p class="text-gray-800 text-sm leading-relaxed">
                        You can secure your spot with a deposit and change your mind free of charge up to 31 days before departure,
                        or up to 8 if you add Flexible Cancellation. Medical and baggage insurance is always included,
                        so you can travel worry-free.
                    </p>
                </div>
                <img src="https://cdn.weroad.io/common/images/company-values/jpg/adventure.jpg" alt="People exploring ancient ruins" class="w-full h-48 object-cover">
            </div>
        </section>
    </section>
    <section class="flex flex-col items-center justify-center min-h-screen px-4 py-12 bg-[#0d0d0d] text-white">
        <h2 class="text-2xl md:text-3xl font-extrabold text-center mb-10">
            What happens on a WeRoad trip?
        </h2>
        <!-- Cards container -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 max-w-6xl w-full">
            <!-- Card 1 -->
            <div class="relative rounded-xl overflow-hidden group min-h-[480px]">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/151178/diving-cenote-mexico.webp" alt="Diving into a cenote" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div class="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-4">
                    <h3 class="font-bold text-white text-sm sm:text-base">Diving into a cenote</h3>
                    <p class="text-xs text-gray-200 flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8 0a5.53 5.53 0 0 0-5.5 5.5C2.5 9.875 8 16 8 16s5.5-6.125 5.5-10.5A5.53 5.53 0 0 0 8 0zM8 7.5A2 2 0 1 1 8 3.5a2 2 0 0 1 0 4z" />
                        </svg>
                        Mexico
                    </p>
                </div>
            </div>
            <!-- Card 2 -->
            <div class="relative rounded-xl overflow-hidden group min-h-[480px]">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/216179/peru-trekking.webp" alt="Trekking at 5,000 metres" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 " />
                <div class="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-4">
                    <h3 class="font-bold text-white text-sm sm:text-base">Trekking at 5,000 metres!</h3>
                    <p class="text-xs text-gray-200 flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8 0a5.53 5.53 0 0 0-5.5 5.5C2.5 9.875 8 16 8 16s5.5-6.125 5.5-10.5A5.53 5.53 0 0 0 8 0zM8 7.5A2 2 0 1 1 8 3.5a2 2 0 0 1 0 4z" />
                        </svg>
                        Valle Rojo, Peru
                    </p>
                </div>
            </div>
            <!-- Card 3 -->
            <div class="relative rounded-xl overflow-hidden group min-h-[480px]">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/243210/snorkeling-gili-islands.webp" alt="Snorkelling adventures" class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div class="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-4">
                    <h3 class="font-bold text-white text-sm sm:text-base">Snorkelling adventures!</h3>
                    <p class="text-xs text-gray-200 flex items-center gap-1">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 16 16">
                            <path d="M8 0a5.53 5.53 0 0 0-5.5 5.5C2.5 9.875 8 16 8 16s5.5-6.125 5.5-10.5A5.53 5.53 0 0 0 8 0zM8 7.5A2 2 0 1 1 8 3.5a2 2 0 0 1 0 4z" />
                        </svg>
                        Gili Islands, Indonesia
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center py-20 bg-white">
        <div class="flex items-center flex-col md:flex-row space-x-2 text-sm text-gray-800">
            <span>Our customers say</span>
            <span class="font-semibold">Excellent</span>
            <!-- Dynamic Stars -->
            <div id="stars" class="flex items-center space-x-0.5"></div>
            <span id="ratingText" class="text-gray-700 font-semibold"></span>
            <span class="text-gray-500">out of 5 based on</span>
            <span class="font-semibold text-gray-800">901</span>
            <span class="text-gray-500">reviews</span>
            <!-- Trustpilot logo -->
            <div class="flex items-center space-x-1 pl-1">
                <svg xmlns="http://www.w3.org/2000/svg" fill="#00B67A" viewBox="0 0 24 24" class="w-4 h-4">
                    <path d="M12 .587l3.668 7.431 8.2 1.193-5.934 5.784 1.402 8.175L12 18.896l-7.336 3.864 1.402-8.175L.132 9.211l8.2-1.193z" />
                </svg>
                <span class="font-semibold text-gray-900">Trustpilot</span>
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center">
        <div class="relative w-full max-w-5xl rounded-xl overflow-hidden shadow-lg">
            <!-- Background image -->
            <img src="https://cdn.weroad.io/common/images/company-values/jpg/friends.jpg" alt="Travel community" class="w-full h-[420px] object-cover">
            <!-- Overlay -->
            <div class="absolute inset-0 bg-black/30"></div>
            <!-- Text content -->
            <div class="absolute inset-0 flex flex-col items-center  text-center px-6">
                <h2 class="text-2xl md:text-3xl font-extrabold text-white mt-10 mb-2">
                    Join our travel community!
                </h2>
                <p class="text-gray-200 mb-5">
                    Meet fellow travellers and connect before you fly!
                </p>
                <a href="#" class="bg-red-500 hover:bg-red-600 text-white font-semibold text-sm px-6 py-3 rounded">
                    Click here to join our Facebook community group!
                </NuxtLink>
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center py-10 my-5 bg-[#0e0e0e]">
        <section class="w-full py-12 px-4 text-center text-white bg-[#0e0e0e]">
            <h2 class="text-2xl md:text-3xl font-extrabold mb-2">Our partners</h2>
            <p class="text-gray-400 mb-8 text-sm md:text-base">We are proudly partner with</p>
            <div class="flex flex-wrap justify-center items-center gap-8 md:gap-16">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/118073/.webp" alt="Partner 1" class="h-6 md:h-8 object-contain">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/217238/.webp" alt="Partner 2" class="h-6 md:h-8 object-contain">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/118191/.webp" alt="Partner 3" class="h-6 md:h-8 object-contain">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/237863/.webp" alt="Partner 4" class="h-6 md:h-8 object-contain">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/237864/.webp" alt="Partner 5" class="h-6 md:h-8 object-contain">
            </div>
        </section>
    </section>
    <section class="bg-white flex items-center justify-center py-5 my-5 px-4">
        <section class="w-full max-w-6xl mx-auto py-10">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
                <!-- Guardian -->
                <div>
                    <p class="text-2xl mb-3">“</p>
                    <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                        10 of the best group trips<br>for solo travellers
                    </p>
                    <div class="mt-3">
                        <img src="https://strapi-imaginary.weroad.it/resource/webp-small/89116/.webp" alt="The Guardian" class="mx-auto h-8 md:h-10 object-contain">
                    </div>
                </div>
                <!-- Skift -->
                <div>
                    <p class="text-2xl mb-3">“</p>
                    <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                        WeRoad is capitalising on<br>
                        Millennials' affinity for<br>
                        adventure and travel by<br>
                        catering to their desire<br>
                        for exploration and social<br>
                        connection
                    </p>
                    <div class="mt-3">
                        <img src="https://strapi-imaginary.weroad.it/resource/webp-small/87445/.webp" alt="Skift" class="mx-auto h-8 md:h-10 object-contain">
                    </div>
                </div>
                <!-- Daily Mirror -->
                <div>
                    <p class="text-2xl mb-3">“</p>
                    <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                        I quit my job at age 42 to<br>
                        travel with WeRoad
                    </p>
                    <div class="mt-3">
                        <img src="https://strapi-imaginary.weroad.it/resource/webp-small/89115/.webp" alt="Daily Mirror" class="mx-auto h-8 md:h-10 object-contain">
                    </div>
                </div>
            </div>
        </section>
    </section>
  </div>
</template>
