<!-- // Generated from project/homepage/index1.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Press Mentions \u2014 Replica", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="bg-white flex items-center justify-center min-h-screen px-4">
    
    <section class="w-full max-w-6xl mx-auto py-10">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
        <!-- Guardian -->
        <div>
            <p class="text-2xl mb-3">“</p>
            <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                10 of the best group trips<br>for solo travellers
            </p>
            <div class="mt-3">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/89116/.webp" alt="The Guardian" class="mx-auto h-8 md:h-10 object-contain">
            </div>
        </div>
        <!-- Skift -->
        <div>
            <p class="text-2xl mb-3">“</p>
            <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                WeRoad is capitalising on<br>
                Millennials' affinity for<br>
                adventure and travel by<br>
                catering to their desire<br>
                for exploration and social<br>
                connection
            </p>
            <div class="mt-3">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/87445/.webp" alt="Skift" class="mx-auto h-8 md:h-10 object-contain">
            </div>
        </div>
        <!-- Daily Mirror -->
        <div>
            <p class="text-2xl mb-3">“</p>
            <p class="font-semibold text-gray-900 leading-snug text-base md:text-lg">
                I quit my job at age 42 to<br>
                travel with WeRoad
            </p>
            <div class="mt-3">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/89115/.webp" alt="Daily Mirror" class="mx-auto h-8 md:h-10 object-contain">
            </div>
        </div>
    </div></section>
  </section>
  </div>
</template>
