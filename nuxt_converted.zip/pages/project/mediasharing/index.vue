<!-- // Generated from project/mediasharing/index.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Background section -->
    <section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center flex-col mb-5" style="background-image: url('https://strapi-imaginary.weroad.it/resource/webp-cover/3581/tour-norvegia-lofoten-capo-nord.webp');">
        <!-- Overlay -->
        <div class="absolute inset-0 bg-black/30"></div>
        <!-- Title -->
        <h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
            Become a Travel Coordinator
        </h1>
        <p class='block text-white text-md mt-5 md:text-xl font-bold text-center drop-shadow-lg'>Explore the world and meet new friends</p>
    </section>
    <section class='text-gray-900'>
        <header class="w-full mx-auto center mb-20">
            <nav class="mx-auto max-w-6xl px-4 py-4 center">
                <ol class="flex items-center gap-2 text-sm text-gray-500 justify-center">
                    <!-- home -->
                    <li class="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m3 10.5 9-7.5 9 7.5M4.5 9.75V21h6v-6h3v6h6V9.75" />
                        </svg>
                        <span>Events & Community
                        </span>
                    </li>
                    <li class="text-gray-400">></li>
                    <li class="text-gray-600">Become a travel coordinator
                    </li>
                </ol>
            </nav>
        </header>
        <!-- Hero / Title block -->
        <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center">
            <h1 class="text-3xl font-extrabold tracking-tight mb-4">
                Why should you become a Travel Coordinator?
            </h1>
            <p class="text-gray-600 leading-relaxed mb-6">
                It’s not that easy to explain, but let’s try to sum it up with 3 hashtags:
                <span class="font-semibold text-gray-800">#TravelTheWorld</span>,
                <span class="font-semibold text-gray-800">#MeetCoolPeople</span>, and
                <span class="font-semibold text-gray-800">#PersonalGrowth</span>.
            </p>
            <p class="text-gray-600 leading-relaxed mb-4">
                We are a <span class="font-semibold text-gray-800">community of passionate travellers</span>,
                in love with the world and hungry to make new friends. We wear the Travel Coordinator t-shirt only once or twice a year to explore the world, meanwhile, we do other types of jobs the rest of the year.
            </p>
            <p class="text-gray-600 leading-relaxed mb-4">
                For us, <span class="font-semibold italic text-gray-800">every trip is a chance to feel something, like really feel something.</span>
                We lead groups of people that are just like us, eager to discover faraway countries and foreign cultures.
            </p>
            <p class="text-gray-600 leading-relaxed mb-4">
                The greatest satisfaction always comes on the very last day of our trips. It’s on that day that we look into the eyes of the people we travelled with and realise that we went from being total strangers to having new friends that explore the world together.
            </p>
            <p class="text-gray-700 leading-relaxed">
                Curious to know what a WeRoad experience looks like?
            </p>
            <div class="flex flex-wrap items-center justify-center gap-4 mt-10">
                <a href="#" class="inline-flex min-w-[250px] items-center justify-center rounded-md bg-rose-500 px-2 py-3 text-white font-semibold shadow-sm
                    hover:bg-rose-600 focus:outline-none focus-visible:ring-2  focus-visible:ring-rose-400">
                    Become a Travel Coordinator!
                </NuxtLink>
            </div>
        </main>
    </section>
    <section class="flex flex-col md:flex-row items-center justify-center min-h-screen p-6  ">
        <div class="mt-8 space-y-4 md:grid grid-cols-3 gap-6">
            <article class="rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/39385/trip-vietnam-group-dragon-selfie-december-winter.webp" class="w-full h-72 object-cover" alt="Portrait" loading="lazy">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-2">Travel the world</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        As a Travel Coordinator, you'll always travel with all expenses covered: intercontinental flights, accommodation, food and beverages, transfers and activities on site. You'll also receive compensation for your work.
                    </p>
                </div>
            </article>
            <article class="rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/42771/.webp" class="w-full h-72 object-cover" alt="Quad ride" loading="lazy">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-2">Share experiences</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        The most exciting part of this "job"? We say it's your fellow travellers: sharing a passion for travel with them, having long conversations about everything, and living incredible experiences. Also seeing them getting out of their comfort zone and challenge themselves, and always tackling small and big problems with a smile on their face.
                    </p>
                </div>
            </article>
            <article class="rounded-2xl border border-gray-200 overflow-hidden shadow-sm">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-small/39384/cuba-hills-horse-ride-group-funny-december-winter.webp" class="w-full h-72 object-cover" alt="Friends hugging" loading="lazy">
                <div class="p-6">
                    <h3 class="text-lg font-semibold mb-2">Meet new friends</h3>
                    <p class="text-gray-600 text-sm leading-relaxed">
                        You'll get to know a lot of different people who share the same love for travel that you do: a community of Travel Coordinators, WeRoad team members, and above all, the WeRoaders. The heart of our trip, you'll share unforgettable adventures and become lifelong friends with your fellow travellers.
                    </p>
                </div>
            </article>
        </div>
    </section>
    <section class='flex flex-col items-center justify-center pb-12 '>
        <h2 class='mb-10 text-3xl font-extrabold text-gray-900'>You will also...</h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl w-full">
            <!-- Card 1 -->
            <div class="bg-white shadow-sm rounded-2xl p-6 text-center hover:shadow-md transition">
                <img src="https://strapi-imaginary.weroad.it/resource/icon/39344/activities.svg" alt="Choose where and when" class="w-12 h-12 mx-auto mb-4">
                <h3 class="font-semibold text-gray-900 mb-2">Choose where and when</h3>
                <p class="text-gray-600 text-sm leading-relaxed">
                    You’ll be the one telling us where and when you want to travel. Maybe you are available just for one trip a year, or you’d like to commit fully and make this your full-time job. Either way, you’re more than welcome to join us.
                </p>
            </div>
            <!-- Card 2 -->
            <div class="bg-white shadow-sm rounded-2xl p-6 text-center hover:shadow-md transition">
                <img src="https://strapi-imaginary.weroad.it/resource/icon/39343/friends.svg" alt="Be part of a community" class="w-12 h-12 mx-auto mb-4">
                <h3 class="font-semibold text-gray-900 mb-2">Be part of a community</h3>
                <p class="text-gray-600 text-sm leading-relaxed">
                    Once you are in, you’ll be part of the Travel Coordinator community. You’ll receive useful advice from fellow Coordinators and be able to share the ups and downs of your role. You’ll also be invited to annual meetings and parties organised by WeRoad.
                </p>
            </div>
            <!-- Card 3 -->
            <div class="bg-white shadow-sm rounded-2xl p-6 text-center hover:shadow-md transition">
                <img src="https://strapi-imaginary.weroad.it/resource/icon/39345/transfer.svg" alt="Be able to grow" class="w-12 h-12 mx-auto mb-4">
                <h3 class="font-semibold text-gray-900 mb-2">Be able to grow</h3>
                <p class="text-gray-600 text-sm leading-relaxed">
                    We believe in personal and professional growth: during your career as a Travel Coordinator, you’ll be able to apply to become a Coordinator Guru (experienced Coordinator) or a Pioneer (leading the first tour of a new destination).
                </p>
            </div>
            <!-- Card 4 -->
            <div class="bg-white shadow-sm rounded-2xl p-6 text-center hover:shadow-md transition">
                <img src="https://strapi-imaginary.weroad.it/resource/icon/39346/culture.svg" alt="Have support 24/7" class="w-12 h-12 mx-auto mb-4">
                <h3 class="font-semibold text-gray-900 mb-2">Have support 24/7</h3>
                <p class="text-gray-600 text-sm leading-relaxed">
                    Before every trip, WeRoad will share all the information you’ll need to best experience your adventure. During the trip, the WeRoad Team and your Coordinator Guru will provide support 24/7 if needed. You’ll never be by yourself, we’ve got your back!
                </p>
            </div>
        </div>
        <div class="flex flex-wrap items-center justify-center gap-4 mt-10">
            <a href="#" class="inline-flex min-w-[250px] items-center justify-center rounded-md bg-rose-500 px-8 py-3 text-white font-semibold shadow-sm
                    hover:bg-rose-600 focus:outline-none focus-visible:ring-2 focus-visible:ring-rose-400">
                Become a Travel Coordinator!
            </NuxtLink>
        </div>
    </section>
    <section class="flex items-center justify-center min-h-screen px-6 bg-[#0b0b0b] text-white">
        <section class="max-w-3xl w-full my-20">
            <h2 class="text-center text-2xl md:text-3xl font-extrabold mb-12">Selection Process</h2>
            <div class="space-y-10">
                <!-- Step 1 -->
                <div class="flex items-start gap-5">
                    <div class="circle">1</div>
                    <div class="pt-[2px]">
                        <h3 class="font-semibold text-lg leading-tight mb-1">Online Form</h3>
                        <p class="text-gray-300 text-sm leading-relaxed max-w-2xl">
                            Fill out the online form and send us a video where you introduce yourself and tell us why you are Travel Coordinator material.
                        </p>
                    </div>
                </div>
                <!-- Step 2 -->
                <div class="flex items-start gap-5">
                    <div class="circle">2</div>
                    <div class="pt-[2px]">
                        <h3 class="font-semibold text-lg leading-tight mb-1">Group Interview</h3>
                        <p class="text-gray-300 text-sm leading-relaxed max-w-2xl">
                            If we see that spark in you, we’ll invite you to one of our Group Interviews with other aspiring Travel Coordinators like you.
                        </p>
                    </div>
                </div>
                <!-- Step 3 -->
                <div class="flex items-start gap-5">
                    <div class="circle">3</div>
                    <div class="pt-[2px]">
                        <h3 class="font-semibold text-lg leading-tight mb-1">Bootcamp</h3>
                        <p class="text-gray-300 text-sm leading-relaxed max-w-2xl">
                            If the Group Interview goes smoothly, congrats! You now have to get through Bootcamp, a selection weekend where we’ll test you but you’ll also live a real WeRoad experience and meet many other aspiring Travel Coordinators.
                        </p>
                    </div>
                </div>
                <!-- Step 4 -->
                <div class="flex items-start gap-5">
                    <div class="circle">4</div>
                    <div class="pt-[2px]">
                        <h3 class="font-semibold text-lg leading-tight mb-1">Final Results</h3>
                        <p class="text-gray-300 text-sm leading-relaxed max-w-2xl">
                            Once the Bootcamp is over, you’ll receive an email with the final result. If your qualities and skills match our philosophy, we’ll welcome you on board and start your adventure as a Travel Coordinator!
                        </p>
                    </div>
                </div>
            </div>
        </section>
    </section>
    <section class="flex flex-col items-center justify-center  px-4 py-10">
        <section class="max-w-2xl w-full space-y-10">
            <!-- Upcoming Group Interviews -->
            <div class="text-center">
                <h2 class="text-2xl md:text-3xl font-extrabold mb-6">Upcoming Group Interviews</h2>
                <div class="bg-gray-50 border border-gray-200 rounded-xl px-5 py-4 flex justify-between items-center text-sm md:text-base">
                    <div class="flex items-center gap-2 text-gray-600">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 6.75h.008v.008H8.25V6.75zM8.25 12h.008v.008H8.25V12zM8.25 17.25h.008v.008H8.25v-.008zM12 6.75h.008v.008H12V6.75zM12 12h.008v.008H12V12zM12 17.25h.008v.008H12v-.008zM15.75 6.75h.008v.008h-.008V6.75zM15.75 12h.008v.008h-.008V12zM15.75 17.25h.008v.008h-.008v-.008z" />
                            <path stroke-linecap="round" stroke-linejoin="round" d="M3 4.5h18M3 4.5v15a2.25 2.25 0 002.25 2.25h13.5A2.25 2.25 0 0021 19.5v-15M3 4.5L4.5 3m15 1.5L19.5 3" />
                        </svg>
                        <span>To be announced</span>
                    </div>
                    <p class="font-semibold text-gray-800">Online Group Interview TBC</p>
                </div>
            </div>
            <!-- Upcoming Bootcamps -->
            <div class="text-center">
                <h2 class="text-2xl md:text-3xl font-extrabold mb-6">Upcoming Bootcamps</h2>
                <div class="bg-gray-50 border border-gray-200 rounded-xl px-5 py-4 flex items-center gap-4 text-sm md:text-base">
                    <!-- Date box -->
                    <div class="bg-white border border-gray-300 rounded-lg px-3 py-2 text-center flex-shrink-0">
                        <div class="text-xl font-bold text-gray-800 leading-none">19</div>
                        <div class="text-xs uppercase tracking-wide text-gray-500">Jul</div>
                    </div>
                    <!-- Bootcamp info -->
                    <div class="text-left">
                        <p class="font-semibold text-gray-800">Bootcamp @ Liverpool</p>
                        <p class="text-gray-600 text-sm">Saturday 19th and Sunday 20th July 2025 in Liverpool</p>
                    </div>
                </div>
            </div>
        </section>
    </section>
    <section class="flex flex-col items-center justify-center px-6 bg-[#0b0b0b] text-white">
        <section class="text-center space-y-6 items-center py-20 text-white">
            <div>
                <h2 class="text-2xl md:text-3xl font-extrabold mb-2">
                    Are you ready to join this adventure?
                </h2>
                <p class="text-sm text-white">Send us your application!</p>
            </div>
            <!-- Button -->
            <div>
                <button class="bg-[#ff4e4e] hover:bg-[#e23f3f] text-white font-semibold text-sm px-6 py-2 rounded-md transition-all duration-200">
                    Become a Travel Coordinator!
                </button>
            </div>
            <!-- Footer text -->
            <div class="pt-10 text-xs md:text-sm text-white leading-relaxed ">
                <p class="text-white">Questions about the application and the role of Travel Coordinator?</p>
                <p>
                    Do you want to contact us directly?
                    <a href="mailto:coordinators@weroad.com" class="text-white font-medium hover:underline">
                        Email us at coordinators@weroad.com
                    </NuxtLink>
                </p>
            </div>
        </section>
    </section>
  </div>
</template>
