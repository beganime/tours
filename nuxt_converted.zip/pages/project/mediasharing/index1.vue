<!-- // Generated from project/mediasharing/index1.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Join the Adventure", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="text-center space-y-6 items-center py-20">
        <div>
            <h2 class="text-2xl md:text-3xl font-extrabold mb-2">
                Are you ready to join this adventure?
            </h2>
            <p class="text-sm text-gray-300">Send us your application!</p>
        </div>
        <!-- Button -->
        <div>
            <button class="bg-[#ff4e4e] hover:bg-[#e23f3f] text-white font-semibold text-sm px-6 py-2 rounded-md transition-all duration-200">
                Become a Travel Coordinator!
            </button>
        </div>
        <!-- Footer text -->
        <div class="pt-10 text-xs md:text-sm text-gray-400 leading-relaxed">
            <p>Questions about the application and the role of Travel Coordinator?</p>
            <p>
                Do you want to contact us directly?
                <a href="mailto:coordinators@weroad.com" class="text-white font-medium hover:underline">
                    Email us at coordinators@weroad.com
                </NuxtLink>
            </p>
        </div>
    </section>
  </div>
</template>
