<!-- // Generated from project/mediasharing/mediashrng.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Background section -->
    <section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center flex-col mb-5" style="background-image: url('https://strapi-imaginary.weroad.it/resource/webp-cover/40074/nepal-tramonto-gruppo-novembre-inverno.webp');">
        <!-- Overlay -->
        <div class="absolute inset-0 bg-black/30"></div>
        <!-- Title -->
        <h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
            Share your best moments as a WeRoader
        </h1>
        <p class='block text-white text-md mt-5 md:text-xl font-bold text-center drop-shadow-lg'>We're always on the hunt for exciting content!</p>
    </section>
    <section class='text-gray-900'>
        <header class="w-full mx-auto center mb-20">
            <nav class="mx-auto max-w-6xl px-4 py-4 center">
                <ol class="flex items-center gap-2 text-sm text-gray-500 justify-center">
                    <!-- home -->
                    <li class="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m3 10.5 9-7.5 9 7.5M4.5 9.75V21h6v-6h3v6h6V9.75" />
                        </svg>
                        <span>Events & Community
                        </span>
                    </li>
                    <li class="text-gray-400">></li>
                    <li class="text-gray-600">Media sharing
                    </li>
                </ol>
            </nav>
        </header>
        <!-- Hero / Title block -->
        <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center">
            <h1 class="text-3xl font-extrabold tracking-tight mb-4">
                Here at WeRoad, our trips have always been reported through your eyes!
            </h1>
            <p class="text-gray-600 leading-relaxed mb-8">
                Yep, that's right: we don't like stock images and polished photoshoots. We think that the best content is unfiltered: that's why we always use images and videos made by our WeRoaders - just like you!
                <br><br>
                If you'd like to share pics and videos from your latest trip (or all the trips you partook in!), we'd greatly appreciate it. How to get started? Follow these simple steps to get started!
            </p>
        </main>
    </section>
    <section class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-2xl shadow-md overflow-hidden max-w-6xl w-full flex flex-col md:flex-row">
            <!-- Left: Image -->
            <div class="md:w-1/2">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/32260/norway-trip-group-photo-december-winter.webp" alt="WeRoad Group Photo" class="w-full h-full object-cover" />
            </div>
            <!-- Right: Text -->
            <div class="md:w-1/2 p-8 flex flex-col justify-center">
                <p class="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-2">
                    CONTENT GUIDELINES
                </p>
                <h2 class="text-2xl font-extrabold text-gray-900 mb-4 leading-snug">
                    Do's
                </h2>
                <ul class="list-disc pl-6 text-gray-700 space-y-3 text-sm md:text-base">
                    <li>
                        <span class="font-semibold text-[#c70000]">Photos:</span>
                        max <a href="#" class="underline text-[#c70000]">50 pics already selected by you</NuxtLink>
                    </li>
                    <li>
                        <span class="font-semibold text-[#c70000]">Videos:</span>
                        a total of <a href="#" class="underline text-[#c70000]">5 minutes max</NuxtLink>
                    </li>
                    <li>Group photos and selfies/videos</li>
                    <li>Shots in which WeRoad backpacks, coordinator badge or where t-shirt are visible</li>
                    <li>Photos and videos of the most exciting local activities of the trip and must-see places</li>
                </ul>
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center min-h-screen p-4">
        <div class="bg-white rounded-2xl shadow-md overflow-hidden max-w-6xl w-full flex flex-col md:flex-row">
            <!-- Right: Text -->
            <div class="md:w-1/2 p-8 flex flex-col justify-center">
                <p class="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-2">
                    CONTENT GUIDELINES
                </p>
                <h2 class="text-2xl font-extrabold text-gray-900 mb-4 leading-snug">
                    Don’ts
                </h2>
                <ul class="list-disc pl-6 text-gray-700 space-y-3 text-sm md:text-base">
                    <li>No blurry, dark or very static photos or videos</li>
                    <li>No heavy edited or artificial photos and videos</li>
                </ul>
            </div>
            <!-- Left: Image -->
            <div class="md:w-1/2">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/34529/iceland-group-photo-december-winter.webp" alt="WeRoad Group Photo" class="w-full h-full object-cover" />
            </div>
        </div>
    </section>
    <section class="flex items-center justify-center min-h-screen p-6 bg-black ">
        <section class="max-w-3xl text-center space-y-6">
            <h2 class="text-2xl md:text-3xl font-extrabold text-white">How to upload your content</h2>
            <p class="text-sm text-gray-300">in 3 simple steps!</p>
            <div class="space-y-8 text-left mt-8">
                <!-- Step 1 -->
                <div class="flex items-start gap-4">
                    <div class="flex-shrink-0 w-6 h-6 rounded-full border border-gray-400 flex items-center justify-center text-sm text-white">1</div>
                    <p class="text-sm leading-relaxed text-gray-300">
                        <span class="font-semibold underline">SELECTING:</span> you’ve probably taken millions of pics and videos and as long
                        as we’d like to see all of them, we don’t really have the time. So: choose the best photos and videos of your trip and send us only that!
                    </p>
                </div>
                <!-- Step 2 -->
                <div class="flex items-start gap-4">
                    <div class="flex-shrink-0 w-6 h-6 rounded-full border border-gray-400 flex items-center justify-center text-sm text-white">2</div>
                    <div class="text-sm text-gray-300 leading-relaxed">
                        <p><span class="font-semibold underline">FILE NAMING:</span> you can upload one or multiple media at a time. Be sure to
                            attach the comment to your assets, so that destinations and coordinators can be identified correctly.</p>
                        <p class="mt-3 text-center text-xs text-gray-400">
                            In this order: Coordinator Full Name - Travel Name - Departure Date (year/month/day) - Your Full Name - IG Profile
                        </p>
                        <p class="mt-2 text-center text-xs text-gray-400">
                            Example: <span class="text-white">Archie Williams - Jordan 360° - 20221113 - Anna Harvey - @annahvry</span>
                        </p>
                    </div>
                </div>
                <!-- Step 3 -->
                <div class="flex items-start gap-4">
                    <div class="flex-shrink-0 w-6 h-6 rounded-full border border-gray-400 flex items-center justify-center text-sm text-white">3</div>
                    <p class="text-sm leading-relaxed text-gray-300">
                        <span class="font-semibold underline">UPLOADING:</span> you’re ready to upload! Click the red button below and start uploading.
                    </p>
                </div>
            </div>
            <!-- Button -->
            <div class="pt-6">
                <button class="bg-[#e63946] hover:bg-[#ff4d5a] text-white font-semibold text-sm px-6 py-2 rounded transition-all">
                    Upload your content here
                </button>
            </div>
        </section>
    </section>
    <section class="flex items-center justify-center min-h-screen p-6">
        <section class="max-w-4xl text-center px-4">
            <h2 class="text-xl md:text-4xl font-extrabold text-[#e63946] mb-4">Remember!</h2>
            <p class="text-sm md:text-base text-gray-700 leading-relaxed italic">
                By sending, publishing or viewing content on or through the Website, you grant WeRoad a license without territorial limits, non-exclusive,
                free of charge and with the right of sublicense, for use, copying, reproduction, processing, adaptation, modification, publication,
                transmission, display and distribution of such content with any media or distribution method currently available or developed thereafter.
                We also have the right to disclose your identity to any third party who is claiming that any content posted or uploaded by you on the
                Website constitutes a violation of their intellectual property rights, or of their right to privacy. We have the right to remove any posting
                you make on the Website if, in our opinion, your post does comply with the “Use not allowed” section of Terms&Conditions. You are solely
                responsible for securing and backing up your own content. <br><br>
                We also have the right to disclose your identity to any third party who is claiming that any content posted or uploaded by you on the
                Website constitutes a violation of their intellectual property rights, or of their right to privacy. We have the right to remove any posting
                you make on the Website if, in our opinion, your post does comply with the “Use not allowed” section of Terms&Conditions. You are solely
                responsible for securing and backing up your own content.
            </p>
        </section>
    </section>
  </div>
</template>
