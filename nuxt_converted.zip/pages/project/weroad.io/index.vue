<!-- // Generated from project/weroad.io/index.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Hero \u2014 Replica (mobile adapted)", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- HERO -->
    <section class="w-full mx-auto pb-6 relative h-[520px] md:h-[460px] overflow-hidden">
        <!-- Background image (focus right so the person stays visible on mobile) -->
        <img src="https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=1600&auto=format&fit=crop" alt="Desert background" class="absolute inset-0 w-full h-full object-cover object-[70%_50%] md:object-center" />
        <!-- Readability overlays -->
        <!-- global light vignette -->
        <div class="absolute inset-0 bg-black/20"></div>
        <!-- stronger left-to-right fade for mobile text block -->
        <div class="absolute inset-y-0 left-0 w-4/5 sm:w-2/3 md:w-1/2 bg-gradient-to-r from-black/70 via-black/30 to-transparent"></div>
        <!-- top fade like original -->
        <div class="pointer-events-none absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-black/60 to-transparent"></div>
        <!-- Logo: left on mobile, centered on desktop -->
        <div class="absolute top-5 left-4 md:left-1/2 md:-translate-x-1/2 flex items-baseline gap-1 select-none z-10">
            <span class="text-[#e31b23] font-extrabold tracking-tight text-[28px] leading-none">WE</span>
            <span class="text-white font-extrabold tracking-tight text-[28px] leading-none">ROAD</span>
        </div>
        <!-- Headline: left & stacked on mobile, centered on desktop -->
        <div class="absolute inset-0 flex items-center md:items-center justify-start md:justify-center px-4 sm:px-6">
            <h1 class="text-white font-extrabold tracking-tight drop-shadow-[0_2px_10px_rgba(0,0,0,.45)]
               text-left md:text-center leading-[1.06]
               text-[34px] sm:text-[40px] md:text-[28px] lg:text-[30px] max-w-[15ch] md:max-w-none">
                Connecting people, Cultures and Stories.
            </h1>
        </div>
    </section>
    <section class="w-full py-10 bg-[#111] text-white">
        <!-- small intro text centered -->
        <div class="text-center text-[12px] leading-snug text-gray-200 opacity-90 max-w-3xl mx-auto px-4">
            <p>From €10 to €100 million in just 3 years, and continues to grow by 50% year on year — not bad, huh?</p>
            <p>Our secret sauce? A super scalable marketplace model that did exactly what it promised. Now we’re one of
                the fastest-growing scale-ups Europe. Seated backed us, so it must be true :P</p>
        </div>
        <!-- content -->
        <div class="max-w-6xl mx-auto mt-6 px-4 grid grid-cols-1 md:grid-cols-12 gap-10">
            <!-- collage (left) -->
            <div class="md:col-span-5 flex justify-center">
                <div class="w-[520px] max-w-full grid grid-cols-2 gap-3">
                    <!-- top wide -->
                    <img src="https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=1600&auto=format&fit=crop" alt="" class="col-span-2 w-full h-full aspect-[16/9] object-cover rounded-xl" />
                    <!-- bottom left square -->
                    <img src="https://images.unsplash.com/photo-1543352634-8731f4fc1e31?q=80&w=1600&auto=format&fit=crop" alt="" class="w-full h-full aspect-square object-cover rounded-xl" />
                    <!-- bottom right square -->
                    <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop" alt="" class="w-full h-full aspect-square object-cover rounded-xl" />
                </div>
            </div>
            <!-- text (right) -->
            <div class="md:col-span-7">
                <h2 class="text-white font-extrabold text-[26px] leading-tight mb-4">
                    WeRoad is the world's biggest<br class="hidden md:block"> community of people who want
                    to explore the world and<br class="hidden md:block"> actually connect.
                </h2>
                <p class="text-gray-200 text-[13.5px] leading-relaxed mb-3">
                    <span class="font-semibold text-white">300,000</span> travelers,
                    <span class="font-semibold text-white">1,000</span> itineraries,
                    <span class="font-semibold text-white">4,000</span> travel coordinators
                    rated <span class="font-semibold text-white">9/10</span> on average. In just a few years, we’ve hit
                    <span class="font-semibold text-white">3.5 million</span> followers and claimed the throne as the #1 adventure travel
                    community brand out there.
                </p>
                <p class="text-gray-200 text-[13.5px] leading-relaxed mb-3">
                    Starting this year, we’re not just fixing loneliness through epic trips, we’re doing it with local events and weekends too,
                    run by our coordinators or handpicked partners.
                </p>
                <p class="text-gray-200 text-[13.5px] leading-relaxed">
                    And all of this – trips, events, vibes – is WeRoad.
                    Wanna feel what’s WeRoad? Scroll for a video (warning: emotions might hit hard) and a few articles that get what we’re all about.
                </p>
            </div>
        </div>
    </section>
    <section class="antialiased">
        <!-- In the press -->
        <section class="bg-[#111111] border-y border-neutral-800">
            <div class="max-w-6xl mx-auto px-4 py-8 md:py-10">
                <p class="text-center text-white font-extrabold text-sm md:text-2xl">
                    In the press
                </p>
                <div class="mt-6 flex flex-wrap items-center justify-center gap-x-10 sm:gap-x-12 md:gap-x-16 gap-y-6 opacity-90">
                    <img src="https://www.weroad.io/images/logo-wired.svg" alt="WIRED" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                    <img src="https://www.weroad.io/images/logo-travolution.svg" alt="Travolution" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                    <img src="https://www.weroad.io/images/logo-sifted.svg" alt="sifted" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                    <img src="https://www.weroad.io/images/logo-skift.svg" alt="Skift" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                    <img src="https://www.weroad.io/images/logo-phocuswire.svg" alt="PhocusWire" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                    <img src="https://www.weroad.io/images/logo-forbes.svg" alt="Forbes" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
                </div>
            </div>
        </section>
    </section>
    <section class="antialiased">
        <section class="bg-[#111111] border-y border-neutral-800">
            <div class="max-w-6xl mx-auto px-4 md:px-6 py-10">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
                    <!-- Left column -->
                    <div class="">
                        <div class="flex items-center gap-2 mb-4 text-[#e5e7eb]">
                            <span class="text-[15px]" aria-hidden="true">🏁</span>
                            <h3 class="uppercase text-[13px] font-extrabold tracking-wide">Meet WeRoad. Read our story year by year</h3>
                        </div>
                        <ul class="space-y-2 text-sm text-[#e5e7eb]">
                            <!-- item -->
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Bootstrap</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 0)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Start-up</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 2)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Scale-up</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 3)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Dancing time</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 4 aka the pandemic year)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Five years in a row</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 5)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Adventures in technicolor</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 6)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Pairing Community and Scale</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 7)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Breaking the bubbles</NuxtLink>
                                <span class="text-neutral-400 ml-2">(year 8)</span>
                            </li>
                        </ul>
                    </div>
                    <!-- Right column -->
                    <div>
                        <div class="flex items-center gap-2 mb-4 text-[#e5e7eb]">
                            <span class="text-[15px]" aria-hidden="true">📼</span>
                            <h3 class="uppercase text-[13px] font-extrabold tracking-wide">WeRoad in video</h3>
                        </div>
                        <ul class="space-y-2 text-sm text-[#e5e7eb]">
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Your Reason Why</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2024 corporate video)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Make it Matter</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2024 corporate video)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">WeRoad Island - Festival Edition</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2023 Coordinators' Global Reunion)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Go beyond</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2022 corporate video)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Have you ever been on a WeRoad</NuxtLink>
                                <span class="text-neutral-400 ml-2">(our 2022 TV commercial)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Back to real adventures</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2021 corporate video)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">Coordinators Bootcamp</NuxtLink>
                                <span class="text-neutral-400 ml-2">(How we select and train our travel coordinators)</span>
                            </li>
                            <li class="flex gap-3">
                                <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                                <a href="#" class="hover:underline">WeRoad Jordan Expedition</NuxtLink>
                                <span class="text-neutral-400 ml-2">(2021 WeRoad's team in Jordan)</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
    </section>
    <section class="antialiased">
        <!-- ARTICLES THAT MENTION US -->
        <section class="bg-[#111111] border-y border-neutral-800">
            <div class="max-w-5xl mx-auto px-4 md:px-6 py-10">
                <div class="flex items-center gap-2 mb-5 text-[#e5e7eb]">
                    <span class="text-[15px]" aria-hidden="true">📰</span>
                    <h3 class="uppercase text-[13px] font-extrabold tracking-wide">Articles that mention us:</h3>
                </div>
                <ul class="space-y-2 text-[15px] leading-relaxed text-[#e5e7eb]">
                    <!-- 2025 -->
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">In recruitment, an AI-on-AI war is rewriting the hiring playbook</NuxtLink>,
                            <span class="text-neutral-300">The Next Web, August 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Viaggiamo per aggiustare qualcosa di rotto, per esplorare una interiorità abbandonata</NuxtLink>,
                            <span class="text-neutral-300">L’Espresso, August 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Ces Français qui utilisent les applications de rencontre pour se faire des amis</NuxtLink>,
                            <span class="text-neutral-300">Le Figaro, August 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Viaggiare al femminile, tra desiderio di scoperta e qualche pregiudizio</NuxtLink>,
                            <span class="text-neutral-300">La Repubblica, July 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Sifted 50 Southern Europe Leaderboard</NuxtLink>,
                            <span class="text-neutral-300">July 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeMeet: WeRoad’s new initiative</NuxtLink>,
                            <span class="text-neutral-300">Travolution, May 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">The solo travel experience you didn’t know you were missing – with Fortune 40 under 40 alumn and WeRoad Co-founder Erika De Santi</NuxtLink>,
                            <span class="text-neutral-300">Globetrotter podcast, April 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Cette plateforme vous permet de partir à l’autre bout du monde avec des voyageurs du monde entier</NuxtLink>,
                            <span class="text-neutral-300">Cosmopolitan FR, February 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Tutto quello che ho imparato facendo un viaggio WeRoad</NuxtLink>,
                            <span class="text-neutral-300">Wired Italia, January 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeRoad eyes market expansion amid 2024’s £100M revenue success</NuxtLink>,
                            <span class="text-neutral-300">Travolution, January 2025</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">€0 to €100M: How WeRoad Built a Travel Empire, WeRoad Co-Founder Fabio Bin</NuxtLink>,
                            <span class="text-neutral-300">Propellic podcast, December 16, 2024</span>
                        </div>
                    </li>
                    <!-- 2024 -->
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">How far has solo adventure tour operator WeRoad come in a year?</NuxtLink>,
                            <span class="text-neutral-300">Travolution, November 1, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Revolutionizing Adventure Travel: WeRoad Co-Founder, Erika De Santi</NuxtLink>,
                            <span class="text-neutral-300">Travel Trends Podcast, August 21, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Why the Travel Industry should buy into the experience economy</NuxtLink>,
                            <span class="text-neutral-300">Phocuswire, August 2, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Meet Andrea D’Amico, CEO of WeRoad, at FutureTravel Summit 2024</NuxtLink>,
                            <span class="text-neutral-300">Future Travel, July 18, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Going Global – How to expand with an M&amp;A mindset</NuxtLink>,
                            <span class="text-neutral-300">A Sifted Report, July 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Sifted 50 Southern Europe Leaderboard</NuxtLink>,
                            <span class="text-neutral-300">July 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Erika De Santi – Wild Business Growth Podcast #286: Group Travel Adventurer, Co-Founder of WeRoad</NuxtLink>,
                            <span class="text-neutral-300">Wild Business Growth Podcast, May 8, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeRoad goes global</NuxtLink>,
                            <span class="text-neutral-300">La Repubblica, April 24, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeRoad launches global platform for international adventure seekers</NuxtLink>,
                            <span class="text-neutral-300">Travel Daily Media, April 17, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">My Mexican adventure that all solo 30-somethings should experience</NuxtLink>,
                            <span class="text-neutral-300">The Times, March 24, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">TOP 100: Europe’s most influential women in the startup and venture capital space</NuxtLink>,
                            <span class="text-neutral-300">EU-Startups, March 7, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">How Travel Can Fix the World’s Loneliness Crisis</NuxtLink>,
                            <span class="text-neutral-300">Skift</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Learn how low-budget growth hacks helped Italian startup WeRoad to raise €36M…</NuxtLink>,
                            <span class="text-neutral-300">The Pursuit of Scrappiness, February 13, 2024</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Top Travel Industry Predictions for 2024</NuxtLink>,
                            <span class="text-neutral-300">Phocuswire, January 2, 2024</span>
                        </div>
                    </li>
                    <!-- 2023–2021 -->
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeRoad’s journey to europe’s leading group adventure tour operator by 2025</NuxtLink>,
                            <span class="text-neutral-300">Travolution, October 4, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">10 of the best tour companies for solo travellers</NuxtLink>,
                            <span class="text-neutral-300">The Times, August 23, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Keeping campaigns real</NuxtLink>,
                            <span class="text-neutral-300">Skift, June 24, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Italian company WeRoad raises 18 million euros to become the European leader in group travel</NuxtLink>,
                            <span class="text-neutral-300">Forbes, April 27, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">How to hire an external CEO</NuxtLink>,
                            <span class="text-neutral-300">Sifted, April 27, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">TOP 100: Europe’s most influential women in the startup and venture capital space</NuxtLink>,
                            <span class="text-neutral-300">EU Startup, March 8, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Anything but plane: WeRoad’s launches OOH campaign</NuxtLink>,
                            <span class="text-neutral-300">Travel Daily, March 2, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Tour Operators Up Offerings for Solo Travelers</NuxtLink>,
                            <span class="text-neutral-300">Skift, January 17, 2023</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">The WeRoad Journey: Connecting people, culture and stories</NuxtLink>,
                            <span class="text-neutral-300">EU Startup, August 24, 2022</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">Q&amp;A: WeRoad CEO on Booking.com, rapid growth and automation</NuxtLink>,
                            <span class="text-neutral-300">PhocusWire, August 5, 2022</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">WeRoad aims for the UK</NuxtLink>,
                            <span class="text-neutral-300">La Repubblica, April 10, 2021</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">How Italian Travel Startup WeRoad Plans to Grow in Europe</NuxtLink>,
                            <span class="text-neutral-300">Business Insider, Nov 10, 2021</span>
                        </div>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <div>
                            <a href="#" class="italic hover:underline">The 28 Italian startups to watch, according to VCs</NuxtLink>,
                            <span class="text-neutral-300">Sifted, April 8, 2021</span>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
    </section>
  </div>
</template>
