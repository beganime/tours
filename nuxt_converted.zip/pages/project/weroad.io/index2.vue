<!-- // Generated from project/weroad.io/index2.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "WeRoad \u2014 About Block (replica)", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="w-full py-10">
        <!-- small intro text centered -->
        <div class="text-center text-[12px] leading-snug text-gray-200 opacity-90 max-w-3xl mx-auto px-4">
            <p>From €10 to €100 million in just 3 years, and continues to grow by 50% year on year — not bad, huh?</p>
            <p>Our secret sauce? A super scalable marketplace model that did exactly what it promised. Now we’re one of
                the fastest-growing scale-ups Europe. Seated backed us, so it must be true :P</p>
        </div>
        <!-- content -->
        <div class="max-w-6xl mx-auto mt-6 px-4 grid grid-cols-1 md:grid-cols-12 gap-10">
            <!-- collage (left) -->
            <div class="md:col-span-5 flex justify-center">
                <div class="w-[520px] max-w-full grid grid-cols-2 gap-3">
                    <!-- top wide -->
                    <img src="https://images.unsplash.com/photo-1518684079-3c830dcef090?q=80&w=1600&auto=format&fit=crop" alt="" class="col-span-2 w-full h-full aspect-[16/9] object-cover rounded-xl" />
                    <!-- bottom left square -->
                    <img src="https://images.unsplash.com/photo-1543352634-8731f4fc1e31?q=80&w=1600&auto=format&fit=crop" alt="" class="w-full h-full aspect-square object-cover rounded-xl" />
                    <!-- bottom right square -->
                    <img src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop" alt="" class="w-full h-full aspect-square object-cover rounded-xl" />
                </div>
            </div>
            <!-- text (right) -->
            <div class="md:col-span-7">
                <h2 class="text-white font-extrabold text-[26px] leading-tight mb-4">
                    WeRoad is the world's biggest<br class="hidden md:block"> community of people who want
                    to explore the world and<br class="hidden md:block"> actually connect.
                </h2>
                <p class="text-gray-200 text-[13.5px] leading-relaxed mb-3">
                    <span class="font-semibold text-white">300,000</span> travelers,
                    <span class="font-semibold text-white">1,000</span> itineraries,
                    <span class="font-semibold text-white">4,000</span> travel coordinators
                    rated <span class="font-semibold text-white">9/10</span> on average. In just a few years, we’ve hit
                    <span class="font-semibold text-white">3.5 million</span> followers and claimed the throne as the #1 adventure travel
                    community brand out there.
                </p>
                <p class="text-gray-200 text-[13.5px] leading-relaxed mb-3">
                    Starting this year, we’re not just fixing loneliness through epic trips, we’re doing it with local events and weekends too,
                    run by our coordinators or handpicked partners.
                </p>
                <p class="text-gray-200 text-[13.5px] leading-relaxed">
                    And all of this – trips, events, vibes – is WeRoad.
                    Wanna feel what’s WeRoad? Scroll for a video (warning: emotions might hit hard) and a few articles that get what we’re all about.
                </p>
            </div>
        </div>
    </section>
  </div>
</template>
