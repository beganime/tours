<!-- // Generated from project/weroad.io/index3.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "In the press \u2014 logos", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="antialiased">
    
    <!-- In the press -->
<section class="bg-[#111111] border-y border-neutral-800">
    <div class="max-w-6xl mx-auto px-4 py-8 md:py-10">
        <p class="text-center text-white font-semibold text-sm md:text-base">
            In the press
        </p>
        <div class="mt-6 flex flex-wrap items-center justify-center gap-x-10 sm:gap-x-12 md:gap-x-16 gap-y-6 opacity-90">
            <img src="https://www.weroad.io/images/logo-wired.svg" alt="WIRED" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
            <img src="https://www.weroad.io/images/logo-travolution.svg" alt="Travolution" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
            <img src="https://www.weroad.io/images/logo-sifted.svg" alt="sifted" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
            <img src="https://www.weroad.io/images/logo-skift.svg" alt="Skift" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
            <img src="https://www.weroad.io/images/logo-phocuswire.svg" alt="PhocusWire" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
            <img src="https://www.weroad.io/images/logo-forbes.svg" alt="Forbes" class="h-6 md:h-7 lg:h-8 w-auto select-none" loading="lazy">
        </div>
    </div></section>
  </section>
  </div>
</template>
