<!-- // Generated from project/weroad.io/index4.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "WeRoad \u2014 Lists Block", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="antialiased">
		
   <section class="bg-[#111111] border-y border-neutral-800">
    <div class="max-w-6xl mx-auto px-4 md:px-6 py-10">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16">
            <!-- Left column -->
            <div>
                <div class="flex items-center gap-2 mb-4">
                    <span class="text-[15px]" aria-hidden="true">🏁</span>
                    <h3 class="uppercase text-[13px] font-extrabold tracking-wide">Meet WeRoad. Read our story year by year</h3>
                </div>
                <ul class="space-y-2 text-sm">
                    <!-- item -->
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Bootstrap</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 0)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Start-up</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 2)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Scale-up</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 3)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Dancing time</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 4 aka the pandemic year)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Five years in a row</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 5)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Adventures in technicolor</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 6)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Pairing Community and Scale</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 7)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Breaking the bubbles</NuxtLink>
                        <span class="text-neutral-400 ml-2">(year 8)</span>
                    </li>
                </ul>
            </div>
            <!-- Right column -->
            <div>
                <div class="flex items-center gap-2 mb-4">
                    <span class="text-[15px]" aria-hidden="true">📼</span>
                    <h3 class="uppercase text-[13px] font-extrabold tracking-wide">WeRoad in video</h3>
                </div>
                <ul class="space-y-2 text-sm">
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Your Reason Why</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2024 corporate video)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Make it Matter</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2024 corporate video)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">WeRoad Island - Festival Edition</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2023 Coordinators' Global Reunion)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Go beyond</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2022 corporate video)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Have you ever been on a WeRoad</NuxtLink>
                        <span class="text-neutral-400 ml-2">(our 2022 TV commercial)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Back to real adventures</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2021 corporate video)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">Coordinators Bootcamp</NuxtLink>
                        <span class="text-neutral-400 ml-2">(How we select and train our travel coordinators)</span>
                    </li>
                    <li class="flex gap-3">
                        <span class="mt-2 inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                        <a href="#" class="hover:underline">WeRoad Jordan Expedition</NuxtLink>
                        <span class="text-neutral-400 ml-2">(2021 WeRoad's team in Jordan)</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>
	</section>
  </div>
</template>
