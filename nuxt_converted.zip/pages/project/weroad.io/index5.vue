<!-- // Generated from project/weroad.io/index5.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Articles that mention us \u2014 list", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- ARTICLES THAT MENTION US -->
    <section class="bg-[#111111] border-y border-neutral-800">
        <div class="max-w-5xl mx-auto px-4 md:px-6 py-10">
            <div class="flex items-center gap-2 mb-5">
                <span class="text-[15px]" aria-hidden="true">📰</span>
                <h3 class="uppercase text-[13px] font-extrabold tracking-wide">Articles that mention us:</h3>
            </div>
            <ul class="space-y-2 text-[15px] leading-relaxed">
                <!-- 2025 -->
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">In recruitment, an AI-on-AI war is rewriting the hiring playbook</NuxtLink>,
                        <span class="text-neutral-300">The Next Web, August 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Viaggiamo per aggiustare qualcosa di rotto, per esplorare una interiorità abbandonata</NuxtLink>,
                        <span class="text-neutral-300">L’Espresso, August 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Ces Français qui utilisent les applications de rencontre pour se faire des amis</NuxtLink>,
                        <span class="text-neutral-300">Le Figaro, August 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Viaggiare al femminile, tra desiderio di scoperta e qualche pregiudizio</NuxtLink>,
                        <span class="text-neutral-300">La Repubblica, July 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Sifted 50 Southern Europe Leaderboard</NuxtLink>,
                        <span class="text-neutral-300">July 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeMeet: WeRoad’s new initiative</NuxtLink>,
                        <span class="text-neutral-300">Travolution, May 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">The solo travel experience you didn’t know you were missing – with Fortune 40 under 40 alumn and WeRoad Co-founder Erika De Santi</NuxtLink>,
                        <span class="text-neutral-300">Globetrotter podcast, April 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Cette plateforme vous permet de partir à l’autre bout du monde avec des voyageurs du monde entier</NuxtLink>,
                        <span class="text-neutral-300">Cosmopolitan FR, February 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Tutto quello che ho imparato facendo un viaggio WeRoad</NuxtLink>,
                        <span class="text-neutral-300">Wired Italia, January 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeRoad eyes market expansion amid 2024’s £100M revenue success</NuxtLink>,
                        <span class="text-neutral-300">Travolution, January 2025</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">€0 to €100M: How WeRoad Built a Travel Empire, WeRoad Co-Founder Fabio Bin</NuxtLink>,
                        <span class="text-neutral-300">Propellic podcast, December 16, 2024</span>
                    </div>
                </li>
                <!-- 2024 -->
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">How far has solo adventure tour operator WeRoad come in a year?</NuxtLink>,
                        <span class="text-neutral-300">Travolution, November 1, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Revolutionizing Adventure Travel: WeRoad Co-Founder, Erika De Santi</NuxtLink>,
                        <span class="text-neutral-300">Travel Trends Podcast, August 21, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Why the Travel Industry should buy into the experience economy</NuxtLink>,
                        <span class="text-neutral-300">Phocuswire, August 2, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Meet Andrea D’Amico, CEO of WeRoad, at FutureTravel Summit 2024</NuxtLink>,
                        <span class="text-neutral-300">Future Travel, July 18, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Going Global – How to expand with an M&amp;A mindset</NuxtLink>,
                        <span class="text-neutral-300">A Sifted Report, July 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Sifted 50 Southern Europe Leaderboard</NuxtLink>,
                        <span class="text-neutral-300">July 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Erika De Santi – Wild Business Growth Podcast #286: Group Travel Adventurer, Co-Founder of WeRoad</NuxtLink>,
                        <span class="text-neutral-300">Wild Business Growth Podcast, May 8, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeRoad goes global</NuxtLink>,
                        <span class="text-neutral-300">La Repubblica, April 24, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeRoad launches global platform for international adventure seekers</NuxtLink>,
                        <span class="text-neutral-300">Travel Daily Media, April 17, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">My Mexican adventure that all solo 30-somethings should experience</NuxtLink>,
                        <span class="text-neutral-300">The Times, March 24, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">TOP 100: Europe’s most influential women in the startup and venture capital space</NuxtLink>,
                        <span class="text-neutral-300">EU-Startups, March 7, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">How Travel Can Fix the World’s Loneliness Crisis</NuxtLink>,
                        <span class="text-neutral-300">Skift</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Learn how low-budget growth hacks helped Italian startup WeRoad to raise €36M…</NuxtLink>,
                        <span class="text-neutral-300">The Pursuit of Scrappiness, February 13, 2024</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Top Travel Industry Predictions for 2024</NuxtLink>,
                        <span class="text-neutral-300">Phocuswire, January 2, 2024</span>
                    </div>
                </li>
                <!-- 2023–2021 -->
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeRoad’s journey to europe’s leading group adventure tour operator by 2025</NuxtLink>,
                        <span class="text-neutral-300">Travolution, October 4, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">10 of the best tour companies for solo travellers</NuxtLink>,
                        <span class="text-neutral-300">The Times, August 23, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Keeping campaigns real</NuxtLink>,
                        <span class="text-neutral-300">Skift, June 24, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Italian company WeRoad raises 18 million euros to become the European leader in group travel</NuxtLink>,
                        <span class="text-neutral-300">Forbes, April 27, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">How to hire an external CEO</NuxtLink>,
                        <span class="text-neutral-300">Sifted, April 27, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">TOP 100: Europe’s most influential women in the startup and venture capital space</NuxtLink>,
                        <span class="text-neutral-300">EU Startup, March 8, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Anything but plane: WeRoad’s launches OOH campaign</NuxtLink>,
                        <span class="text-neutral-300">Travel Daily, March 2, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Tour Operators Up Offerings for Solo Travelers</NuxtLink>,
                        <span class="text-neutral-300">Skift, January 17, 2023</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">The WeRoad Journey: Connecting people, culture and stories</NuxtLink>,
                        <span class="text-neutral-300">EU Startup, August 24, 2022</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">Q&amp;A: WeRoad CEO on Booking.com, rapid growth and automation</NuxtLink>,
                        <span class="text-neutral-300">PhocusWire, August 5, 2022</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">WeRoad aims for the UK</NuxtLink>,
                        <span class="text-neutral-300">La Repubblica, April 10, 2021</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">How Italian Travel Startup WeRoad Plans to Grow in Europe</NuxtLink>,
                        <span class="text-neutral-300">Business Insider, Nov 10, 2021</span>
                    </div>
                </li>
                <li class="flex gap-3">
                    <span class="mt-[9px] inline-block w-1.5 h-1.5 rounded-full border border-neutral-500"></span>
                    <div>
                        <a href="#" class="italic hover:underline">The 28 Italian startups to watch, according to VCs</NuxtLink>,
                        <span class="text-neutral-300">Sifted, April 8, 2021</span>
                    </div>
                </li>
            </ul>
        </div>
    </section>
  </div>
</template>
