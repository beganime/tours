<!-- // Generated from project/áΣ¬∞ε/brdcrmps-srch.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Breadcrumb + Search (Responsive)", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://unpkg.com/lucide@latest"}, {"src": "/inline/brdcrmps-srch-1.js", "defer": true}] });
</script>

<template>
  <div>
<section class="text-gray-700">
        <div class="w-full flex flex-col md:flex-row md:items-center md:justify-between gap-3 px-4 md:px-8 py-4">
            <!-- Breadcrumb -->
            <nav class="flex flex-wrap items-center text-sm text-[#4b89a1] space-x-1">
                <a href="#" class="hover:underline">WeRoad Travel</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">General Informations</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">How WeRoad works</NuxtLink>
            </nav>
            <!-- Search -->
            <div class="relative w-full md:w-[300px] lg:w-[350px]">
                <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" placeholder="Search" class="border border-gray-300 rounded-md pl-9 pr-3 py-1.5 text-md w-full focus:ring-1 focus:ring-gray-400 focus:outline-none" />
            </div>
        </div>
    </section>
  </div>
</template>
