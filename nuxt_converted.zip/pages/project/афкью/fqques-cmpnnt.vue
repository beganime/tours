<!-- // Generated from project/áΣ¬∞ε/fqques-cmpnnt.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "How WeRoad Works", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="flex justify-center py-16">
        <div class="w-full max-w-3xl px-6">
            <h2 class="text-2xl font-bold mb-6">How WeRoad works</h2>
            <div class="border-t border-gray-200 divide-y divide-gray-200">
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What is WeRoad?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How can I get in touch with WeRoad?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Who is WeRoad for? What type of travellers are WeRoaders?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Are there any age restrictions?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What does it mean to “be a WeRoader”?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How is a group made up in average?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Can I see who’s in the group before I book the trip?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How long does a WeRoad tour last?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How often do tours depart?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Who is and what does the Travel Coordinator do?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How can I stay up to date about new destinations, offers and get inspiration?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How can I be part of the community?
                </button>
            </div>
        </div>
    </section>
  </div>
</template>
