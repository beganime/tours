<!-- // Generated from project/áΣ¬∞ε/shablons-of-faqs/Flightsandtransfers.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Document", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://unpkg.com/lucide@latest"}, {"src": "/inline/Flightsandtransfers-1.js", "defer": true}] });
</script>

<template>
  <div>
<section class="text-gray-700">
        <div class="w-full flex flex-col md:flex-row md:items-center md:justify-between gap-3 px-4 md:px-8 py-4">
            <!-- Breadcrumb -->
            <nav class="flex flex-wrap items-center text-sm text-[#4b89a1] space-x-1">
                <a href="#" class="hover:underline">WeRoad Travel</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">General Informations</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">Flights and transfers</NuxtLink>
            </nav>
            <!-- Search -->
            <div class="relative w-full md:w-[300px] lg:w-[350px]">
                <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" placeholder="Search" class="border border-gray-300 rounded-md pl-9 pr-3 py-1.5 text-md w-full focus:ring-1 focus:ring-gray-400 focus:outline-none" />
            </div>
        </div>
    </section>
    <section class="flex justify-center py-16">
        <div class="w-full max-w-3xl px-6">
            <h2 class="text-2xl font-bold mb-6">Flights and transfers</h2>
            <div class="border-t border-gray-200 divide-y divide-gray-200">
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Can you help me buying flights?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Is the flight included?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    When should I book my flights?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                  Which flight should I book?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Can I find out my travel groups' flights?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    My flight has been delayed/changed/cancelled, or I cannot board my flight, what should I do?
                </button>
                
            </div>
        </div>
    </section>
  </div>
</template>
