<!-- // Generated from project/áΣ¬∞ε/shablons-of-faqs/Itinerariesanddepartures.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Document", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://unpkg.com/lucide@latest"}, {"src": "/inline/Itinerariesanddepartures-1.js", "defer": true}] });
</script>

<template>
  <div>
<section class="text-gray-700">
        <div class="w-full flex flex-col md:flex-row md:items-center md:justify-between gap-3 px-4 md:px-8 py-4">
            <!-- Breadcrumb -->
            <nav class="flex flex-wrap items-center text-sm text-[#4b89a1] space-x-1">
                <a href="#" class="hover:underline">WeRoad Travel</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">General Informations</NuxtLink>
                <span class="text-gray-400">&gt;</span>
                <a href="#" class="hover:underline">Itineraries and departures</NuxtLink>
            </nav>
            <!-- Search -->
            <div class="relative w-full md:w-[300px] lg:w-[350px]">
                <i data-lucide="search" class="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input type="text" placeholder="Search" class="border border-gray-300 rounded-md pl-9 pr-3 py-1.5 text-md w-full focus:ring-1 focus:ring-gray-400 focus:outline-none" />
            </div>
        </div>
    </section>
    <section class="flex justify-center py-16">
        <div class="w-full max-w-3xl px-6">
            <h2 class="text-2xl font-bold mb-6">Itineraries and departures</h2>
            <div class="border-t border-gray-200 divide-y divide-gray-200">
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What does the WeRoad package include?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What type of accommodation should I expect on your trips?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    When is a tour confirmed?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What is a trip type?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What does "planned" mean?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What does "almost confirmed" mean?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What does "on request" mean?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    How can I be informed about tours, dates and status updates?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    If a location is mentioned, is it guaranteed that we’ll spend the night there?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Will I share the room?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Can I book a private room?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    Can prices change?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    May I book a private WeRoad?
                </button>
                <button class="w-full text-left py-3 text-sm md:text-base font-medium hover:text-[#1b7a72] focus:outline-none">
                    What happens when there are multiple groups departing on the same day for the same trip?
                </button>
            </div>
        </div>
    </section>
  </div>
</template>
