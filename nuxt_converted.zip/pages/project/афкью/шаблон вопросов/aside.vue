<!-- // Generated from project/áΣ¬∞ε/Φáí½«¡ ó«»α«ß«ó/aside.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Articles in this section", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/aside-1.js", "defer": true}] });
</script>

<template>
  <div>
<aside class="w-full max-w-md border-t border-b border-gray-200">
        <!-- Header (mobile view collapsible) -->
        <button id="toggleButton" class="w-full flex justify-between items-center py-3 px-2 md:hidden">
            <span class="text-[15px] font-semibold text-gray-900">Articles in this section</span>
            <svg id="arrowIcon" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-gray-600 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
        </button>
        <!-- Desktop heading -->
        <h3 class="hidden md:block text-[15px] font-semibold text-gray-900 mb-3 mt-3 px-2">
            Articles in this section
        </h3>
        <!-- Links list -->
        <ul id="articlesList" class="overflow-hidden max-h-0 md:max-h-none md:block transition-max text-[15px] leading-snug">
            <li>
                <a href="#" class="block bg-[#5E9DA4] text-white font-medium rounded px-3 py-2">
                    How can I be part of your team?
                </NuxtLink>
            </li>
            <li>
                <a href="#" class="block text-gray-900 hover:underline px-3 py-2">
                    How to become a Travel Coordinator?
                </NuxtLink>
            </li>
            <li>
                <a href="#" class="block text-gray-900 hover:underline px-3 py-2">
                    How can I become a partner?
                </NuxtLink>
            </li>
        </ul>
    </aside>
  </div>
</template>
