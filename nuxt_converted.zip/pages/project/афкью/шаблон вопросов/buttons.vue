<!-- // Generated from project/áΣ¬∞ε/Φáí½«¡ ó«»α«ß«ó/buttons.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Was this article helpful?", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="text-gray-800  border-b border-t border-gray-400">
        <section class="flex flex-col items-center justify-center py-20">
            <p class="text-sm text-gray-800 font-medium mb-4">Was this article helpful?</p>
            <div class="flex items-center space-x-3 mb-3">
                <button class="flex items-center space-x-1 border border-[#1b7a72] text-[#1b7a72] hover:bg-[#eaf5f3] px-4 py-1.5 rounded text-sm transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 00-1.414 0L8 12.586 4.707 9.293A1 1 0 103.293 10.707l4 4a1 1 0 001.414 0l8-8a1 1 0 000-1.414z" clip-rule="evenodd" />
                    </svg>
                    <span>Yes</span>
                </button>
                <button class="flex items-center space-x-1 border border-gray-400 text-gray-700 hover:bg-gray-50 px-4 py-1.5 rounded text-sm transition">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd" d="M10 8.586l3.95-3.95a1 1 0 111.414 1.414L11.414 10l3.95 3.95a1 1 0 11-1.414 1.414L10 11.414l-3.95 3.95a1 1 0 11-1.414-1.414L8.586 10l-3.95-3.95A1 1 0 116.05 4.636L10 8.586z" clip-rule="evenodd" />
                    </svg>
                    <span>No</span>
                </button>
            </div>
            <p class="text-xs text-gray-600">1 out of 1 found this helpful</p>
        </section>
    </section>
  </div>
</template>
