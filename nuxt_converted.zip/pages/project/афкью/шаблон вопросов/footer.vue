<!-- // Generated from project/áΣ¬∞ε/Φáí½«¡ ó«»α«ß«ó/footer.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Recently viewed & Related articles", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 pt-6">
        <!-- Recently viewed -->
        <div>
            <h3 class="text-sm font-semibold text-gray-900 mb-5">Recently viewed articles</h3>
            <ul class="space-y-5 text-sm text-[#1b7a72]">
                <li><a href="#" class="hover:underline">What is WeRoad?</NuxtLink></li>
                <li><a href="#" class="hover:underline">How can I get in touch with WeRoad?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Who is WeRoad for? What type of travellers are WeRoaders?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Can I see who’s in the group before I book the trip?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Are there any age restrictions?</NuxtLink></li>
            </ul>
        </div>
        <!-- Related -->
        <div>
            <h3 class="text-sm font-semibold text-gray-900 mb-5">Related articles</h3>
            <ul class="space-y-5 text-sm text-[#1b7a72]">
                <li><a href="#" class="hover:underline">How to become a Travel Coordinator?</NuxtLink></li>
                <li><a href="#" class="hover:underline">How can I become a partner?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Why do I have to travel with a backpack?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Is the flight included?</NuxtLink></li>
                <li><a href="#" class="hover:underline">Are there any age restrictions?</NuxtLink></li>
            </ul>
        </div>
    </section>
  </div>
</template>
