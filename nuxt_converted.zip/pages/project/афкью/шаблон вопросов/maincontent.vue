<!-- // Generated from project/áΣ¬∞ε/Φáí½«¡ ó«»α«ß«ó/maincontent.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "How can I be part of your team?", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<main class="max-w-sm md:max-w-full mx-auto md:mr-10 p-8 color[#111827]">
        <!-- Заголовок -->
        <h1 class="text-2xl font-extrabold text-gray-900 mb-3 leading-snug">
            How can I be<br>part of your team?
        </h1>
        <!-- Автор и дата -->
        <div class="flex items-center flex-col md:flex-row space-x-2 text-sm text-gray-600 mb-5">
            <img src="https://weroadsupport.zendesk.com/system/photos/1900054122254/wr_logo.png" alt="WeRoad logo" class="w-6 h-6 object-contain rounded-full" />
            <span class="font-medium text-gray-800">WeRoad</span>
            <span>8 months ago</span>
            <span>Updated</span>
        </div>
        <!-- Контент -->
        <div class="space-y-4 text-[15px] leading-relaxed">
            <p>
                We are present in 6 European cities:
                <span class="font-medium">Milan, our HQ, Paris, London, Madrid, Berlin and Chiasso in Switzerland.</span>
            </p>
            <p>
                You can find all our open positions, always up to date, here:<br>
                <a href="https://career.weroad.travel/" target="_blank" class="text-[#1b7a72] break-words hover:underline">
                    https://career.weroad.travel/
                </NuxtLink>, and if you want to be part of our (incredible) team, follow the application process – we wish you the best of luck!
            </p>
            <p>
                If you work in tech... join our Monkeys!<br>
                Take a look at this page:<br>
                <a href="https://monkeys.weroad.io/" target="_blank" class="text-[#1b7a72] break-words hover:underline">
                    https://monkeys.weroad.io/
                </NuxtLink>
            </p>
        </div>
        <!-- Соцсети -->
        <div class="flex items-center space-x-5 mt-6 border-b border-gray-200 pb-4 justify-start">
            <a href="#" aria-label="Facebook" class="text-gray-600 hover:text-[#1b7a72]">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22 12.07C22 6.48 17.52 2 11.93 2S1.86 6.48 1.86 12.07C1.86 17.11 5.69 21.26 10.5 22v-7.03H7.9v-2.9h2.6V9.94c0-2.57 1.54-3.99 3.9-3.99 1.13 0 2.31.2 2.31.2v2.54h-1.3c-1.28 0-1.67.8-1.67 1.62v1.94h2.83l-.45 2.9h-2.38V22c4.81-.74 8.64-4.89 8.64-9.93z" />
                </svg>
            </NuxtLink>
            <a href="#" aria-label="Twitter" class="text-gray-600 hover:text-[#1b7a72]">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M22.46 6.11c-.77.35-1.6.58-2.46.69a4.27 4.27 0 001.88-2.37 8.61 8.61 0 01-2.7 1.03 4.25 4.25 0 00-7.24 3.87A12.05 12.05 0 013 4.8a4.25 4.25 0 001.32 5.67 4.22 4.22 0 01-1.92-.53v.05a4.25 4.25 0 003.41 4.17 4.27 4.27 0 01-1.91.07 4.25 4.25 0 003.96 2.94A8.53 8.53 0 012 19.54a12.02 12.02 0 006.52 1.91c7.82 0 12.09-6.48 12.09-12.1 0-.18 0-.35-.01-.53a8.63 8.63 0 002.13-2.2z" />
                </svg>
            </NuxtLink>
            <a href="#" aria-label="LinkedIn" class="text-gray-600 hover:text-[#1b7a72]">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M20.45 20.45h-3.56v-5.24c0-1.25-.02-2.85-1.74-2.85-1.75 0-2.02 1.36-2.02 2.76v5.33h-3.56V9h3.42v1.56h.05a3.75 3.75 0 013.37-1.85c3.6 0 4.26 2.37 4.26 5.44v6.3zM5.34 7.43a2.06 2.06 0 110-4.12 2.06 2.06 0 010 4.12zM7.12 20.45H3.56V9h3.56v11.45zM22.22 0H1.78C.8 0 0 .8 0 1.78v20.44C0 23.2.8 24 1.78 24h20.44c.98 0 1.78-.8 1.78-1.78V1.78C24 .8 23.2 0 22.22 0z" />
                </svg>
            </NuxtLink>
        </div>
    </main>
  </div>
</template>
