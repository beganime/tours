<!-- // Generated from project/½¿τ¡δ⌐ ¬áí¿¡ÑΓ/index1.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0420\u0430\u0441\u0441\u043a\u0430\u0436\u0438\u0442\u0435 \u0432\u0430\u0448\u0435\u0439 \u0433\u0440\u0443\u043f\u043f\u0435 \u043e \u0441\u0435\u0431\u0435 \u2014 \u041a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<main class="min-h-screen flex items-start justify-center px-4 py-10 sm:py-14">
        <section class="w-full max-w-4xl">
            <!-- Заголовок страницы -->
            <h1 class="text-center font-extrabold tracking-tight" style="color:var(--purple); font-size:clamp(26px,4.5vw,32px);">
                Расскажите вашей группе о себе
            </h1>
            <p class="mt-2 text-center text-sm sm:text-base" style="color:var(--muted);">
                Заполните анкету и узнайте больше о тех, кто поедет вместе с вами
            </p>
            <!-- Карточка всей анкеты -->
            <div class="card mt-6 p-5 sm:p-6">
                <!-- Я живу в -->
                <div class="space-y-2">
                    <label for="city" class="block text-[15px] font-semibold">Я живу в:</label>
                    <div class="relative">
                        <span class="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M12 21s-7-4.5-7-10a7 7 0 1114 0c0 5.5-7 10-7 10z" />
                                <circle cx="12" cy="11" r="2.8" />
                            </svg>
                        </span>
                        <input id="city" type="text" class="field w-full rounded-md pl-10 pr-3 py-2.5 text-[15px]" placeholder="Москва, Российская Федерация" />
                    </div>
                </div>
                <!-- Мне интересно -->
                <div class="mt-6">
                    <p class="text-[15px] font-semibold mb-3">Мне интересно:</p>
                    <div class="flex flex-wrap chips-wrap">
                        <input id="c-fish" class="chip-input" type="checkbox"><label class="chip" for="c-fish">Рыбалка</label>
                        <input id="c-med" class="chip-input" type="checkbox"><label class="chip" for="c-med">Медитация</label>
                        <input id="c-auto" class="chip-input" type="checkbox"><label class="chip" for="c-auto">Автопутешествия</label>
                        <input id="c-extreme" class="chip-input" type="checkbox"><label class="chip" for="c-extreme">Экстрим</label>
                        <input id="c-hike" class="chip-input" type="checkbox"><label class="chip" for="c-hike">Походы</label>
                        <input id="c-self" class="chip-input" type="checkbox"><label class="chip" for="c-self">Саморазвитие</label>
                        <input id="c-sport" class="chip-input" type="checkbox"><label class="chip" for="c-sport">Спорт</label>
                        <input id="c-lang" class="chip-input" type="checkbox"><label class="chip" for="c-lang">Иностранные языки</label>
                        <input id="c-history" class="chip-input" type="checkbox"><label class="chip" for="c-history">История</label>
                        <input id="c-art" class="chip-input" type="checkbox"><label class="chip" for="c-art">Искусство</label>
                        <input id="c-shop" class="chip-input" type="checkbox"><label class="chip" for="c-shop">Шоппинг</label>
                        <input id="c-bars" class="chip-input" type="checkbox"><label class="chip" for="c-bars">Бары и рестораны</label>
                        <input id="c-sea" class="chip-input" type="checkbox"><label class="chip" for="c-sea">Море и пляж</label>
                        <input id="c-photo" class="chip-input" type="checkbox"><label class="chip" for="c-photo">Фото- и видеосъёмка</label>
                        <input id="c-nature" class="chip-input" type="checkbox"><label class="chip" for="c-nature">Природа и парки</label>
                        <input id="c-kids" class="chip-input" type="checkbox"><label class="chip" for="c-kids">Путешествия с детьми</label>
                        <input id="c-sail" class="chip-input" type="checkbox"><label class="chip" for="c-sail">Путешествия под парусом</label>
                        <input id="c-food" class="chip-input" type="checkbox"><label class="chip" for="c-food">Гастрономия</label>
                        <input id="c-ind" class="chip-input" type="checkbox"><label class="chip" for="c-ind">Индастриал</label>
                        <input id="c-museums" class="chip-input" type="checkbox"><label class="chip" for="c-museums">Музеи</label>
                        <input id="c-slums" class="chip-input" type="checkbox"><label class="chip" for="c-slums">Трущобы</label>
                        <input id="c-loft" class="chip-input" type="checkbox"><label class="chip" for="c-loft">Лофты</label>
                    </div>
                </div>
                <!-- Я путешествую -->
                <div class="mt-8">
                    <p class="text-[15px] font-semibold mb-3">Я путешествую:</p>
                    <div class="grid grid-cols-2 gap-2.5 sm:max-w-xl">
                        <input id="t-1" class="chip-input" type="radio" name="travel_freq"><label class="chip" for="t-1">Один раз в месяц</label>
                        <input id="t-2" class="chip-input" type="radio" name="travel_freq"><label class="chip" for="t-2">Несколько раз в год</label>
                        <input id="t-3" class="chip-input" type="radio" name="travel_freq"><label class="chip" for="t-3">Один раз в год</label>
                        <input id="t-4" class="chip-input" type="radio" name="travel_freq"><label class="chip" for="t-4">Реже одного раза в год</label>
                    </div>
                </div>
                <!-- Ожидания -->
                <div class="mt-8">
                    <p class="text-[15px] font-semibold mb-3">От этого путешествия я жду:</p>
                    <div class="flex flex-col gap-2.5 sm:max-w-2xl">
                        <input id="e-1" class="chip-input" type="checkbox"><label class="chip chip-wide" for="e-1">Активный отдых, не хочу лежать на шезлонге</label>
                        <input id="e-2" class="chip-input" type="checkbox"><label class="chip chip-wide" for="e-2">Хочу лежать на шезлонге, не хочу никуда бежать</label>
                        <input id="e-3" class="chip-input" type="checkbox"><label class="chip chip-wide" for="e-3">Компания единомышленников по возрасту и интересам</label>
                        <input id="e-4" class="chip-input" type="checkbox"><label class="chip chip-wide" for="e-4">Насыщенный маршрут, чтобы посмотреть много нового</label>
                    </div>
                </div>
                <!-- ▲▲▲ КОНЕЦ НОВОГО БЛОКА ▲▲▲ -->
                <!-- ▼▼▼ НОВЫЙ БЛОК СО СКРИНА ▼▼▼ -->
                <div class="mt-8 grid gap-5 ">
                    <div>
                        <label for="f-like" class="block text-[15px] font-semibold mb-1.5">Я люблю:</label>
                        <input id="f-like" type="text" class="field w-full rounded-md px-3 py-2.5" placeholder="">
                    </div>
                    <div>
                        <label for="f-super" class="block text-[15px] font-semibold mb-1.5">Моя суперсила:</label>
                        <input id="f-super" type="text" class="field w-full rounded-md px-3 py-2.5" placeholder="">
                    </div>
                    <div>
                        <label for="f-want" class="block text-[15px] font-semibold mb-1.5">В путешествии я хочу:</label>
                        <input id="f-want" type="text" class="field w-full rounded-md px-3 py-2.5" placeholder="">
                    </div>
                    <div>
                        <p class="text-[15px] font-semibold mb-1.5">Честно говоря, я</p>
                        <div class="flex justify-between text-xs text-gray-500 mb-2">
                            <span>Интроверт</span>
                            <span>Экстраверт</span>
                        </div>
                        <input type="range" min="0" max="100" value="35" class="range" aria-label="Интроверт — Экстраверт">
                    </div>
                    <div>
                        <label for="f-dislike" class="block text-[15px] font-semibold mb-1.5">Больше всего в путешествии я не люблю:</label>
                        <input id="f-dislike" type="text" class="field w-full rounded-md px-3 py-2.5" placeholder="">
                    </div>
                    <div>
                        <label for="f-expect" class="block text-[15px] font-semibold mb-1.5">Больше всего в путешествии я жду:</label>
                        <input id="f-expect" type="text" class="field w-full rounded-md px-3 py-2.5" placeholder="">
                    </div>
                </div>
                <div class="pt-2">
                    <button type="button" class="w-full rounded-md px-8 py-3 font-bold text-white" style="background:var(--cta);">СОХРАНИТЬ</button>
                </div>
            </div>
        </section>
    </main>
  </div>
</template>
