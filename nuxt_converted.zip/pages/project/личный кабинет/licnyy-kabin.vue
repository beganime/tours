<!-- // Generated from project/½¿τ¡δ⌐ ¬áí¿¡ÑΓ/licnyy-kabin.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0410\u043a\u043a\u0430\u0443\u043d\u0442 \u2014 \u043a\u043e\u043c\u043f\u043e\u043d\u0435\u043d\u0442", link: [{"rel": "preconnect", "href": "https://fonts.googleapis.com"}, {"rel": "preconnect", "href": "https://fonts.gstatic.com", "crossorigin": null}, {"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="max-w-5xl mx-auto px-4 sm:px-6 md:px-8 py-6">
        <!-- Заголовок и пользователь -->
        <h1 class="text-2xl font-extrabold tracking-tight text-[color:var(--brand)]">
            Аккаунт
        </h1>
        <p class="mt-2 text-sm text-gray-500">
            Артём Губин, gubinartem433@gmail.com
        </p>
        <!-- Метрики -->
        <div class="mt-8 grid grid-cols-2 gap-6">
            <!-- Количество путешествий -->
            <div class="text-center">
                <div class="text-xl font-semibold text-[color:var(--brand)]">0</div>
                <div class="mt-2 text-sm text-gray-600">Количество путешествий</div>
            </div>
            <!-- Количество стран -->
            <div class="text-center">
                <div class="text-xl font-semibold text-[color:var(--brand)]">0</div>
                <div class="mt-2 text-sm text-gray-600">Количество стран</div>
            </div>
        </div>
        <!-- Разделительная линия -->
        <div class="mt-6 border-t border-gray-200"></div>
    </section>
    <section class="text-gray-800 max-w-5xl mx-auto">
        <main class="px-4 sm:px-6 md:px-8 py-8">
            <div class="max-w-5xl mx-auto">
                <!-- Карточка -->
                <section class="bg-white border border-gray-200 rounded-xl shadow-[0_6px_22px_rgba(0,0,0,0.08)]">
                    <div class="p-5 sm:p-6">
                        <h2 class="text-[17px] sm:text-lg font-extrabold text-gray-800 mb-2">
                            Индивидуальный формат путешествий своей компанией!
                        </h2>
                        <p class="text-gray-600 text-sm leading-relaxed max-w-4xl">
                            Если вы хотите отправиться в авторский тур только своей семьёй, компанией друзей
                            или единомышленников по уникальной программе, заполните заявку, и наши проверенные
                            тревел-эксперты подготовят предложение специально для вас.
                        </p>
                        <button class="mt-4 inline-flex items-center rounded-md bg-[color:var(--brand1)] px-4 py-2 text-xs font-extrabold uppercase tracking-wide text-white hover:brightness-95 active:brightness-90 focus:outline-none focus:ring-2 focus:ring-[color:var(--brand)]/40">
                            Заполнить заявку
                        </button>
                    </div>
                </section>
            </div>
        </main>
    </section>
    <section class="text-gray-800">
        <main class="px-4 sm:px-6 md:px-8 py-8 max-w-5xl mx-auto">
            <div class="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-5">
                <!-- Card 1 -->
                <article class="bg-white border border-gray-200 rounded-xl shadow-[0_6px_22px_rgba(0,0,0,0.06)] p-5">
                    <div class="flex items-start gap-3">
                        <!-- orange x icon -->
                        <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-orange-50 border border-orange-200">
                            <svg viewBox="0 0 20 20" class="w-3.5 h-3.5 text-orange-500" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
                                <path d="M5 5 L15 15M15 5 L5 15"></path>
                            </svg>
                        </span>
                        <div>
                            <h3 class="font-extrabold text-[15px] leading-5">1. Заполните<br class="md:hidden"> профиль</h3>
                            <p class="mt-3 text-sm text-gray-600 leading-6">
                                Предоставьте<br> личные и<br> контактные данные.
                            </p>
                        </div>
                    </div>
                </article>
                <!-- Card 2 -->
                <article class="bg-white border border-gray-200 rounded-xl shadow-[0_6px_22px_rgba(0,0,0,0.06)] p-5">
                    <div class="flex items-start gap-3">
                        <!-- green check icon -->
                        <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-lime-50 border border-lime-200">
                            <svg viewBox="0 0 20 20" class="w-3.5 h-3.5" fill="none" stroke-width="2" stroke-linecap="round" stroke="var(--green)">
                                <path d="M4.5 10.5l3.5 3.5L15.5 6.5"></path>
                            </svg>
                        </span>
                        <div>
                            <h3 class="font-extrabold text-[15px] leading-5">4. Привязать<br class="md:hidden"> мессенджеры</h3>
                            <p class="mt-3 text-sm text-gray-600 leading-6">
                                Подключите<br> удобный канал<br> получения<br> уведомлений.
                                Уведомления<br> приходят, когда вам<br> написали в чат.
                            </p>
                        </div>
                    </div>
                </article>
                <!-- Card 3 -->
                <article class="bg-white border border-gray-200 rounded-xl shadow-[0_6px_22px_rgba(0,0,0,0.06)] p-5">
                    <div class="flex items-start gap-3">
                        <!-- empty circle -->
                        <span class="inline-flex w-5 h-5 rounded-full border border-gray-300"></span>
                        <div>
                            <h3 class="font-extrabold text-[15px] leading-5">
                                9. Остались<br class="md:hidden"> вопросы —<br> напишите в чат<br> поддержки
                            </h3>
                            <p class="mt-3 text-sm leading-6">
                                <a href="#" class="text-[color:var(--brand)] hover:underline">Написать в чат</NuxtLink>
                            </p>
                        </div>
                    </div>
                </article>
            </div>
        </main>
    </section>
  </div>
</template>
