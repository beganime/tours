<!-- // Generated from project/α¡1/add-multi-day-tour-page/create-tour.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Create tour \u2014 exact visual clone", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://unpkg.com/lucide@latest"}, {"src": "/inline/create-tour-1.js", "defer": true}, {"src": "/inline/create-tour-2.js", "defer": true}] });
</script>

<template>
  <div>
<!-- Header -->
	<header class="pt-6">
		<div class="max-w-4xl mx-auto px-4 flex items-center justify-between">
			<h1 class="text-[22px] font-semibold">Create tour</h1>

			<div class="flex items-center gap-2">
				<span class="text-sm text-subtext">Description language:</span>
				<button
					class="inline-flex items-center gap-2 border border-border rounded-full bg-white px-3 py-1.5 text-sm shadow-sm hover:bg-gray-50">
					<i data-lucide="languages" class="w-4 h-4 text-gray-600"></i>
					<span>Russian</span>
					<i data-lucide="chevron-down" class="w-4 h-4 text-gray-600"></i>
				</button>
			</div>
		</div>
	</header>

	<!-- Main -->
	<main class="max-w-4xl mx-auto px-4 pt-6">
		<section class="rounded-card border border-border bg-card shadow-smooth">
			<div class="px-6 py-4 border-b border-border">
				<h2 class="text-lg font-semibold">General settings</h2>
			</div>

			<div class="p-6 space-y-6">

				<!-- Hide from catalog -->
				<div class="border border-border rounded-lg bg-white px-4 py-3.5 flex items-center justify-between">
					<div class="flex items-start gap-3">
						<div class="h-6 w-6 flex items-center justify-center rounded-md bg-gray-100 text-gray-600">
							<i data-lucide="eye-off" class="w-[18px] h-[18px]"></i>
						</div>
						<div>
							<p class="font-medium text-[15px]">Hide from catalog (access by link only)</p>
							<p class="text-[13px] text-gray-500 mt-0.5">
								The tour can be booked via the link, but cannot be found in the catalog
							</p>
						</div>
					</div>

					<!-- Toggle -->
					<div class="flex-shrink-0">
						<input id="hideToggle" type="checkbox" class="sr-only peer" />
						<label for="hideToggle" class="relative inline-flex items-center h-5 w-9 cursor-pointer rounded-full bg-toggle transition
                   after:absolute after:h-4 after:w-4 after:bg-white after:rounded-full after:top-[2px] after:left-[2px] after:shadow after:transition-all
                   peer-checked:bg-emerald-500 peer-checked:after:translate-x-4">
						</label>
					</div>
				</div>

				<!-- Input: Name -->
				<div>
					<label class="block text-sm font-medium mb-1.5">Name (from 2 words)<span
							class="text-rose-500">*</span></label>
					<div class="relative">
						<input type="text"
							class="w-full rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 text-sm placeholder:text-gray-400 focus:ring-2 focus:ring-indigo-100 focus:bg-white outline-none" />
						<i data-lucide="info" class="w-4 h-4 absolute right-3 top-2.5 text-gray-400"></i>
					</div>
				</div>

				<!-- Row 1: main / additional types -->
				<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
					<div>
						<label class="block text-sm font-medium mb-1.5">Main tour type<span class="text-rose-500">*</span></label>
						<button
							class="flex items-center justify-between w-full rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 text-left text-sm hover:bg-gray-100">
							<span class="text-gray-400">Select…</span>
							<i data-lucide="chevron-down" class="w-4 h-4 text-gray-400"></i>
						</button>
					</div>
					<div>
						<label class="block text-sm font-medium mb-1.5">Additional types (up to 3)</label>
						<!-- === КОМПОНЕНТ Additional types (up to 3) === -->
						<div class="relative w-full md:w-[420px]">
							<!-- Кнопка/контейнер селекта -->
							<button id="typesBtn" type="button"
								class="w-full text-left rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 hover:bg-gray-100 transition">
								<div class="flex items-start justify-between gap-2">
									<div class="flex-1">
										<!-- Лейбл сверху (маленький серый) -->
										<div class="text-[12px] leading-4 text-gray-500">
											Additional types (up to 3)
										</div>
										<!-- Строка выбранных значений -->
										<div id="typesSummary" class="mt-0.5 text-[14px] leading-5 text-indigo-600">
											<!-- По умолчанию пусто; JS подставит "Select…" серым либо список -->
										</div>
									</div>
									<i data-lucide="chevron-down" class="w-4 h-4 mt-1 text-gray-500"></i>
								</div>
							</button>
						
							<!-- Выпадающее меню -->
							<div id="typesMenu"
								class="hidden absolute z-20 mt-1 w-full rounded-lg border border-border bg-white shadow-lg overflow-y-auto scrollbar-hide max-h-56">
								<ul class="py-2 text-sm text-gray-800">
									<!-- Опции -->
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Автотур" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Автотур</span></label></li>
						
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Авторский" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Авторский</span></label></li>
						
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Поход" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Поход</span></label></li>
						
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Винный" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Винный</span></label></li>
						
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Гастрономический" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Гастрономический</span></label></li>
						
									<li><label class="flex items-center px-3 py-2 hover:bg-gray-50 cursor-pointer">
											<input value="Фототур" type="checkbox"
												class="typesOpt w-4 h-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500">
											<span class="ml-3">Фототур</span></label></li>
								</ul>
							</div>
						</div>
						<!-- === /КОМПОНЕНТ === -->
					</div>
				</div>

				<!-- Row 2: countries / regions -->
				<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
					<div>
						<label class="block text-sm font-medium mb-1.5">Country(ies) of the tour<span
								class="text-rose-500">*</span></label>
						<button
							class="flex items-center justify-between w-full rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 text-left text-sm hover:bg-gray-100">
							<span class="text-gray-400">Select…</span>
							<i data-lucide="chevron-down" class="w-4 h-4 text-gray-400"></i>
						</button>
					</div>
					<div>
						<label class="block text-sm font-medium mb-1.5">Regions</label>
						<button
							class="flex items-center justify-between w-full rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 text-left text-sm hover:bg-gray-100">
							<span class="text-gray-400">Select…</span>
							<i data-lucide="chevron-down" class="w-4 h-4 text-gray-400"></i>
						</button>
					</div>
				</div>

				<!-- Languages -->
				<div>
					<label class="block text-sm font-medium mb-1.5">Main languages of the tour<span
							class="text-rose-500">*</span></label>
					<button
						class="flex items-center justify-between w-full rounded-lg border border-border bg-gray-50 px-3.5 py-2.5 text-left text-sm hover:bg-gray-100">
						<span class="text-gray-400">Select…</span>
						<i data-lucide="chevron-down" class="w-4 h-4 text-gray-400"></i>
					</button>
				</div>

			</div>
		</section>
	</main>
  </div>
</template>
