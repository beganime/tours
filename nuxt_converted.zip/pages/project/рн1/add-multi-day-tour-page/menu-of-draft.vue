<!-- // Generated from project/α¡1/add-multi-day-tour-page/menu-of-draft.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Navbar Final Layout with Top Buttons", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://unpkg.com/lucide@latest"}, {"src": "/inline/menu-of-draft-1.js", "defer": true}] });
</script>

<template>
  <div>
<div class="max-w-[1120px] mx-auto px-4 py-4">

		<!-- Контейнер -->
		<div
			class="bg-white rounded-lg shadow-sm px-4 sm:px-5 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">

			<!-- Правая часть (кнопки) — наверху на мобильных -->
			<div
				class="order-1 sm:order-2 flex flex-row flex-wrap justify-center sm:justify-end items-center gap-2 w-full sm:w-auto">
				<button
					class="flex-1 sm:flex-none px-5 py-2.5 bg-gray-200/80 hover:bg-gray-300 text-sm font-semibold text-gray-900 rounded-[14px] shadow-sm transition text-center">
					Save draft
				</button>
				<button
					class="flex-1 sm:flex-none px-6 py-2.5 btn-green text-white text-sm font-semibold rounded-[14px] hover:opacity-95 shadow-sm transition flex items-center justify-center gap-2">
					<span>For moderation</span>
					<i data-lucide="arrow-right" class="hidden sm:block w-4 h-4"></i>
				</button>
			</div>

			<!-- Левая часть (навигация) — снизу на мобильных -->
			<div class="order-2 sm:order-1 flex flex-wrap items-center gap-3">
				<!-- стрелка -->
				<button class="text-gray-500 hover:text-gray-700">
					<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="none" stroke="currentColor"
						stroke-width="2" stroke-linecap="round" stroke-linejoin="round" viewBox="0 0 24 24">
						<path d="M14 2L6 12L14 22"></path>
					</svg>
				</button>

				<!-- (No name) + Draft -->
				<div class="flex items-center gap-2">
					<span class="text-sm font-medium text-gray-800">(No name)</span>
					<span
						class="inline-flex items-center gap-1.5 rounded-md border border-gray-200 bg-white px-2 py-[2px] text-xs text-gray-700 shadow-sm">
						<span class="inline-block w-2 h-2 rounded-full bg-gray-400"></span>
						Draft
					</span>
				</div>

				<!-- разделитель -->
				<span class="text-gray-400 select-none">⋯</span>

				<!-- вкладки -->
				<div class="flex items-end gap-5">
					<button class="relative pb-[6px] text-sm font-medium text-gray-900 leading-none">
						Description
						<span
							class="pointer-events-none absolute left-0 right-0 -bottom-[1px] mx-auto h-[2px] w-16 bg-gray-900 rounded"></span>
					</button>
					<button class="pb-[6px] text-sm font-medium text-gray-400 hover:text-gray-700 leading-none">
						Prices and dates
					</button>
				</div>
			</div>
		</div>
	</div>
  </div>
</template>
