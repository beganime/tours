<!-- // Generated from project/α¡1/alltrips/alltrafric.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Background section -->
	<section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center mb-5"
		style="background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1500&q=80');">

		<!-- Overlay -->
		<div class="absolute inset-0 bg-black/30"></div>

		<!-- Title -->
		<h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
			It's time for Africa!
		</h1>
	</section>
	<section class='text-gray-900'>
		<header class="w-full mx-auto center mb-20">
			<nav class="mx-auto max-w-6xl px-4 py-4 center">
				<ol class="flex items-center gap-2 text-sm text-gray-500 justify-center">
					<!-- home -->
					<li class="flex items-center gap-2">
						<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24"
							stroke="currentColor">
							<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"
								d="m3 10.5 9-7.5 9 7.5M4.5 9.75V21h6v-6h3v6h6V9.75" />
						</svg>
						<span>Destinations</span>
					</li>
					<li class="text-gray-400">></li>
					<li class="text-gray-600">Africa</li>
				</ol>
			</nav>
		</header>

		<!-- Hero / Title block -->
		<main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center">
			<h1 class="text-3xl font-extrabold tracking-tight mb-4">
				All our trips to Africa
			</h1>
			<p class="text-gray-600 leading-relaxed mb-8">
				Get ready for the ultimate safari adventure in South Africa and Tanzania! Roam through the wild heart of Kruger
				National
				Park, where the Big Five roam free, and then jet off to the endless plains of the Serengeti in Tanzania for a
				chance to
				witness the breathtaking Great Migration. These lands promise unforgettable wildlife encounters set against some
				of the
				most dramatic landscapes on the planet. Pack your binoculars and your sense of wonder!
			</p>

		</main>
	</section>
	<section class='flex flex-col items-center justify-center pb-12'>
		<div class="flex flex-wrap justify-center gap-6">

			<!-- Card 1 -->
			<div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
				<div class="relative">
					<img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80"
						alt="Italy coast" class="w-full h-48 object-cover">
					<button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
						<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20"
							fill="currentColor">
							<path
								d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
						</svg>
					</button>
					<div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
					<div
						class="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-lg flex items-center gap-1">
						<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-yellow-400" fill="currentColor"
							viewBox="0 0 20 20">
							<path
								d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.233 3.787a1 1 0 00.95.69h3.992c.969 0 1.371 1.24.588 1.81l-3.232 2.35a1 1 0 00-.364 1.118l1.233 3.787c.3.921-.755 1.688-1.54 1.118l-3.232-2.35a1 1 0 00-1.176 0l-3.232 2.35c-.785.57-1.84-.197-1.54-1.118l1.233-3.787a1 1 0 00-.364-1.118L2.28 9.214c-.783-.57-.38-1.81.588-1.81h3.992a1 1 0 00.95-.69l1.233-3.787z" />
						</svg>
						4.7
					</div>
				</div>
				<div class="p-4">
					<h3 class="font-semibold text-gray-900 text-base mb-1">
						Italy Express: Naples and the Amalfi Coast
					</h3>
					<p class="text-sm text-gray-700">
						From <span class="text-green-600 font-semibold">$637</span>
						<span class="line-through text-gray-400 ml-1">$696</span>
						<span class="text-green-600 font-semibold ml-1">-8%</span>
					</p>
				</div>
			</div>

			<!-- Card 2 -->
			<div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
				<div class="relative">
					<img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80"
						alt="Matterhorn" class="w-full h-48 object-cover">
					<button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
						<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20"
							fill="currentColor">
							<path
								d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
						</svg>
					</button>
					<div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
				</div>
				<div class="p-4">
					<h3 class="font-semibold text-gray-900 text-base mb-1">
						Matterhorn: snow adventures in Cervinia and Zermatt
					</h3>
					<p class="text-sm text-gray-700">
						From <span class="text-gray-900 font-semibold">$1,118</span>
					</p>
				</div>
			</div>

		</div>
	</section>

	<section class='flex items-center justify-center min-h-screen px-4'>
		<section class="max-w-3xl">
			<h2 class="text-2xl md:text-3xl font-extrabold text-gray-900 leading-snug mb-4">
				"The breath of the landscape was<br>
				immense. Everything gave a sense of<br>
				grandeur, of freedom, of supreme<br>
				nobility."
			</h2>
			<p class="italic text-gray-400 mb-4">Karen Blixen</p>

			<p class="text-gray-600 font-medium text-sm md:text-base leading-relaxed">
				In Africa, everything exudes vastness: the continent itself, spanning over 20% of the Earth's landmass, the
				expansive
				Sahara desert, the world's largest, the meandering Nile River, record-breaking temperatures, and a mosaic of
				dialects
				and cultures thriving among a billion inhabitants. Yet, within this vastness lies a surprising intimacy awaiting
				discovery—one that captivates and enthralls. Despite its sheer scale, Africa beckons with an unexpected sense of
				closeness once you delve into its depths and embrace its multifaceted essence. It stands as the last frontier of
				unparalleled adventure, where grandeur and intimacy intertwine, inviting you to explore and understand its
				unique
				allure.
			</p>
		</section>
	</section>
	<section class='h-full w-full'>
		<img src="https://strapi-imaginary.weroad.it/resource/webp-large/11219/africa-desktop.webp" alt="kartinka">
	</section>
  </div>
</template>
