<!-- // Generated from project/α¡1/alltrips/banner.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Background section -->
	<section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center"
		style="background-image: url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1500&q=80');">

		<!-- Overlay -->
		<div class="absolute inset-0 bg-black/30"></div>

		<!-- Title -->
		<h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
			The old continent
		</h1>
	</section>
  </div>
</template>
