<!-- // Generated from project/α¡1/alltrips/cards.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Travel Cards", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<div class="flex flex-wrap justify-center gap-6">

		<!-- Card 1 -->
		<div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
			<div class="relative">
				<img src="https://images.unsplash.com/photo-1505761671935-60b3a7427bad?auto=format&fit=crop&w=800&q=80"
					alt="Italy coast" class="w-full h-48 object-cover">
				<button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
					<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
						<path
							d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
					</svg>
				</button>
				<div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
				<div
					class="absolute bottom-3 right-3 bg-black/70 text-white text-sm px-2 py-1 rounded-lg flex items-center gap-1">
					<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 text-yellow-400" fill="currentColor"
						viewBox="0 0 20 20">
						<path
							d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.233 3.787a1 1 0 00.95.69h3.992c.969 0 1.371 1.24.588 1.81l-3.232 2.35a1 1 0 00-.364 1.118l1.233 3.787c.3.921-.755 1.688-1.54 1.118l-3.232-2.35a1 1 0 00-1.176 0l-3.232 2.35c-.785.57-1.84-.197-1.54-1.118l1.233-3.787a1 1 0 00-.364-1.118L2.28 9.214c-.783-.57-.38-1.81.588-1.81h3.992a1 1 0 00.95-.69l1.233-3.787z" />
					</svg>
					4.7
				</div>
			</div>
			<div class="p-4">
				<h3 class="font-semibold text-gray-900 text-base mb-1">
					Italy Express: Naples and the Amalfi Coast
				</h3>
				<p class="text-sm text-gray-700">
					From <span class="text-green-600 font-semibold">$637</span>
					<span class="line-through text-gray-400 ml-1">$696</span>
					<span class="text-green-600 font-semibold ml-1">-8%</span>
				</p>
			</div>
		</div>

		<!-- Card 2 -->
		<div class="w-72 bg-white rounded-xl shadow-md overflow-hidden relative">
			<div class="relative">
				<img src="https://images.unsplash.com/photo-1488646953014-85cb44e25828?auto=format&fit=crop&w=800&q=80"
					alt="Matterhorn" class="w-full h-48 object-cover">
				<button class="absolute top-3 right-3 bg-white/80 hover:bg-white rounded-full p-2">
					<svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-gray-700" viewBox="0 0 20 20" fill="currentColor">
						<path
							d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 18.657l-6.828-6.829a4 4 0 010-5.656z" />
					</svg>
				</button>
				<div class="absolute bottom-3 left-3 bg-black/70 text-white text-sm px-3 py-1 rounded-lg">5 days</div>
			</div>
			<div class="p-4">
				<h3 class="font-semibold text-gray-900 text-base mb-1">
					Matterhorn: snow adventures in Cervinia and Zermatt
				</h3>
				<p class="text-sm text-gray-700">
					From <span class="text-gray-900 font-semibold">$1,118</span>
				</p>
			</div>
		</div>

	</div>
  </div>
</template>
