<!-- // Generated from project/α¡1/alltrips/text.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Europe Quote Section", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="max-w-3xl">
		<h2 class="text-2xl md:text-3xl font-extrabold text-gray-900 leading-snug mb-4">
			"Oh old continent! Burdened with years, <br>
			rough, holy, sublime mistress of the <br>
			spirit, who filters perfumes and senses!"
		</h2>
		<p class="italic text-gray-400 mb-4">Dezső Kosztolányi</p>

		<p class="text-gray-700 text-sm md:text-base leading-relaxed">
			It is the cradle of the <span class="font-bold">great ancient civilisations</span>, of empires that sailed in gold
			and fell into the ashes;
			<span class="font-bold">homeland of writers, poets and philosophers</span> who laid the foundations of man's
			thought,
			of <span class="font-bold">artists</span> who influenced the world with their art.
			<span class="font-bold">Center of the Earth for centuries</span>, the great navigators set off from here towards
			the unknown –
			while now it is a popular destination for travellers from all over the globe.
			There are endless stories to listen to and countless hidden views to admire: every road is an adventure, every
			corner a discovery.
		</p>
	</section>
  </div>
</template>
