<!-- // Generated from project/α¡1/page of reg/account.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Account Settings \u2014 Countries via intl-tel-input", link: [{"rel": "stylesheet", "href": "https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/css/intlTelInput.css"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"}, {"src": "https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/intlTelInput.min.js"}, {"src": "https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/utils.js"}, {"src": "/inline/account-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<!-- Вкладки -->
		<div class="bg-white rounded-xl shadow-sm border border-gray-200">
			<nav class="flex gap-6 px-5 sm:px-6 py-3 text-sm">
				<button class="relative font-medium text-gray-900">
					Account
					<span class="absolute left-0 -bottom-3 h-[2px] w-full bg-gray-800 rounded-full"></span>
				</button>
				<button class="text-gray-500 hover:text-gray-800">Profile</button>
				<button class="text-gray-500 hover:text-gray-800">Team</button>
				<button class="text-gray-500 hover:text-gray-800">Notifications</button>
				<button class="text-gray-500 hover:text-gray-800">Legal Data</button>
			</nav>
		</div>

		<!-- Карточка -->
		<section class="mt-5 bg-white rounded-2xl shadow-sm border border-gray-200">
			<div class="px-5 sm:px-6 py-5">
				<h2 class="text-xl font-extrabold">Account</h2>
			</div>
			<div class="px-5 sm:px-6 pb-6 space-y-7">

				<!-- Official name -->
				<div class="border-t border-gray-200 pt-6">
					<div class="flex items-center justify-between">
						<div>
							<div class="text-sm text-gray-500">Official name</div>
							<div id="nameView" class="font-medium">Батыр Рахманов</div>
						</div>
						<button id="nameEditBtn"
							class="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200">
							<iconify-icon icon="mdi:pencil-outline" width="16"></iconify-icon>
							Edit
						</button>
					</div>

					<div id="nameForm" class="mt-3 hidden">
						<div class="text-xs text-gray-500 mb-2">
							The name (without surname) will be visible to travelers. Note that if you work as an individual or
							individual entrepreneur,
							the name and surname must match the account holder for payments.
						</div>
						<div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
							<div>
								<label class="text-xs text-gray-500 block mb-1">Name*</label>
								<input id="firstName"
									class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]"
									value="Батыр" />
							</div>
							<div>
								<label class="text-xs text-gray-500 block mb-1">Surname*</label>
								<input id="lastName"
									class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]"
									value="Рахманов" />
							</div>
						</div>
						<div class="mt-3 flex items-center gap-3">
							<button id="nameSave"
								class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">Save</button>
							<button data-cancel="name" class="cancelBtn text-sm text-gray-500 hover:text-gray-800">Cancel</button>
						</div>
					</div>
				</div>

				<!-- Phone (intl-tel-input) -->
				<div class="border-t border-gray-200 pt-6">
					<div class="flex items-center justify-between">
						<div>
							<div class="text-sm text-gray-500">Phone</div>
							<div id="phoneView" class="font-medium">+7 9** ***-**-**</div>
							<p class="text-xs text-gray-500 mt-1 max-w-3xl">
								Enter the number where you, the main organizer, or someone from the team can be contacted. An SMS will
								be sent to it for confirmation.
							</p>
						</div>
						<button id="phoneEditBtn"
							class="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200">
							<iconify-icon icon="mdi:pencil-outline" width="16"></iconify-icon>
							Edit
						</button>
					</div>

					<!-- Форма телефона -->
					<div id="phoneForm" class="mt-3 hidden">
						<label class="text-xs text-gray-500 block mb-1">Phone</label>
						<input id="phoneField"
							class="w-full max-w-md rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]" />
						<div class="mt-3 flex items-center gap-3">
							<button id="phoneSave"
								class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">Save</button>
							<button data-cancel="phone" class="cancelBtn text-sm text-gray-500 hover:text-gray-800">Cancel</button>
						</div>
					</div>
				</div>

				<!-- Password -->
				<div class="border-t border-gray-200 pt-6">
					<div class="flex items-center justify-between">
						<div>
							<div class="text-sm text-gray-500">Password</div>
							<div class="font-medium">••••••••</div>
						</div>
						<button id="passEditBtn"
							class="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200">
							<iconify-icon icon="mdi:pencil-outline" width="16"></iconify-icon>
							Edit
						</button>
					</div>

					<div id="passForm" class="mt-3 hidden">
						<div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
							<input id="curPass" type="password" placeholder="Current password"
								class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]" />
							<input id="newPass" type="password" placeholder="New password"
								class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]" />
							<input id="newPass2" type="password" placeholder="Confirm new password"
								class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]" />
						</div>
						<div class="mt-3 flex items-center gap-3">
							<button id="passSave"
								class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">Save</button>
							<button data-cancel="pass" class="cancelBtn text-sm text-gray-500 hover:text-gray-800">Cancel</button>
						</div>
					</div>
				</div>

				<!-- Email -->
				<div class="border-t border-gray-200 pt-6">
					<div class="flex items-center justify-between">
						<div>
							<div class="text-sm text-gray-500">Email</div>
							<div id="emailView" class="font-medium">sheker***@gmail.com</div>
						</div>
						<button id="emailEditBtn"
							class="inline-flex items-center gap-2 text-sm px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200">
							<iconify-icon icon="mdi:pencil-outline" width="16"></iconify-icon>
							Edit
						</button>
					</div>

					<div id="emailForm" class="mt-3 hidden">
						<div class="text-xs text-gray-500 mb-2">
							Enter an email that you have permanent access to. A code will be sent to it for confirmation.
						</div>
						<input id="emailInput" type="email" placeholder="Email"
							class="w-full max-w-md rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]" />
						<div class="mt-3 flex items-center gap-3">
							<button id="emailSave"
								class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">Save</button>
							<button data-cancel="email" class="cancelBtn text-sm text-gray-500 hover:text-gray-800">Cancel</button>
						</div>
					</div>
				</div>

				<!-- Deactivate -->
				<div class="border-t border-gray-200 pt-6">
					<button class="text-sm text-red-500 hover:text-red-600">Deactivate account</button>
				</div>
			</div>
		</section>
	</main>
  </div>
</template>
