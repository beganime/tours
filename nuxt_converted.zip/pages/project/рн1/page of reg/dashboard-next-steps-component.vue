<!-- // Generated from project/α¡1/page of reg/dashboard-next-steps-component.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Next Steps \u2014 Perfect UI", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"}] });
</script>

<template>
  <div>
<section class="w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<h2 class="text-2xl font-semibold mb-6">Next steps</h2>

		<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">

			<!-- 1) Specify payment method -->
			<article
				class="relative bg-[#fffffffa] rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col transition duration-300 hover:shadow-md">
				<div
					class="absolute top-4 right-4 flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#abc323] text-white">
					<iconify-icon icon="mdi:currency-rub" width="18" height="18"></iconify-icon>
				</div>

				<h3 class="text-base font-semibold text-gray-800">Specify payment method</h3>
				<p class="mt-2 text-sm text-red-500 font-medium">Check and update data to receive payments</p>

				<div class="mt-6 flex items-center">
					<button type="button"
						class="inline-flex items-center justify-center w-[42px] h-[42px] rounded-full bg-gray-100 text-gray-600 transition duration-200 ease-out hover:bg-[#abc323] hover:text-white hover:scale-105 hover:shadow-[0_3px_8px_rgba(171,195,35,0.4)]"
						aria-label="open">
						<iconify-icon icon="mdi:arrow-right" width="20" height="20"></iconify-icon>
					</button>
				</div>
			</article>

			<!-- 2) Link messengers -->
			<article
				class="relative bg-[#fffffffa] rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col transition duration-300 hover:shadow-md">
				<div class="absolute top-4 right-4 flex items-center gap-2">
					<span class="inline-flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#26A4E3]">
						<iconify-icon icon="simple-icons:telegram" class="text-white" width="18" height="18"></iconify-icon>
					</span>
					<span class="inline-flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#25D366]">
						<iconify-icon icon="simple-icons:whatsapp" class="text-white" width="18" height="18"></iconify-icon>
					</span>
				</div>

				<h3 class="text-base font-semibold text-gray-800">Link messengers</h3>
				<p class="mt-2 text-sm text-gray-500">Do not miss new requests and messages</p>

				<div class="mt-6 flex items-center">
					<button type="button"
						class="inline-flex items-center justify-center w-[42px] h-[42px] rounded-full bg-gray-100 text-gray-600 transition duration-200 ease-out hover:bg-[#abc323] hover:text-white hover:scale-105 hover:shadow-[0_3px_8px_rgba(171,195,35,0.4)]"
						aria-label="open">
						<iconify-icon icon="mdi:arrow-right" width="20" height="20"></iconify-icon>
					</button>
				</div>
			</article>

			<!-- 3) Terms and Rules -->
			<article
				class="relative bg-[#fffffffa] rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col transition duration-300 hover:shadow-md">
				<div
					class="absolute top-4 right-4 flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#abc323] text-white">
					<iconify-icon icon="mdi:check-circle" width="18" height="18"></iconify-icon>
				</div>

				<h3 class="text-base font-semibold text-gray-800">Terms and Rules</h3>
				<p class="mt-2 text-sm text-gray-500">Familiarize yourself with the platform’s rules</p>

				<div class="mt-6 flex items-center">
					<button type="button"
						class="inline-flex items-center justify-center w-[42px] h-[42px] rounded-full bg-gray-100 text-gray-600 transition duration-200 ease-out hover:bg-[#abc323] hover:text-white hover:scale-105 hover:shadow-[0_3px_8px_rgba(171,195,35,0.4)]"
						aria-label="open">
						<iconify-icon icon="mdi:arrow-right" width="20" height="20"></iconify-icon>
					</button>
				</div>
			</article>

			<!-- 4) Order promotion -->
			<article
				class="relative bg-[#fffffffa] rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col transition duration-300 hover:shadow-md">
				<div
					class="absolute top-4 right-4 flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#abc323] text-white">
					<iconify-icon icon="mdi:bullhorn" width="18" height="18"></iconify-icon>
				</div>

				<h3 class="text-base font-semibold text-gray-800">Order promotion</h3>
				<p class="mt-2 text-sm text-gray-500">Increase tour attractiveness and sales</p>

				<div class="mt-6 flex items-center">
					<button type="button"
						class="inline-flex items-center justify-center w-[42px] h-[42px] rounded-full bg-gray-100 text-gray-600 transition duration-200 ease-out hover:bg-[#abc323] hover:text-white hover:scale-105 hover:shadow-[0_3px_8px_rgba(171,195,35,0.4)]"
						aria-label="open">
						<iconify-icon icon="mdi:arrow-right" width="20" height="20"></iconify-icon>
					</button>
				</div>
			</article>

			<!-- 5) Add third-party reviews -->
			<article
				class="relative bg-[#fffffffa] rounded-2xl border border-gray-200 p-6 shadow-sm flex flex-col transition duration-300 hover:shadow-md">
				<div
					class="absolute top-4 right-4 flex items-center justify-center w-[34px] h-[34px] rounded-full bg-[#abc323] text-white">
					<iconify-icon icon="mdi:star-circle" width="18" height="18"></iconify-icon>
				</div>

				<h3 class="text-base font-semibold text-gray-800">Add third-party reviews</h3>
				<p class="mt-2 text-sm text-gray-500">80% of our bookings come from tours with reviews</p>

				<div class="mt-6 flex items-center">
					<button type="button"
						class="inline-flex items-center justify-center w-[42px] h-[42px] rounded-full bg-gray-100 text-gray-600 transition duration-200 ease-out hover:bg-[#abc323] hover:text-white hover:scale-105 hover:shadow-[0_3px_8px_rgba(171,195,35,0.4)]"
						aria-label="open">
						<iconify-icon icon="mdi:arrow-right" width="20" height="20"></iconify-icon>
					</button>
				</div>
			</article>

		</div>
	</section>
  </div>
</template>
