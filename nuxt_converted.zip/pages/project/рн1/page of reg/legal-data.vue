<!-- // Generated from project/α¡1/page of reg/legal-data.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Legal Data \u2014 upload & bigger checkboxes", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"}, {"src": "/inline/legal-data-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<!-- Tabs (верхний бар) -->
		<div class="bg-white rounded-xl shadow-sm border border-gray-200">
			<nav class="flex gap-6 px-5 sm:px-6 py-3 text-sm">
				<button class="text-gray-500 hover:text-gray-800">Account</button>
				<button class="text-gray-500 hover:text-gray-800">Profile</button>
				<button class="text-gray-500 hover:text-gray-800">Team</button>
				<button class="text-gray-500 hover:text-gray-800">Notifications</button>
				<button class="relative font-medium text-gray-900">
					Legal Data
					<span class="absolute left-0 -bottom-3 h-[2px] w-full bg-gray-800 rounded-full"></span>
				</button>
			</nav>
		</div>

		<!-- Карточка -->
		<section class="mt-5 bg-white rounded-2xl shadow-sm border border-gray-200">
			<div class="px-5 sm:px-6 py-6 space-y-8">

				<!-- Шапка -->
				<div>
					<h2 class="text-xl font-extrabold mb-2">Legal Data</h2>
					<p class="text-sm text-gray-500">
						The data you provided during verification. To change it, send supporting documents to
						<a href="#" class="text-[#abc323] hover:underline">Support Chat</NuxtLink> or
						<a href="#" class="text-[#abc323] hover:underline">te@youtravel.me</NuxtLink>.
					</p>

					<div class="mt-6 border-t border-gray-200 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-y-4">
						<div class="text-sm text-gray-500">Country</div>
						<div class="text-sm font-medium">Uzbekistan</div>

						<div class="text-sm text-gray-500">Legal status</div>
						<div class="text-sm font-medium">Legal Entity</div>

						<div class="text-sm text-gray-500">Registration number</div>
						<div class="text-sm font-medium">+99365864038</div>

						<div class="text-sm text-gray-500">VAT number</div>
						<div class="text-sm font-medium">-</div>

						<div class="text-sm text-gray-500">Name</div>
						<div class="text-sm font-medium">Батыр</div>
					</div>
				</div>

				<!-- Licenses -->
				<div class="pt-2">
					<h3 class="text-lg font-semibold">Licenses</h3>

					<div class="mt-4">
						<div class="flex items-center gap-2 text-sm font-medium">
							A license to operate in the field of active tourism and sports
							<iconify-icon icon="mdi:help-circle-outline" class="text-gray-400"></iconify-icon>
						</div>

						<!-- Кнопка загрузки + подсказка -->
						<div class="mt-3 flex items-center gap-4 flex-wrap">
							<input id="fileInput" type="file" class="hidden" multiple
								accept=".png,.jpg,.jpeg,.webp,.pdf,image/png,image/jpeg,image/webp,application/pdf" />
							<button id="uploadBtn"
								class="inline-flex items-center gap-2 rounded-lg bg-gray-100 hover:bg-gray-200 px-4 py-2 text-sm">
								<iconify-icon icon="mdi:tray-arrow-up" width="18"></iconify-icon>
								Upload license
							</button>
							<div class="text-xs text-gray-500">
								PNG, JPG, JPEG, WEBP, PDF, up to 10 MB
							</div>
						</div>

						<!-- Ошибки -->
						<p id="fileError" class="hidden mt-2 text-xs text-red-600"></p>

						<!-- Список файлов (чипы) -->
						<div id="fileList" class="mt-3 space-y-2"></div>
					</div>

					<!-- Номер + License type -->
					<div class="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
						<div>
							<label class="text-xs text-gray-500 block mb-1">TTO Number</label>
							<input
								class="w-full rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 outline-none focus:ring-2 focus:ring-[#abc323]"
								placeholder="Type number" />
						</div>

						<!-- License type -->
						<div class="relative" id="licenseWrap">
							<label class="text-xs text-gray-500 block mb-1">License type</label>
							<button type="button" id="licenseBtn"
								class="w-full flex items-center justify-between rounded-lg border border-gray-300 bg-gray-50 px-3 py-2 text-left text-sm outline-none focus:ring-2 focus:ring-[#abc323]">
								<span id="licenseText" class="truncate text-gray-500">License type</span>
								<iconify-icon icon="mdi:chevron-down" width="18" class="text-gray-500"></iconify-icon>
							</button>

							<div id="licenseMenu"
								class="hidden absolute z-20 mt-2 w-full bg-white rounded-xl border border-gray-200 shadow-xl p-1">
								<div class="max-h-56 overflow-y-auto">
									<!-- увеличенные чекбоксы -->
									<label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 cursor-pointer">
										<input type="checkbox" class="licenseOpt h-5 w-5 scale-110 accent-[#abc323]"
											value="Domestic tourism" />
										<span class="text-sm">Domestic tourism</span>
									</label>
									<label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 cursor-pointer">
										<input type="checkbox" class="licenseOpt h-5 w-5 scale-110 accent-[#abc323]"
											value="Inbound tourism" />
										<span class="text-sm">Inbound tourism</span>
									</label>
									<label class="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 cursor-pointer">
										<input type="checkbox" class="licenseOpt h-5 w-5 scale-110 accent-[#abc323]"
											value="Outbound tourism" />
										<span class="text-sm">Outbound tourism</span>
									</label>
								</div>
								<div class="border-t border-gray-100 p-2 flex items-center justify-end gap-2">
									<button id="licenseClear" class="text-xs text-gray-500 hover:text-gray-800 px-2 py-1">Clear</button>
									<button id="licenseApply"
										class="text-xs px-3 py-1 rounded-md bg-[#abc323] hover:bg-[#9db51f] text-white">
										Apply
									</button>
								</div>
							</div>
						</div>
					</div>

					<!-- Save -->
					<div class="mt-5">
						<button
							class="inline-flex items-center justify-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">
							Save
						</button>
					</div>
				</div>

			</div>
		</section>
	</main>
  </div>
</template>
