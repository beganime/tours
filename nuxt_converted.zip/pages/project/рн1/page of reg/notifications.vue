<!-- // Generated from project/α¡1/page of reg/notifications.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Notifications \u2014 modal", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"}, {"src": "/inline/notifications-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="w-full max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
		<!-- Tabs -->
		<div class="bg-white rounded-xl shadow-sm border border-gray-200">
			<nav class="flex flex-wrap gap-6 px-5 sm:px-6 py-3 text-sm">
				<button class="text-gray-500 hover:text-gray-800">Account</button>
				<button class="text-gray-500 hover:text-gray-800">Profile</button>
				<button class="text-gray-500 hover:text-gray-800">Team</button>
				<button class="relative font-medium text-gray-900">
					Notifications
					<span class="absolute left-0 -bottom-3 h-[2px] w-full bg-gray-800 rounded-full"></span>
				</button>
				<button class="text-gray-500 hover:text-gray-800">Legal Data</button>
			</nav>
		</div>

		<!-- Notifications card -->
		<section class="mt-5 bg-[#fffffffa] rounded-2xl shadow-sm border border-gray-200">
			<header class="px-5 sm:px-6 py-4">
				<h2 class="text-lg font-semibold">Notifications</h2>
			</header>

			<div class="divide-y divide-gray-200">
				<!-- Telegram -->
				<div class="px-5 sm:px-6 py-4 flex items-center justify-between">
					<div class="flex items-center gap-4">
						<span class="inline-flex items-center justify-center w-11 h-11 rounded-full bg-[#26A4E3]">
							<iconify-icon icon="simple-icons:telegram" class="text-white" width="20" height="20"></iconify-icon>
						</span>
						<div class="font-medium text-gray-800">Telegram</div>
					</div>
					<button id="openModal"
						class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2 transition">
						Enable
					</button>
				</div>

				<!-- Email (disabled/on) -->
				<div class="px-5 sm:px-6 py-4 flex items-center justify-between opacity-60 cursor-not-allowed">
					<div class="flex items-center gap-4">
						<span
							class="inline-flex items-center justify-center w-11 h-11 rounded-full bg-gray-100 border border-gray-300">
							<iconify-icon icon="mdi:email-outline" class="text-gray-600" width="22" height="22"></iconify-icon>
						</span>
						<div class="font-medium text-gray-800">Email</div>
					</div>
					<div class="relative w-14 h-8 rounded-full bg-[#abc323] select-none">
						<span class="absolute left-1 top-1 h-6 w-6 rounded-full bg-white shadow-sm"></span>
					</div>
				</div>

				<!-- SMS (working switch) -->
				<div class="px-5 sm:px-6 py-4 flex items-center justify-between">
					<div class="flex items-center gap-4">
						<span
							class="inline-flex items-center justify-center w-11 h-11 rounded-full bg-gray-100 border border-gray-300">
							<iconify-icon icon="mdi:message-text-outline" class="text-gray-600" width="22" height="22"></iconify-icon>
						</span>
						<div class="font-medium text-gray-800">SMS notifications</div>
					</div>

					<div class="select-none">
						<input id="smsInput" type="checkbox" class="sr-only" />
						<button id="smsTrack" type="button"
							class="relative inline-flex w-14 h-8 rounded-full bg-gray-300 transition-colors duration-300 ease-out active:scale-[0.98]"
							role="switch" aria-checked="false" tabindex="0">
							<span id="smsKnob"
								class="absolute left-1 top-1 h-6 w-6 rounded-full bg-white shadow-sm transform transition-transform duration-300 ease-[cubic-bezier(0.34,1.56,0.64,1)]">
							</span>
						</button>
					</div>
				</div>
			</div>

			<!-- Footer -->
			<div class="px-5 sm:px-6 py-4">
				<button class="inline-flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800">
					Notification language
					<span class="font-medium text-gray-700">Русский</span>
					<iconify-icon icon="mdi:chevron-down" width="18" height="18"></iconify-icon>
				</button>
			</div>
		</section>
	</main>

	<!-- Modal (overlay hidden by default) -->
	<div id="modal" class="fixed inset-0 z-50 hidden">
		<!-- Backdrop -->
		<div id="backdrop" class="absolute inset-0 bg-black/40 opacity-0 transition-opacity duration-300"></div>

		<!-- Panel wrapper: позиционируем у низа на мобилке и по центру на >=sm -->
		<div class="absolute inset-0 flex items-end sm:items-center justify-center p-4">
			<!-- Panel -->
			<div id="panel" class="w-full max-w-lg bg-white rounded-2xl shadow-xl opacity-0 translate-y-10 sm:translate-y-8
                  transition-all duration-300 ease-out">
				<!-- Header -->
				<div class="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-gray-200">
					<h3 class="text-base font-semibold">Link notifications</h3>
					<button id="closeModal"
						class="inline-flex w-8 h-8 items-center justify-center rounded-full hover:bg-gray-100">
						<iconify-icon icon="mdi:close" width="20" height="20"></iconify-icon>
					</button>
				</div>

				<!-- Body -->
				<div class="px-5 sm:px-6 py-5 space-y-5">
					<!-- Selector (disabled single option like screenshot) -->
					<div>
						<div class="w-full rounded-lg border border-gray-300 bg-gray-50 px-4 py-2 text-sm text-gray-700">Telegram
						</div>
					</div>

					<!-- Step 1 -->
					<div class="text-sm text-gray-700">
						<p class="font-medium mb-2">01. Go to the chatbot via the link or QR code</p>
						<div class="flex items-center gap-4">
							<span class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-[#26A4E3]">
								<iconify-icon icon="simple-icons:telegram" class="text-white" width="18" height="18"></iconify-icon>
							</span>
							<div class="flex-1">
								<div class="font-medium text-gray-800">Telegram</div>
								<a href="https://t.me/youtravelme_bot" target="_blank" class="text-[#2b6cb0] hover:underline text-sm">
									https://t.me/youtravelme_bot
								</NuxtLink>
							</div>
							<!-- QR placeholder as span -->
							<span class="w-[64px] h-[64px] rounded-lg border border-gray-300 bg-gray-50 text-[10px] text-gray-500
                           inline-flex items-center justify-center">
								QR
							</span>
						</div>
					</div>

					<!-- Step 2 -->
					<div class="text-sm text-gray-700">
						<p class="font-medium">02. Send a message to our bot <code
								class="px-1.5 py-0.5 rounded bg-gray-100">/start</code></p>
					</div>

					<!-- Step 3 -->
					<div class="text-sm text-gray-700">
						<p class="font-medium">
							03. Wait for the code. If the code does not arrive within 15 minutes, resend <code
								class="px-1.5 py-0.5 rounded bg-gray-100">/start</code>.
							Enter the code:
						</p>
						<div class="mt-3 flex items-center gap-3">
							<input type="text" placeholder="Enter code"
								class="flex-1 rounded-lg border border-gray-300 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-[#abc323] focus:border-[#abc323]" />
							<button
								class="inline-flex items-center rounded-lg bg-[#abc323] hover:bg-[#9db51f] text-white text-sm font-medium px-4 py-2">
								Link
							</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
  </div>
</template>
