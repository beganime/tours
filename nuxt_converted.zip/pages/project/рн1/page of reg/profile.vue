<!-- // Generated from project/α¡1/page of reg/profile.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u2014 \u0444\u0438\u043d\u0430\u043b\u044c\u043d\u0430\u044f \u0430\u0434\u0430\u043f\u0442\u0438\u0432\u043d\u0430\u044f \u0432\u0435\u0440\u0441\u0438\u044f \u0441 \u0431\u043e\u043a\u043e\u0432\u043e\u0439 \u043f\u0430\u043d\u0435\u043b\u044c\u044e", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/profile-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-6xl mx-auto px-3 sm:px-6 lg:px-8 py-6">
		<div class="border-t border-gray-200 mb-5"></div>

		<div class="flex flex-col lg:flex-row gap-8">

			<!-- ЛЕВАЯ КОЛОНКА -->
			<section class="flex-1 min-w-0 order-1 lg:order-1">
				<p class="text-[#8aa61f] text-sm font-semibold text-center sm:text-left">Сейчас на сайте</p>
				<h1 class="text-2xl sm:text-3xl font-extrabold mt-1 mb-5 text-center sm:text-left">Здравствуйте, меня
					зовут&nbsp;Батыр</h1>

				<!-- Блок с аватаром и инпутами -->
				<div class="flex flex-col sm:flex-row gap-4 sm:items-start">
					<!-- Аватар -->
					<div class="flex flex-col items-center sm:items-start w-full sm:w-auto">
						<div id="avatarBox"
							class="w-[120px] h-[120px] rounded-lg overflow-hidden border-2 border-indigo-500 cursor-pointer">
							<img id="avatarImg"
								src="https://images.unsplash.com/photo-1527980965255-d3b416303d12?q=80&w=400&auto=format&fit=crop"
								class="w-full h-full object-cover" alt="avatar">
						</div>
						<input id="avatarInput" type="file" accept="image/*" class="hidden">
						<p class="text-[12px] text-gray-500 mt-2 text-center sm:text-left">Нажмите на фото, чтобы изменить</p>
					</div>

					<!-- Поля -->
					<div class="flex-1 space-y-3">
						<div class="text-sm text-gray-500 text-center sm:text-left">На YouTravel.me с февраля 2025</div>

						<!-- Страна -->
						<div class="relative" id="countryWrap">
							<button id="countryBtn" type="button"
								class="w-full text-left border-2 border-indigo-500 bg-white rounded-md px-3 py-2 text-sm flex items-center justify-between focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600">
								<span id="countryValue" class="truncate text-gray-700">Туркменистан</span>
								<svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" stroke-width="2"
									viewBox="0 0 24 24">
									<path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
								</svg>
							</button>
							<div id="countryMenu"
								class="hidden absolute z-20 mt-1 w-full bg-white rounded-md border border-gray-200 shadow-xl">
								<div class="p-2 border-b">
									<input id="countrySearch" type="text" placeholder="Поиск страны"
										class="w-full text-sm border-2 border-indigo-500 rounded-md px-2 py-1 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none" />
								</div>
								<ul id="countryList" class="max-h-64 overflow-y-auto scrolly text-sm"></ul>
							</div>
						</div>

						<!-- Город -->
						<input type="text" placeholder="Укажите город, где вы живёте"
							class="w-full border-2 border-indigo-500 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none">

						<!-- Языки -->
						<div class="relative" id="langWrap">
							<div
								class="w-full border-2 border-indigo-500 rounded-md px-2 py-2 focus-within:ring-2 focus-within:ring-indigo-500 focus-within:border-indigo-600">
								<div id="langChips" class="flex flex-wrap gap-2 mb-2 sm:justify-start">
									<span
										class="inline-flex items-c gap-1 bg-[#eef7d5] text-[#3a4e00] border border-[#dce9a8] px-2 py-1 rounded-md text-[12px]">
										Английский
									</span>
								</div>
								<div class="relative">
									<input id="langInput" type="text" placeholder="Выберите языки"
										class="w-full px-2 py-1.5 text-sm outline-none">
									<div id="langMenu"
										class="hidden absolute z-10 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-md shadow-xl max-h-56 overflow-y-auto scrolly">
										<ul id="langList" class="text-sm"></ul>
									</div>
								</div>
							</div>
						</div>

						<!-- Количество стран -->
						<input type="number" min="0" placeholder="Укажите количество стран, где вы были"
							class="w-full border-2 border-indigo-500 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none">
					</div>
				</div>

				<!-- Информация о себе -->
				<div class="mt-6 space-y-4">
					<textarea rows="6" placeholder="Укажите информацию о себе"
						class="w-full border-2 border-indigo-500 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none"></textarea>

					<div class="flex flex-col sm:flex-row justify-between items-center gap-2">
						<div class="inline-block border border-[#b08cf7] text-[#6f2de1] text-xs font-semibold rounded-md px-2 py-1">
							Мультиязычность
						</div>
						<div class="flex gap-2">
							<button class="px-3 py-1 rounded-md bg-[#6f2de1] text-white text-xs font-semibold shadow">✓</button>
							<button class="px-3 py-1 rounded-md bg-[#6f2de1] text-white text-xs font-semibold shadow">✕</button>
						</div>
					</div>

					<div class="flex items-start gap-2 text-xs text-gray-600 bg-[#f9fafb] border border-gray-200 rounded-md p-3">
						<svg class="w-4 h-4 text-gray-400 mt-0.5" fill="none" stroke="currentColor" stroke-width="2"
							viewBox="0 0 24 24">
							<path stroke-linecap="round" stroke-linejoin="round"
								d="M13 16h-1v-4h-1m1-4h.01M12 6a9 9 0 100 18 9 9 0 000-18z" />
						</svg>
						<p>Пожалуйста, не публикуйте названия компаний, контакты, бренды и ссылки.</p>
					</div>

					<input type="url" placeholder="Добавьте ссылку на видео о себе"
						class="w-full border-2 border-indigo-500 rounded-md px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-600 outline-none">
					<div class="flex flex-col sm:flex-row justify-between items-center gap-2">
						<div class="inline-block border border-[#b08cf7] text-[#6f2de1] text-xs font-semibold rounded-md px-2 py-1">
							Мультиязычность
						</div>
						<div class="flex gap-2">
							<button class="px-3 py-1 rounded-md bg-[#6f2de1] text-white text-xs font-semibold shadow">✓</button>
							<button class="px-3 py-1 rounded-md bg-[#6f2de1] text-white text-xs font-semibold shadow">✕</button>
						</div>
					</div>
				</div>
			</section>

			<!-- ПРАВАЯ ПАНЕЛЬ -->
			<aside class="w-full lg:w-[320px] order-2 lg:order-2">
				<div class="bg-white border border-gray-200 rounded-xl shadow-sm p-5">
					<!-- Верх -->
					<div class="flex items-center gap-2 text-sm justify-center lg:justify-start">
						<span class="icon-circle bg-[#eef7d5]">
							<svg class="w-4 h-4" viewBox="0 0 24 24" fill="#8aa61f">
								<path d="M12 2l3 7h7l-5.5 4.2L18 21l-6-4-6 4 1.5-7.8L2 9h7z" />
							</svg>
						</span>
						<span class="font-medium text-gray-800">Проверенный тревел-эксперт</span>
					</div>

					<div class="mt-3 flex items-center gap-2 text-sm text-gray-600 justify-center lg:justify-start">
						<span class="icon-circle bg-gray-100">
							<svg class="w-4 h-4" viewBox="0 0 24 24" fill="#9ca3af">
								<path d="M20 8H4v10h16V8zM2 6h20V4H2v2z" />
							</svg>
						</span>
						0 отзывов
					</div>

					<div class="mt-5 hidden lg:block">
						<div class="text-sm font-semibold text-gray-800 mb-2 lg:text-left">Батыр подтвердил</div>
						<ul class="space-y-2 text-sm text-center lg:text-left">
							<li class="flex items-center gap-2 lg:justify-start"><span
									class="icon-circle bg-[#eef7d5] text-[#8aa61f]">✔</span> Личный e-mail</li>
							<li class="flex items-center gap-2 lg:justify-start"><span
									class="icon-circle bg-[#eef7d5] text-[#8aa61f]">✔</span> Документы</li>
							<li class="flex items-center gap-2 lg:justify-start"><span
									class="icon-circle bg-[#eef7d5] text-[#8aa61f]">✔</span> Телефон</li>
						</ul>
					</div>

					<div class="my-5 border-t hidden lg:block border-gray-200"></div>

					<!-- Подключить соцсети -->
					<div class="space-y-3 hidden lg:block">
						<button class="w-full flex items-center justify-between text-sm">
							<div class="flex items-center gap-3">
								<span class="icon-circle bg-[#e8f0fe]">
									<svg width="14" height="14" viewBox="0 0 24 24" fill="#1877F2">
										<path
											d="M22 12a10 10 0 1 0-11.6 9.9v-7h-2v-2.9h2v-2.2c0-2 1.2-3.1 3-3.1.9 0 1.8.1 1.8.1v2h-1c-1 0-1.3.6-1.3 1.2v2h2.2l-.4 2.9h-1.8v7A10 10 0 0 0 22 12" />
									</svg>
								</span>
								<span class="text-gray-800">Подключить Facebook</span>
							</div>
						</button>

						<button class="w-full flex items-center justify-between text-sm">
							<div class="flex items-center gap-3">
								<span class="icon-circle bg-[#e6f2ff]">
									<svg width="16" height="16" viewBox="0 0 24 24" fill="#2787F5">
										<path
											d="M13.5 17c-4.7 0-7.4-3.2-7.5-8.7h2.6c.1 3.8 1.8 5.4 3.2 5.7V8.3h2.5v3.3c1.3-.1 2.6-1.6 3-3.3h2.5c-.3 1.9-1.7 3.4-2.7 4 1 .4 2.4 1.7 3 4h-2.7c-.5-1.6-1.8-2.7-3.1-2.8v2.8h-2.5V14c-1.4 0-2.7-1.2-3.2-3.1" />
									</svg>
								</span>
								<span class="text-gray-800">Подключить VK</span>
							</div>
						</button>

						<button class="w-full flex items-center justify-between text-sm">
							<div class="flex items-center gap-3">
								<span class="icon-circle bg-[#fff3e0]">
									<svg width="16" height="16" viewBox="0 0 24 24">
										<path fill="#EA4335"
											d="M12 10.2v3.8h5.3a4.6 4.6 0 1 1-1.7-4.9l2.5-2A8 8 0 1 0 12 20a8 8 0 0 0 7.7-5.6H12z" />
										<path fill="#34A853" d="M6.1 14.3a7.9 7.9 0 0 0 2.7 3.6l2-3.3c-.9-.6-1.7-1.6-2-2.8H6.1z" />
										<path fill="#FBBC05" d="M8.8 7.9a4.7 4.7 0 0 0-2.7 3.6h2.7c.3-1.1 1.1-2.1 2-2.8l-2-3.3z" />
										<path fill="#4285F4"
											d="M19.7 10.4H12v3.6h4.8c-.3 1.5-1.4 2.8-2.8 3.5l2.3 2c2.5-1.5 4-4.2 4-7.2 0-.6 0-1.2-.1-1.9z" />
									</svg>
								</span>
								<span class="text-gray-800">Подключить Google</span>
							</div>
						</button>
					</div>
				</div>
			</aside>
		</div>
	</main>
  </div>
</template>
