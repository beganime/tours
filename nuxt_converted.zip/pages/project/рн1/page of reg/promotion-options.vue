<!-- // Generated from project/α¡1/page of reg/promotion-options.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0435 \u2014 \u0441 \u0438\u043a\u043e\u043d\u043a\u043e\u0439 \u0440\u0430\u043a\u0435\u0442\u044b", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://code.iconify.design/iconify-icon/2.1.0/iconify-icon.min.js"}, {"src": "/inline/promotion-options-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<!-- Экран 1 -->
		<section id="screen-intro" class="transition-all duration-300">
			<div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
				<h1 class="text-xl sm:text-2xl font-semibold text-center text-gray-400 mb-6">
					Пусть все узнают о вашем туре
				</h1>

				<div class="rounded-xl bg-gray-50 border border-gray-200 h-56 sm:h-64 flex items-center justify-center mb-6">
					<span class="text-gray-400">Иллюстрация</span>
				</div>

				<p class="text-sm text-gray-600 leading-6 max-w-3xl mx-auto text-center">
					Продвигайте свои туры на площадках и ресурсах YouTravel.me, чтобы как можно больше путешественников их
					заметили.
					Расскажите о поездке в наших соцсетях, блоге, почтовой рассылке и поднимите тур в поисковой выдаче на
					платформе.
				</p>

				<div class="mt-6 flex justify-center">
					<button id="openOptions" class="inline-flex items-center justify-center rounded-[10px] bg-[#abc323] hover:bg-[#9db51f]
                       text-white font-medium px-6 py-3 transition">
						Выбрать способ продвижения
					</button>
				</div>
			</div>

			<!-- Два блока "Скоро" -->
			<div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mt-6">
				<div class="bg-white rounded-2xl border border-gray-100 p-5 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.15)]">
					<div class="text-gray-500 font-semibold mb-1">Пригласить тревел-экспертов и заработать</div>
					<div class="text-sm text-gray-400">Скоро</div>
				</div>

				<div class="bg-white rounded-2xl border border-gray-100 p-5 shadow-[0_20px_40px_-20px_rgba(0,0,0,0.15)]">
					<div class="text-gray-500 font-semibold mb-1">Участвовать в акции Кешбэк</div>
					<div class="text-sm text-gray-400">Скоро</div>
				</div>
			</div>
		</section>

		<!-- Экран 2 -->
		<section id="screen-options" class="hidden opacity-0 translate-y-6 transition-all duration-300">
			<div class="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sm:p-8">
				<div class="flex items-center justify-between mb-2">
					<h2 class="text-xl sm:text-2xl font-semibold">Выберите вариант продвижения</h2>
					<button id="goBack" class="text-sm text-gray-500 hover:text-gray-800 underline underline-offset-4">
						Назад
					</button>
				</div>

				<!-- Фиолетовый блок -->
				<div class="mt-6 rounded-2xl p-5 sm:p-6 bg-[#efe9ff]">
					<div class="text-center mb-3">
						<div class="mx-auto w-10 h-10 rounded-full bg-[#6f2de1]/10 flex items-center justify-center mb-2">
							<iconify-icon icon="mdi:rocket-launch-outline" class="text-[#6f2de1]" width="22" height="22">
							</iconify-icon>
						</div>
						<a href="#" class="text-[#6f2de1] font-semibold hover:underline">
							Поднимите карточку в <span class="underline decoration-[#6f2de1]/30">топ каталога</span>
						</NuxtLink>
					</div>

					<div
						class="bg-white rounded-xl border border-white/70 shadow-sm p-5 text-[15px] leading-relaxed text-gray-700">
						<p class="font-semibold text-gray-900">
							Туры на первых позициях поиска привлекают больше путешественников.
						</p>
						<p class="mt-2">
							Поднимите тур в топ каталога, самостоятельно управляя продвижением. Запускайте рекламные кампании
							на основе аукционной модели в реальном времени и сами решайте, сколько на них потратить.
						</p>
						<p class="mt-3">
							Чтобы получить доступ к системе, пополните баланс на сумму от 3 000 ₽.
							При единоразовом пополнении от 15 000 ₽ получите бонус +20%.
						</p>
					</div>


					<div class="mt-6 text-sm text-gray-600 leading-6 space-y-2">
						<p>
							Подробнее о продвижении читайте в <a href="#" class="text-[#6f2de1] hover:underline">Базе Знаний</NuxtLink>.
						</p>
						<p>
							Ваш профиль должен быть верифицирован, а туры опубликованы.
							Подробнее читайте в базе знаний
							<a href="#" class="text-[#6f2de1] hover:underline">«Верификация тревел-экспертов»</NuxtLink>.
						</p>
						<div class="mt-6 flex justify-center">
							<button class="inline-flex items-center justify-center px-6 py-3 bg-[#6f2de1]
										 hover:bg-[#5b24b6] text-white font-medium rounded-[10px] shadow-sm transition">
								Пополнить баланс для поднятия в Топ каталога
							</button>
						</div>
					</div>
				</div>

				<!-- Зелёный блок -->
				<div class="mt-6 rounded-2xl p-5 sm:p-6 bg-[#eef7d5]">
					<div class="text-center mb-3">
						<div class="mx-auto w-10 h-10 rounded-full bg-[#abc323]/20 flex items-center justify-center mb-2">
							<iconify-icon icon="mdi:bullhorn-outline" class="text-[#8aa61f]" width="22" height="22"></iconify-icon>
						</div>
						<div class="text-[#7ea72f] font-semibold">
							Расскажите о вашем туре аудитории <span class="text-[#6c901e]">YouTravel.me</span>
						</div>
					</div>

					<div
						class="bg-white rounded-xl border border-white/70 shadow-sm p-5 text-[15px] leading-relaxed text-gray-700">
						<p>
							Аудитория YouTravel.me — <strong>1,5 миллиона</strong> человек в месяц.
							Закажите пост, серию сторис, статью, упоминание в рассылке или сторис в результатах поиска —
							о вас узнают тысячи путешественников.
						</p>
					</div>


					<div class="mt-6 text-sm text-gray-600 leading-6 space-y-2">
						<p>
							Подробнее о продвижении читайте в <a href="#" class="text-[#7ea72f] hover:underline">Базе Знаний</NuxtLink>.
						</p>
						<p>
							Ваш профиль должен быть верифицирован, а туры опубликованы.
							Подробнее читайте в базе знаний
							<a href="#" class="text-[#7ea72f] hover:underline">«Верификация тревел-экспертов»</NuxtLink>.
						</p>
					</div>
					<div class="mt-6 flex justify-center">
						<button class="inline-flex items-center justify-center px-6 py-3 bg-[#abc323] hover:bg-[#9db51f]
									 text-white font-medium rounded-[10px] shadow-sm transition">
							Заказать размещение
						</button>
					</div>
				</div>
			</div>
		</section>

	</main>
  </div>
</template>
