<!-- // Generated from project/α¡1/page of support/Book-via-YouTravel-me.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u043e\u0447\u0435\u043c\u0443 \u043d\u0443\u0436\u043d\u043e \u0431\u0440\u043e\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0447\u0435\u0440\u0435\u0437 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Book-via-YouTravel-me-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Почему нужно бронировать через YouTravel.me</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			О YouTravel.me
		</h1>

		<!-- Подзаголовок -->
		<h2 class="text-xl font-semibold text-gray-900 mb-4">
			Почему нужно бронировать через YouTravel.me?
		</h2>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h3 class="text-base font-semibold text-gray-900">
				Основные преимущества бронирования туров через YouTravel.me:
			</h3>
			<ul class="space-y-1">
				<li class="flex gap-2">
					<span>—</span>
					<span>
						На одной платформе собрано более 6 700 уникальных авторских туров от проверенных тревел-экспертов;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>У нас нет дополнительных сборов и комиссий за туры;</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						Общение происходит напрямую с тревел-экспертом, которому вы сразу можете задать все интересующие вопросы;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						Надёжная платёжная система, через которую можно безопасно оплачивать туры онлайн;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						Выгодная программа лояльности, благодаря которой вы можете получать бонусы и экономить на следующих
						поездках.
					</span>
				</li>
			</ul>

			<p class="font-semibold text-gray-900 mt-6">
				Наша главная цель — помочь путешественникам с выбором лучшего тура, чтобы путешествие прошло безопасно и
				незабываемо.
			</p>

			<p>
				Мы ежедневно работаем над этим и придерживаемся наших принципов.
			</p>

			<p class="text-[15px] font-semibold text-ytPurple">
				Выбирайте и бронируйте незабываемое путешествие прямо сейчас.
			</p>
		</section>
	</main>
  </div>
</template>
