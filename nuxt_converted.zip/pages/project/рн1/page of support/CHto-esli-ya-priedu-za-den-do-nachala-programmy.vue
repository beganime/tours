<!-- // Generated from project/α¡1/page of support/CHto-esli-ya-priedu-za-den-do-nachala-programmy.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0427\u0442\u043e, \u0435\u0441\u043b\u0438 \u044f \u043f\u0440\u0438\u0435\u0434\u0443 \u0437\u0430 \u0434\u0435\u043d\u044c \u0434\u043e \u043d\u0430\u0447\u0430\u043b\u0430 \u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u044b \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/CHto-esli-ya-priedu-za-den-do-nachala-programmy-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Что, если я приеду за день до начала программы?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			Авторские туры
		</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Что, если я приеду за день до начала программы?
			</h2>

			<p>
				Вы можете приехать раньше начала тура или остаться на более долгий срок.
				Предупредите об этом заранее вашего тревел-эксперта — и он подскажет, какие отели
				можно забронировать на дополнительные дни или продлит проживание в отеле по программе.
			</p>

			<p>
				В некоторых случаях трансфер из аэропорта вне дат тура также может быть бесплатным.
			</p>
		</section>
	</main>
  </div>
</template>
