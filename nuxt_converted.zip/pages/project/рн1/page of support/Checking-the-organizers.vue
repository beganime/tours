<!-- // Generated from project/α¡1/page of support/Checking-the-organizers.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a \u043e\u0441\u0443\u0449\u0435\u0441\u0442\u0432\u043b\u044f\u0435\u0442\u0441\u044f \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0430 \u043e\u0440\u0433\u0430\u043d\u0438\u0437\u0430\u0442\u043e\u0440\u043e\u0432 \u0442\u0443\u0440\u043e\u0432 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Checking-the-organizers-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Как осуществляется проверка организаторов туров</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			О YouTravel.me
		</h1>

		<!-- Основной контент -->
		<section class="space-y-6 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Как осуществляется проверка организаторов туров?
			</h2>

			<p>
				Проверка всех тревел-экспертов проходит с помощью комплексной оценки.
			</p>

			<h3 class="text-base font-semibold text-gray-900">
				Критерии, по которым наша команда проверяет тревел-экспертов:
			</h3>

			<ul class="space-y-1">
				<li class="flex gap-2">
					<span>—</span>
					<span>
						проверка юридического лица по Единому государственному реестру юридических лиц,
						регистрации, операционной деятельности, уплаты налогов и другое;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						отзывы предыдущих клиентов, социальные сети, представленность в интернет-пространстве,
						рекомендации от партнёров, других профессиональных участников рынка;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						уточнение вопросов организации безопасности на маршруте, квалификации гидов,
						опыта работы;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						наша команда оценивает тревел-эксперта на предмет того, готовы ли мы отправить своих родных
						в путешествие.
					</span>
				</li>
			</ul>

			<p>
				Итоговое решение о допуске тревел-эксперта к размещению туров на сайте YouTravel.me оставляется за
				собой.
			</p>

			<p>
				Сбор отзывов о тревел-экспертах осуществляется напрямую от путешественников и публикуется на
				странице тревел-эксперта и на странице тура. Каждый посетитель и путешественник может увидеть
				полный текст отзывов без изменений.
			</p>

			<p>
				Со всеми отзывами о тревел-экспертах можно
				<a href="#" class="text-ytPurple font-semibold hover:underline">ознакомиться здесь</NuxtLink>.
			</p>
		</section>
	</main>
  </div>
</template>
