<!-- // Generated from project/α¡1/page of support/Mogu-ya-poekhat-v-odinochku.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041c\u043e\u0433\u0443 \u044f \u043f\u043e\u0435\u0445\u0430\u0442\u044c \u0432 \u043e\u0434\u0438\u043d\u043e\u0447\u043a\u0443 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Mogu-ya-poekhat-v-odinochku-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Могу я поехать в одиночку?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			Авторские туры
		</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Могу я поехать в одиночку?
			</h2>

			<p>
				Конечно, многие индивидуальные путешественники выбирают авторские туры в небольших группах.
				По умолчанию, стоимость тура на сайте включает в себя размещение, указанное в разделе
				<strong>«Варианты размещения»</strong> в описании тура.
			</p>

			<p>
				В большинстве туров размещение происходит в двухместных номерах с путешественником того же пола
				или в одноместном номере с доплатой. О возможностях и условиях одноместного размещения,
				а также о возможности подселения к другому индивидуальному путешественнику можно узнать у
				тревел-эксперта перед бронированием.
			</p>

			<p>
				Часто в группе встречаются несколько индивидуальных путешественников, которые уже в первые дни
				поездки начинают общаться и становятся друзьями!
			</p>
		</section>
	</main>
  </div>
</template>
