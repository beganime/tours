<!-- // Generated from project/α¡1/page of support/Pay-for-the-tour.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a \u043e\u043f\u043b\u0430\u0442\u0438\u0442\u044c \u0442\u0443\u0440 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Pay-for-the-tour-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Как оплатить тур</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			О YouTravel.me
		</h1>

		<!-- Подзаголовок -->
		<h2 class="text-xl font-semibold text-gray-900 mb-4">
			Как оплатить тур?
		</h2>

		<!-- Основной контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<p>
				После того как вы выбрали авторский тур, вы можете внести предоплату
				непосредственно из чата с тревел-экспертом, нажав кнопку
				<strong>«Оплатить»</strong> или с главной страницы тура, нажав кнопку
				<strong>«Заказать тур»</strong>.
			</p>

			<p>
				После заполнения данных о себе и других участниках вы сможете оплатить
				бронирование любым удобным способом через безопасную платёжную систему.
				Наша система принимает карты любых банков и стран.
			</p>

			<p>
				Размер предоплаты определяется условиями тревел-эксперта, а также
				выбранным способом оплаты, например:
			</p>

			<ul class="space-y-1 text-[15px] leading-relaxed">
				<li class="flex gap-2">
					<span>—</span>
					<span>
						минимальный размер предоплаты всегда доступен при оплате брони
						картой, выпущенной российским банком, если вы бронируете тур
						тревел-эксперта, не являющегося резидентом РФ. Остаток суммы
						оплачивается в день старта тура в валюте страны;
					</span>
				</li>
				<li class="flex gap-2">
					<span>—</span>
					<span>
						максимальный размер предоплаты (100%) устанавливается, если до
						старта путешествия остаётся XX дней и срок уже наступил (исключение
						— особые условия тура).
					</span>
				</li>
			</ul>

			<p>
				При бронировании также доступна информация о дате полной оплаты тура.
				Например, она может совпадать с датой старта путешествия. В ваших
				заказах в личном кабинете всегда доступна полная информация о
				совершённых и предстоящих платежах.
			</p>

			<p>
				Если у вас возникли сложности с оплатой, обратитесь в службу поддержки.
			</p>
		</section>
	</main>
  </div>
</template>
