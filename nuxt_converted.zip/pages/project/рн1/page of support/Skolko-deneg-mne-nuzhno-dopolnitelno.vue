<!-- // Generated from project/α¡1/page of support/Skolko-deneg-mne-nuzhno-dopolnitelno.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0421\u043a\u043e\u043b\u044c\u043a\u043e \u0434\u0435\u043d\u0435\u0433 \u043c\u043d\u0435 \u043d\u0443\u0436\u043d\u043e \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u043e \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Skolko-deneg-mne-nuzhno-dopolnitelno-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Сколько денег мне нужно дополнительно?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			Авторские туры
		</h1>

		<!-- Основной контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Сколько денег мне нужно дополнительно?
			</h2>

			<p>
				У каждого путешественника разные потребности, поэтому нет определённой суммы.
				Тем не менее, мы рекомендуем ориентироваться на <strong>$50–100 в день</strong>,
				зная, что в некоторые дни вы можете вообще ничего не тратить,
				а в другие дни — покупать сувениры для семьи, оплачивать обеды или
				дополнительные активности по ходу программы.
			</p>

			<p>
				Более подробную информацию о возможных ежедневных расходах в рамках конкретной программы
				вы всегда можете получить у тревел-эксперта выбранного тура,
				нажав кнопку <strong>«Написать тревел-эксперту»</strong>.
			</p>
		</section>
	</main>
  </div>
</template>
