<!-- // Generated from project/α¡1/page of support/Waiting-for-confirmation.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0427\u0442\u043e \u0437\u043d\u0430\u0447\u0438\u0442 \u201c\u041e\u0436\u0438\u0434\u0430\u0435\u0442 \u043f\u043e\u0434\u0442\u0432\u0435\u0440\u0436\u0434\u0435\u043d\u0438\u044f\u201d? \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/Waiting-for-confirmation-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Что значит “Ожидает подтверждения”?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			О YouTravel.me
		</h1>

		<!-- Основной контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Что значит “Ожидает подтверждения”?
			</h2>

			<p>
				Тревел-эксперт набирает небольшую группу и старается объединить в поездке людей, похожих
				по интересам и возрасту. Если вы отправили запрос на бронирование и увидели этот статус,
				значит необходимо подождать не более 24 часов. За это время тревел-эксперт успеет подтвердить
				ваше бронирование.
			</p>

			<p>
				Внести предоплату за тур вы можете, не дожидаясь подтверждения от тревел-эксперта. Если вдруг
				организатор не сможет подтвердить ваше бронирование и отклонит его, предоплата вернётся вам в
				полном объёме. Процесс подтверждения занимает не более 24 часов.
			</p>

			<p>
				Если предоплата внесена и организатор подтвердил вашу заявку, бронирование автоматически
				считается завершённым, и вам на почту придёт письмо с деталями бронирования.
			</p>

			<p>
				Если вы оставили заявку без оплаты, и организатор подтвердил её, то для завершения
				бронирования вам необходимо внести предоплату в течение 24 часов. Место в туре закрепляется
				за вами только после внесения предоплаты и подтверждения заявки тревел-экспертом.
			</p>
		</section>
	</main>
  </div>
</template>
