<!-- // Generated from project/α¡1/page of support/What-happens-after-payment.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0427\u0442\u043e \u043f\u0440\u043e\u0438\u0441\u0445\u043e\u0434\u0438\u0442 \u043f\u043e\u0441\u043b\u0435 \u043e\u043f\u043b\u0430\u0442\u044b \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/What-happens-after-payment-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Что происходит после оплаты?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			Авторские туры
		</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Что происходит после оплаты?
			</h2>

			<p>
				После оплаты депозита на указанную при регистрации или внесении предоплаты на сайте
				<strong>YouTravel.me</strong> на вашу электронную почту будет направлено подтверждение
				транзакции и детализированное подтверждение бронирования с дальнейшими инструкциями.
			</p>

			<p>
				Если оплаченное бронирование требует подтверждения организатора, на почту будет выслана
				информация о сроках подтверждения. В таком случае письмо с подтверждением транзакции
				будет отправлено сразу, как только тревел-эксперт примет заявку (обычно это менее 24 часов).
			</p>
		</section>
	</main>
  </div>
</template>
