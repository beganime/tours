<!-- // Generated from project/α¡1/page of support/apply-for-a-visa.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u043e\u043c\u043e\u0433\u0430\u0435\u0442\u0435 \u043b\u0438 \u0432\u044b \u043e\u0444\u043e\u0440\u043c\u043b\u044f\u0442\u044c \u0432\u0438\u0437\u0443? | YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-6 py-12">

		<!-- Хлебные крошки -->
		<nav class="text-sm text-gray-500 mb-6">
			<a href="#" class="hover:text-[#6b21a8]">Главная</NuxtLink> ›
			<a href="#" class="hover:text-[#6b21a8]">Поддержка</NuxtLink> ›
			Помогаете ли вы оформлять визу?
		</nav>

		<!-- Заголовок раздела -->
		<h2 class="text-2xl font-bold text-[#6b21a8] mb-6">Тревел-поддержка</h2>

		<!-- Контент -->
		<article class="prose max-w-none text-[17px] leading-relaxed text-gray-800">
			<h3 class="text-lg font-semibold mb-4">Помогаете ли вы оформлять визу?</h3>

			<p>
				Если путешественник планирует поехать в авторский тур в ту страну, куда ему требуется виза/разрешение на въезд,
				то необходимо сообщить об этом Тревел-эксперту тура.
				После бронирования тура Тревел-эксперт может предоставить необходимые рекомендации по получению визы, а также
				документы, способствующие получению визы
				(ваучер на бронирование отеля, программа пребывания в стране — маршрут, заполненная по шаблону и другое).
			</p>

			<p>
				Помните, что получение визы является целиком ответственностью путешественника.
				Рекомендуем заранее позаботиться о получении всех документов, влияющих на пребывание в туре.
			</p>
		</article>

	</main>
  </div>
</template>
