<!-- // Generated from project/α¡1/page of support/commission.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0411\u0435\u0440\u0435\u0442 \u043b\u0438 \u0441\u0435\u0440\u0432\u0438\u0441 \u043a\u043e\u043c\u0438\u0441\u0441\u0438\u044e \u043f\u0440\u0438 \u043e\u043f\u043b\u0430\u0442\u0435 \u043a\u0440\u0435\u0434\u0438\u0442\u043d\u043e\u0439 \u043a\u0430\u0440\u0442\u043e\u0439 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/commission-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Берет ли сервис комиссию при оплате кредитной картой?</span>
		</nav>

		<!-- Заголовок раздела -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">Оплаты</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Берет ли сервис комиссию при оплате кредитной картой?
			</h2>

			<p>
				Нет. Вы не переплачиваете при любом способе оплаты. При этом тревел-эксперты
				предлагают лучшую цену без наценок.
			</p>
		</section>
	</main>
  </div>
</template>
