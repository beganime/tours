<!-- // Generated from project/α¡1/page of support/create-an-account.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a \u0437\u0430\u0432\u0435\u0441\u0442\u0438 \u0430\u043a\u043a\u0430\u0443\u043d\u0442 \u043d\u0430 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<main class="max-w-4xl mx-auto px-4 py-10">

		<!-- Хлебные крошки -->
		<nav class="text-sm text-gray-500 mb-6">
			<a href="#" class="hover:underline">Главная</NuxtLink> ›
			<a href="#" class="hover:underline">Поддержка</NuxtLink> ›
			<span class="text-gray-700">Как завести аккаунт на YouTravel.me?</span>
		</nav>

		<!-- Заголовок раздела -->
		<h1 class="text-2xl font-bold text-purple-800 mb-8">Мой профиль</h1>

		<!-- Контент -->
		<article class="space-y-4 leading-relaxed text-[17px]">
			<h2 class="text-lg font-semibold">Как завести аккаунт на YouTravel.me?</h2>

			<p>
				Если у вас еще нет профиля YouTravel.me, перейдите на страницу
				<a href="https://youtravel.me" class="text-purple-700 hover:underline">https://youtravel.me</NuxtLink>
				и нажмите кнопку <strong>Регистрация</strong>.
				Вы можете зарегистрироваться по электронной почте или авторизоваться на сайте через любую социальную сеть.
			</p>

			<p>
				Регистрация и создание профиля на YouTravel.me абсолютно бесплатны.
			</p>
		</article>

	</main>
  </div>
</template>
