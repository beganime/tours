<!-- // Generated from project/α¡1/page of support/giftcertificate.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0415\u0441\u0442\u044c \u043b\u0438 \u043f\u043e\u0434\u0430\u0440\u043e\u0447\u043d\u044b\u0435 \u0441\u0435\u0440\u0442\u0438\u0444\u0438\u043a\u0430\u0442\u044b \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/giftcertificate-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Есть ли подарочные сертификаты?</span>
		</nav>

		<!-- Заголовок раздела -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">Оплаты</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">Есть ли подарочные сертификаты?</h2>

			<p>
				Да! Вы можете приобрести подарочный сертификат на сумму от
				<strong>5 000 до 1 000 000 рублей</strong>, чтобы порадовать друзей,
				близких людей или коллегу.
			</p>

			<p>
				Отправиться в путешествие можно в течение 2-х лет со дня покупки сертификата,
				а использовать его для оплаты тура необходимо за 1 год с момента приобретения.
			</p>

			<p>
				Оформите заявку на приобретение подарочного сертификата на любое путешествие в
				<a href="#" class="text-ytPurple font-semibold hover:underline">этом разделе</NuxtLink>.
			</p>
		</section>
	</main>
  </div>
</template>
