<!-- // Generated from project/α¡1/page of support/group-tour.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u043e\u0447\u0435\u043c\u0443 \u043d\u0443\u0436\u043d\u043e \u0435\u0445\u0430\u0442\u044c \u0432 \u0433\u0440\u0443\u043f\u043f\u043e\u0432\u043e\u0439 \u0442\u0443\u0440 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/group-tour-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Почему нужно ехать в групповой тур?</span>
		</nav>

		<!-- Заголовок -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
			Авторские туры
		</h1>

		<!-- Основной контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Почему нужно ехать в групповой тур?
			</h2>

			<p>
				Путешествие в небольшой группе даёт вам возможность познакомиться с представителями другой
				культуры как в стране, которую вы посещаете, так и внутри вашей группы путешественников.
				Обычно путешественники настолько сближаются, что становятся друзьями на всю жизнь и продолжают
				ездить вместе.
			</p>

			<p>
				Небольшая группа с одной стороны позволяет сэкономить ваше время и деньги, а с другой —
				избавляет вас от стрессового планирования. Тревел-эксперт уже забронировал для вас транспорт,
				жильё и программу, вам достаточно оказаться в месте старта путешествия и наслаждаться поездкой —
				обо всём остальном позаботится тревел-эксперт.
			</p>

			<p>
				К тому же организованное заранее активное путешествие позволяет вам заранее рассчитать даты
				отпуска, сэкономив при этом деньги.
			</p>
		</section>
	</main>
  </div>
</template>
