<!-- // Generated from project/α¡1/page of support/guarantee.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a\u0438\u0435 \u0433\u0430\u0440\u0430\u043d\u0442\u0438\u0438 \u0434\u0430\u0451\u0442 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/guarantee-1.js", "defer": true}] });
</script>

<template>
  <div>
<!-- CONTENT WRAPPER -->
	<main class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- двухколоночный макет со «сайдбаром»-заглушкой слева -->
		<div class="grid grid-cols-12 gap-6">
			<!-- Левый белый блок (как карточка-заполнитель) -->
			<article class="col-span-12 md:col-span-9">
				<!-- Хлебные крошки -->
				<nav class="text-xs sm:text-sm text-gray-500 mb-4">
					<a href="#" class="hover:underline">Главная</NuxtLink>
					<span class="mx-2">›</span>
					<a href="#" class="hover:underline">Поддержка</NuxtLink>
					<span class="mx-2">›</span>
					<span class="text-gray-700">Какие гарантии даёт YouTravel.me?</span>
				</nav>

				<!-- Заголовок страницы -->
				<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">
					О YouTravel.me
				</h1>

				<!-- Подзаголовок -->
				<h2 class="text-xl font-semibold text-gray-900 mb-4">Какие гарантии даёт YouTravel.me?</h2>

				<!-- Вступительный абзац -->
				<p class="text-[15px] leading-relaxed text-gray-700 mb-4">
					YouTravel.me — онлайн-платформа, где мы отбираем только лучшие туры от проверенных тревел-экспертов.
					На сайте размещено более 7500 честных отзывов от наших путешественников.
				</p>

				<!-- Блок: YouTravel.me гарантирует -->
				<h3 class="text-base font-semibold text-gray-900 mb-2">YouTravel.me гарантирует:</h3>
				<ul class="space-y-1 text-[15px] leading-relaxed text-gray-800 mb-6">
					<li class="flex gap-2"><span>—</span><span>безопасность вашего путешествия и юридическую помощь по всем
							вопросам;</span></li>
					<li class="flex gap-2"><span>—</span><span>размещение всех отзывов от реальных путешественников;</span></li>
					<li class="flex gap-2"><span>—</span><span>тщательную проверку тревел-экспертов, основанную на непредвзятой
							оценке;</span></li>
					<li class="flex gap-2"><span>—</span><span>надёжную организацию тура, которую берёт на себя
							тревел-эксперт.</span></li>
				</ul>

				<!-- Блок: Как мы собираем отзывы -->
				<h3 class="text-base font-semibold text-gray-900 mb-2">Как мы собираем отзывы от путешественников?</h3>
				<ul class="space-y-1 text-[15px] leading-relaxed text-gray-800 mb-6">
					<li class="flex gap-2"><span>—</span><span>Сбор отзывов осуществляется напрямую от путешественников: через 1
							день после окончания авторского тура каждому приходит письмо с уникальной ссылкой на страницу с оценкой и
							рекомендациями.</span></li>
					<li class="flex gap-2"><span>—</span><span>После отправки отзыв публикуется на странице тревел-эксперта и на
							странице тура. Любой посетитель может увидеть полный текст отзыва без изменений.</span></li>
					<li class="flex gap-2"><span>—</span><span>Отзывы оставляют только путешественники, забронировавшие и
							съездившие в тур через YouTravel.me. Если тур бронировался напрямую у эксперта, мы не можем подтвердить
							достоверность такого отзыва.</span></li>
					<li class="flex gap-2"><span>—</span><span>По каждой поездке от одного путешественника может быть оставлен
							только 1 отзыв.</span></li>
				</ul>

				<!-- Блок: Проверка экспертов -->
				<h3 class="text-base font-semibold text-gray-900 mb-2">Проверка всех тревел-экспертов проходит с помощью
					комплексной оценки.</h3>
				<p class="text-[15px] leading-relaxed text-gray-700 mb-2">
					Критерии, по которым наша команда проверяет тревел-экспертов:
				</p>
				<ul class="space-y-1 text-[15px] leading-relaxed text-gray-800 mb-6">
					<li class="flex gap-2"><span>—</span><span>проверка юрлица по ЕГРЮЛ/регистрам, регистрации, операционной
							деятельности, уплаты налогов и др.;</span></li>
					<li class="flex gap-2"><span>—</span><span>отзывы предыдущих клиентов, соцсети, представленность в
							интернет-пространстве, рекомендации от партнёров и других участников рынка;</span></li>
					<li class="flex gap-2"><span>—</span><span>собеседование с организатором тура, уточнение вопросов безопасности
							на маршруте, квалификации гидов и опыта работы;</span></li>
					<li class="flex gap-2"><span>—</span><span>наша команда оценивает туры и задаёт эксперту вопросы «как будто
							отправляем своих родных».</span></li>
				</ul>

				<p class="text-[15px] leading-relaxed text-gray-700 mb-6">
					Итоговое решение о допуске тревел-эксперта к размещению туров на сайте YouTravel.me оставляет за собой.
				</p>

				<!-- Финальный тезис -->
				<p class="text-[15px] leading-relaxed font-semibold text-gray-900">
					Наша главная цель — помочь путешественникам с выбором лучшего тура, чтобы путешествие прошло безопасно и
					незабываемо.
					Мы ежедневно работаем над этим и придерживаемся наших принципов.
				</p>
			</article>
		</div>
	</main>
  </div>
</template>
