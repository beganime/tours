<!-- // Generated from project/α¡1/page of support/how-it-works.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041a\u0430\u043a \u0437\u0430\u0431\u0440\u043e\u043d\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u0442\u0443\u0440 \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- HEADER -->


	<!-- CONTENT -->
	<main class="max-w-5xl mx-auto px-6 py-12">
		<!-- Breadcrumbs -->
		<nav class="text-sm text-gray-500 mb-6">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700 font-medium">Как забронировать тур</span>
		</nav>

		<!-- Title -->
		<h1 class="text-2xl sm:text-3xl font-bold text-purple-700 mb-8">
			О YouTravel.me
		</h1>

		<!-- Section -->
		<section class="space-y-6 text-[15px] leading-relaxed">
			<div>
				<h2 class="text-xl font-semibold text-gray-800 mb-3">
					Как забронировать тур
				</h2>
				<p>
					На YouTravel.me размещено более <strong>40 000 туров</strong>, которые можно
					забронировать онлайн. Напрямую от тревел-экспертов, без посещения офиса и
					турагентств. Тревел-эксперты станут вашими проводниками в мир путешествий и
					откроют знакомые места по-новому.
				</p>
				<p class="mt-3">
					За 5 лет мы собрали на одной площадке большое комьюнити людей, которых объединяет
					любовь к путешествиям.
				</p>
			</div>

			<div>
				<div>
					<h2 class="text-lg font-semibold text-gray-800 mb-3">
						Тревел-эксперты предлагают вам:
					</h2>
					<ul class="list-disc pl-5 space-y-2">
						<li>
							Нестандартные маршруты, которые составляют исходя из своего опыта,
							делятся самыми секретными местами, чтобы вы узнали мир по-новому и
							познакомились с местной культурой.
						</li>
						<li>
							Путешествия мечты, уже спланированные за вас. Каждая деталь продумана до
							мелочей и все активности индивидуально подстроены под вас.
						</li>
						<li>
							Перезагрузку в компании единомышленников и близких по духу людей.
						</li>
					</ul>
				</div>

				<!-- Раздел: Почему именно YouTravel.me -->
				<div class='mt-4'>
					<h2 class="text-lg font-semibold text-gray-800 mb-3">
						Почему именно YouTravel.me?
					</h2>
					<ul class="list-disc pl-5 space-y-2">
						<li>
							Мы проверяем каждого тревел-эксперта перед тем, как представить его туры на
							сайте. Мы гарантируем безопасность вашего путешествия и отбираем только
							лучшие авторские туры.
						</li>
						<li>
							Вы можете всегда написать тревел-эксперту и задать все интересующие вопросы
							о путешествии.
						</li>
						<li>
							Наш поисковый алгоритм позволяет выбрать для вас наиболее подходящее
							путешествие по стилю, по комфорту и по активности.
						</li>
						<li>
							Мы гарантируем лучшую цену: вы общаетесь напрямую с организатором тура без
							посредников.
						</li>
						<li>
							На сайте более 21 000 отзывов — вы всегда можете узнать обратную связь от
							путешественников, которые уже побывали в туре, который вас заинтересовал.
						</li>
					</ul>
				</div>

				<!-- Раздел: Как забронировать -->
				<div class="mt-10">
					<section class="space-y-10">
						<!-- Заголовок -->
						<h2 class="text-2xl sm:text-3xl font-bold text-gray-900 mb-8">
							Как забронировать тур?
						</h2>

						<!-- 1. Выбирайте направление и даты -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ВЫБИРАЙТЕ НАПРАВЛЕНИЕ И ДАТЫ:
								</h3>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>Выберите нужное направление</li>
									<li>Определите желаемые даты путешествия</li>
									<li>Воспользуйтесь фильтрами для уточнения путешествия</li>
									<li>Выберите один или несколько туров, которые вам подходят</li>
								</ul>
							</div>
						</div>

						<!-- 2. Изучайте карточки туров -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ИЗУЧАЙТЕ КАРТОЧКИ ТУРОВ:
								</h3>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>
										Прочитайте отзывы и изучите информацию про тревел-эксперта
									</li>
									<li>
										Выясните, что включено и не включено в стоимость тура
									</li>
									<li>
										Изучите программу тура и выберите ту, которая больше всего вам
										подходит
									</li>
								</ul>
							</div>
						</div>

						<!-- 3. Свяжитесь с тревел-экспертом -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									СВЯЖИТЕСЬ С ТРЕВЕЛ-ЭКСПЕРТОМ:
								</h3>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>Задайте интересующие вопросы прямо в чате с экспертом</li>
									<li>
										Уточните детали маршрута, формат проживания и уровень комфорта
									</li>
									<li>
										Получите персональные рекомендации и помощь при выборе тура
									</li>
								</ul>
							</div>
						</div>

						<!-- Подключайте мессенджеры -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ПОДКЛЮЧАЙТЕ МЕССЕНДЖЕРЫ ДЛЯ ОПЕРАТИВНОГО ОБЩЕНИЯ:
								</h3>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>
										В левом верхнем углу подключите удобный мессенджер (например,
										Telegram или WhatsApp);
									</li>
									<li>
										Когда тревел-эксперт подтвердит бронирование и вы договоритесь о
										деталях путешествия, перейдите к оплате прямо в чате;
									</li>
									<li>
										Или нажмите «Перейти к оплате» на странице тура — это также
										безопасный способ завершить бронирование.
									</li>
								</ul>
							</div>
						</div>

						<!-- Внесите данные путешественников -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ВНЕСИТЕ ДАННЫЕ ПУТЕШЕСТВЕННИКОВ:
								</h3>
								<p class="text-[15px] leading-relaxed mb-3">
									Вам останется внести данные всех путешественников и выбрать способ оплаты
									банковской картой, затем нажать кнопку
									<strong>«Забронировать места»</strong>.
								</p>
								<h4 class="text-base font-semibold text-gray-900 mb-2">
									Обратите внимание
								</h4>
								<p class="text-[15px] leading-relaxed">
									На нашем сайте вы не платите никаких наценок — только цену тревел-эксперта.
									Цена тура, которую вы видите, действует только в данный момент времени. Если
									он вам нравится, рекомендуем оплатить тур прямо сейчас — позже цена может
									измениться.
								</p>
							</div>
						</div>

						<!-- Оплата бронирования -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ОПЛАТА БРОНИРОВАНИЯ:
								</h3>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>Введите данные своей банковской карты;</li>
									<li>Подтвердите оплату с помощью безопасного платежного шлюза;</li>
									<li>
										После успешной оплаты вы получите подтверждение бронирования и письмо на
										вашу почту.
									</li>
								</ul>
							</div>
						</div>

						<!-- Получайте подтверждение -->
						<div class="grid md:grid-cols-2 gap-8 items-start">

							<div>
								<h3 class="text-lg font-semibold text-gray-900 mb-3">
									ПОЛУЧАЙТЕ ПОДТВЕРЖДЕНИЕ:
								</h3>
								<p class="text-[15px] leading-relaxed mb-3">
									Информация о заказе высылается вам на электронную почту, а также
									сохраняется в вашем профиле.
								</p>

								<h4 class="text-base font-semibold text-gray-900 mb-2">
									Вам нужно распечатать перед вылетом:
								</h4>
								<ul class="list-disc pl-5 space-y-1 text-[15px]">
									<li>Авиабилеты (билеты приобретаются самостоятельно)</li>
									<li>Письмо с подтверждением (или информацию с сайта)</li>
									<li>Медицинскую страховку</li>
								</ul>

								<p class="text-[15px] leading-relaxed mt-3">
									До вылета убедитесь, что договорились с тревел-экспертом о месте встречи.
								</p>

								<p class="mt-4 text-[15px] leading-relaxed font-semibold text-purple-700">
									Отправляйтесь на поиски лучшего авторского тура прямо сейчас.
								</p>
							</div>
						</div>

					</section>
				</div>
			</div>
		</section>
	</main>
  </div>
</template>
