<!-- // Generated from project/α¡1/page of support/to-change-the-tour.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041c\u043e\u0433\u0443 \u043b\u0438 \u044f \u043f\u043e\u043c\u0435\u043d\u044f\u0442\u044c \u043e\u0434\u0438\u043d \u0442\u0443\u0440 \u043d\u0430 \u0434\u0440\u0443\u0433\u043e\u0439 \u043f\u043e\u0441\u043b\u0435 \u043e\u043f\u043b\u0430\u0442\u044b \u2014 YouTravel.me", link: [], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/to-change-the-tour-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
		<!-- Хлебные крошки -->
		<nav class="text-xs sm:text-sm text-gray-500 mb-4">
			<a href="#" class="hover:underline">Главная</NuxtLink>
			<span class="mx-2">›</span>
			<a href="#" class="hover:underline">Поддержка</NuxtLink>
			<span class="mx-2">›</span>
			<span class="text-gray-700">Могу ли я поменять один тур на другой после оплаты?</span>
		</nav>

		<!-- Заголовок раздела -->
		<h1 class="text-2xl sm:text-3xl font-extrabold text-ytPurple mb-6">Оплаты</h1>

		<!-- Контент -->
		<section class="space-y-5 text-[15px] leading-relaxed text-gray-700">
			<h2 class="text-xl font-semibold text-gray-900">
				Могу ли я поменять один тур на другой после оплаты?
			</h2>

			<p>
				Это возможно в исключительных случаях. При этом условия и размер возврата предоплаты
				по заменяемому туру учитываются в соответствии с правилами и сроками возврата.
			</p>

			<p>
				Если вам нужна консультация по возможности перебронирования с одного тура на другой,
				пожалуйста, обратитесь в
				<a href="#" class="text-ytPurple font-semibold hover:underline">чат поддержки</NuxtLink>
				на сайте.
			</p>
		</section>
	</main>
  </div>
</template>
