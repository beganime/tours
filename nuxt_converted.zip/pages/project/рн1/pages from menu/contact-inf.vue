<!-- // Generated from project/α¡1/pages from menu/contact-inf.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f \u2014 YouTravel.Me", link: [{"href": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css", "rel": "stylesheet"}, {"rel": "stylesheet", "href": "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"}, {"src": "/inline/contact-inf-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-[420px] lg:max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Контактная информация</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">

				<!-- Номер -->
				<label class="text-sm font-medium text-gray-700 label-lg">Номер телефона</label>
				<div class="field-lg flex items-center gap-6">

					<input id="phone" type="tel" class="ytm-input" />
				</div>

				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Это блок скрыт для всех пользователей. Информация, которая здесь указана, позволяет быстрее совершать
						бронирования.</p>
				</div>
				<!-- Страна . Регион -->
				<label class="text-sm font-medium text-gray-700 label-lg">Страна/Регион</label>
				<select class="ytm-input" id='countrySelect'>
					<option value="">Загрузка списка стран…</option>
				</select>



				<!-- Город -->
				<label class="text-sm font-medium text-gray-700 label-lg">Город</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Адрес проживания -->
				<label class="text-sm font-medium text-gray-700 label-lg">Адрес проживания</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Индекс -->
				<label class="text-sm font-medium text-gray-700 label-lg">Индекс проживания</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Электронная почта -->
				<label class="text-sm font-medium text-gray-700 label-lg">Электронная почта</label>
				<input class="ytm-input field-lg" type="email" />
		</section>
	</main>
  </div>
</template>
