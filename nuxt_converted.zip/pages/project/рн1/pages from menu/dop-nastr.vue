<!-- // Generated from project/α¡1/pages from menu/dop-nastr.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f \u2014 YouTravel.Me", link: [{"href": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<main class="max-w-[420px] lg:max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Дополнительные настройки</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">
				<!-- Язык уведомлений -->
				<label class="text-sm font-medium text-gray-700 label-lg">Язык уведомлений</label>
				<select class="ytm-input field-lg">
					<option>Русский</option>
					<option>English</option>
				</select>


				<!-- Подключить Мессенджеры -->
				<button class="text-sm font-medium rounded text-white field-lg bg-[#abc323] py-2">Подключить
					Мессенджеры</button>
				<!-- Подключить Текущее Устройство -->
				<button class="text-sm font-medium  rounded text-white field-lg bg-[#abc323] py-2">Подключить Текущее
					Устройство</button>
				<!-- Подсказка справа -->
				<label for="" class="field-lg">

					<input type="checkbox" id="push-notifications"
						class="h-5 w-5 text-[#abc323] border-gray-300 rounded field-lg" />
					<span class="text-sm font-medium text-gray-700 field-lg">Получать push-уведомления</span>
				</label>

				<div class=" right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Необходимо разрешить получение уведомлений в браузере</p>
				</div>
				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Ваш профиль станет профилем организатора авторских туров. Вы по-прежнему сможете осуществлять бронирования,
						но часть
						функций путешественника будет отключено.
						Данное изменение необратимо.</p>
				</div>
				<!-- Стать Тревел-Экспертом -->
				<button class="text-sm rounded font-medium text-white field-lg bg-[#abc323] py-2">Стать
					Тревел-Экспертом</button>

			</div>
		</section>
		<p class='text-sm text-gray-500 my-10'>Удалить аккаунт Внимание! Ваш аккаунт и все связанные с ним данные будут
			удалены.
		</p>
		<button class="text-sm font-medium text-white w-full py-3 field-lg bg-[#abc323] py-2 rounded">СОХРАНИТЬ НАСТРОЙКИ
			ПРОФИЛЯ</button>
	</main>
  </div>
</template>
