<!-- // Generated from project/α¡1/pages from menu/input.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u0422\u0435\u043b\u0435\u0444\u043e\u043d \u0441 \u0444\u043b\u0430\u0433\u043e\u043c", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<label class="flex items-center space-x-3">
		<input type="checkbox" id="push-notifications" class="h-5 w-5 text-[#abc323] border-gray-300 rounded" />
		<span class="text-sm font-medium text-gray-700">Получать push-уведомления</span>
	</label>
  </div>
</template>
