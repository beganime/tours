<!-- // Generated from project/α¡1/pages from menu/password.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f \u2014 YouTravel.Me", link: [{"href": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/js/all.min.js", "defer": true}, {"src": "/inline/password-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-[420px] lg:max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Пароль</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">


				<label class="text-sm font-medium text-gray-700 label-lg">Новый пароль</label>
				<div class="relative mb-4">
					<input id="new-password" type="password" class="ytm-input pr-12" placeholder="Новый пароль" />
					<button type="button" id="toggle-new-password"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
						<i class="fa-regular fa-eye"></i>
					</button>
				</div>
				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Рекомендуем использовать пароль, состоящий минимум из 6 символов.</p>
				</div>


				<!-- Фамилия -->
				<label class="text-sm font-medium text-gray-700 label-lg">Подтверждение пароля</label>
				<div class="relative mb-4">
					<input id="confirm-password" type="password" class="ytm-input pr-12" placeholder="Подтверждение пароля" />
					<button type="button" id="toggle-confirm-password"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
						<i class="fa-regular fa-eye"></i>
					</button>
				</div>

			</div>
		</section>
	</main>
	

	<!-- Скрипт для скрытия/открытия пароля -->
  </div>
</template>
