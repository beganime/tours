<!-- // Generated from project/α¡1/pages from menu/profile-final-version.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041f\u0440\u043e\u0444\u0438\u043b\u044c \u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u0442\u0435\u043b\u044f \u2014 YouTravel.Me", link: [{"href": "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css", "rel": "stylesheet"}, {"rel": "stylesheet", "href": "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/css/intlTelInput.css"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "https://cdn.jsdelivr.net/npm/intl-tel-input@18.2.1/build/js/intlTelInput.min.js"}, {"src": "/inline/profile-final-version-1.js", "defer": true}] });
</script>

<template>
  <div>
<main class="max-w-[420px] lg:max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
		<h1 class="text-2xl font-semibold mb-6">Профиль пользователя</h1>

		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Личные данные</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">

				<!-- Аватар -->
				<label class="text-sm font-medium text-gray-700 label-lg">Аватар</label>
				<div class="field-lg flex items-center gap-6">
					<div class="w-[80px] h-[80px] rounded-md bg-gray-50 border border-gray-300 flex items-center justify-center">
						<span class="text-3xl text-gray-400 select-none">+</span>
					</div>
				</div>

				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Ваши Аватар и Имя будут видны другим пользователям.</p>
				</div>

				<!-- Имя -->
				<label class="text-sm font-medium text-gray-700 label-lg">Имя</label>
				<input class="ytm-input field-lg" type="text" value="Артём" />

				<!-- Фамилия -->
				<label class="text-sm font-medium text-gray-700 label-lg">Фамилия</label>
				<input class="ytm-input field-lg" type="text" value="Губин" />

				<!-- Дата рождения -->
				<label class="text-sm font-medium text-gray-700 label-lg">Дата рождения</label>
				<div class="field-lg grid grid-cols-3 gap-2">
					<select class="ytm-input">
						<option>--</option>
					</select>
					<select class="ytm-input">
						<option>--</option>
					</select>
					<select class="ytm-input">
						<option>----</option>
					</select>
				</div>

				<!-- Пол -->
				<label class="text-sm font-medium text-gray-700 label-lg">Пол</label>
				<select class="ytm-input field-lg">
					<option>Выберите</option>
					<option>Мужской</option>
					<option>Женский</option>
				</select>
			</div>
		</section>
		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Контактная информация</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">

				<!-- Номер -->
				<label class="text-sm font-medium text-gray-700 label-lg">Номер телефона</label>
				<div class="field-lg flex items-center gap-6">

					<input id="phone" type="tel" class="ytm-input" />
				</div>

				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Это блок скрыт для всех пользователей. Информация, которая здесь указана, позволяет быстрее совершать
						бронирования.</p>
				</div>
				<!-- Страна . Регион -->
				<label class="text-sm font-medium text-gray-700 label-lg">Страна/Регион</label>
				<select class="ytm-input" id='countrySelect'>
					<option value="">Загрузка списка стран…</option>
				</select>



				<!-- Город -->
				<label class="text-sm font-medium text-gray-700 label-lg">Город</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Адрес проживания -->
				<label class="text-sm font-medium text-gray-700 label-lg">Адрес проживания</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Индекс -->
				<label class="text-sm font-medium text-gray-700 label-lg">Индекс проживания</label>
				<input class="ytm-input field-lg" type="text" />
				<!-- Электронная почта -->
				<label class="text-sm font-medium text-gray-700 label-lg">Электронная почта</label>
				<input class="ytm-input field-lg" type="email" />
		</section>
		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Пароль</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">


				<label class="text-sm font-medium text-gray-700 label-lg">Новый пароль</label>
				<div class="relative mb-4">
					<input id="new-password" type="password" class="ytm-input pr-12" placeholder="Новый пароль" />
					<button type="button" id="toggle-new-password"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
						<i class="fa-regular fa-eye"></i>
					</button>
				</div>
				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Рекомендуем использовать пароль, состоящий минимум из 6 символов.</p>
				</div>


				<!-- Фамилия -->
				<label class="text-sm font-medium text-gray-700 label-lg">Подтверждение пароля</label>
				<div class="relative mb-4">
					<input id="confirm-password" type="password" class="ytm-input pr-12" placeholder="Подтверждение пароля" />
					<button type="button" id="toggle-confirm-password"
						class="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500">
						<i class="fa-regular fa-eye"></i>
					</button>
				</div>

			</div>
		</section>
		<section class="relative bg-white border border-gray-200 p-6 sm:p-8 shadow-sm">
			<h2 class="text-lg font-semibold text-gray-800 mb-4 lg:mb-2 full-span-lg">Дополнительные настройки</h2>

			<!-- Верстка под десктоп (узкая как на скрине) -->
			<div class="panel-grid">


				<!-- Подключить Мессенджеры -->
				<button class="text-sm font-medium rounded text-white field-lg bg-[#abc323] py-2">Подключить
					Мессенджеры</button>
				<!-- Подключить Текущее Устройство -->
				<button class="text-sm font-medium  rounded text-white field-lg bg-[#abc323] py-2">Подключить Текущее
					Устройство</button>
				<!-- Подсказка справа -->
				<label for="" class="field-lg">

					<input type="checkbox" id="push-notifications"
						class="h-5 w-5 text-[#abc323] border-gray-300 rounded field-lg" />
					<span class="text-sm font-medium text-gray-700 field-lg">Получать push-уведомления</span>
				</label>

				<div class=" right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Необходимо разрешить получение уведомлений в браузере</p>
				</div>
				<!-- Подсказка справа -->
				<div class="right-lg flex items-start gap-2 text-xs text-gray-500 leading-snug">
					<i class="fa-regular fa-circle-question mt-0.5"></i>
					<p>Ваш профиль станет профилем организатора авторских туров. Вы по-прежнему сможете осуществлять бронирования,
						но часть
						функций путешественника будет отключено.
						Данное изменение необратимо.</p>
				</div>
				<!-- Стать Тревел-Экспертом -->
				<button class="text-sm rounded font-medium text-white field-lg bg-[#abc323] py-2">Стать
					Тревел-Экспертом</button>

			</div>
		</section>
		<p class='text-sm text-gray-500 my-10'>Удалить аккаунт Внимание! Ваш аккаунт и все связанные с ним данные будут
			удалены.
		</p>
		<button class="text-sm font-medium text-white w-full py-3 field-lg bg-[#abc323] py-2 rounded">СОХРАНИТЬ НАСТРОЙКИ
			ПРОФИЛЯ</button>
	</main>
  </div>
</template>
