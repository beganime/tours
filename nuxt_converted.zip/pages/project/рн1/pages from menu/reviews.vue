<!-- // Generated from project/α¡1/pages from menu/reviews.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "\u041e\u0442\u0437\u044b\u0432\u044b \u2014 YouTravel", link: [], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- MAIN CONTENT -->
	<main class="min-h-screen flex flex-col items-center justify-start pt-16 px-4">
		<section class="w-full max-w-3xl bg-white rounded-2xl  p-8">
			<h1 class="text-2xl font-extrabold text-indigo-800 mb-4">Отзывы</h1>
			<p class="text-gray-500 leading-relaxed">
				У вас пока нет опубликованных отзывов. <br>
				Чтобы оставить отзыв на тур, перейдите в раздел <span class="font-medium text-indigo-600">Мои
					бронирования</span> и нажмите на кнопку <span class="font-medium text-indigo-600">Оставить отзыв</span>.
			</p>
		</section>
	</main>
  </div>
</template>
