<!-- // Generated from project/α¡1/typetrips/bucket-list-destinations.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/bucket-list-destinations-1.js", "defer": true}] });
</script>

<template>
  <div>
<!-- Background section -->
    <section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center mb-5" style="background-image: url('https://strapi-imaginary.weroad.it/resource/cover/3956/.webp');">
        <!-- Overlay -->
        <div class="absolute inset-0 bg-black/30"></div>
        <!-- Title -->
        <h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
            Where's on your bucket list?
        </h1>
    </section>
    <section class='text-gray-900'>
        <header class="w-full mx-auto center py-4">
            <nav class="mx-auto max-w-6xl px-4 py-4 center">
                <ol class="flex items-center gap-2 text-sm text-gray-500 justify-center">
                    <!-- home -->
                    <li class="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m3 10.5 9-7.5 9 7.5M4.5 9.75V21h6v-6h3v6h6V9.75" />
                        </svg>
                        <span>Travel styles
                        </span>
                    </li>
                    <li class="text-gray-400">></li>
                    <li class="text-gray-600">Bucket list
                    </li>
                </ol>
            </nav>
        </header>
        <!-- Hero / Title block -->
        <div class="bg-black">
            <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center bg-black">
                <h1 class="text-3xl font-extrabold tracking-tight mb-4 text-white">
                    Unlock dream destinations with bucket list trips.
                </h1>
                <p class="text-white leading-relaxed mb-8">
                    Prepare to hike through mountains, explore dense jungles, and immerse yourself in breathtaking landscapes. From the Taj Mahal, to sleeping in the Sahara Desert, conquering mountain peaks or chasing the mesmerizing Northern Lights - these exhilarating experiences will push your limits and create unforgettable memories. Brace yourself for heart-pounding excitement as you join us on these remarkable journeys, designed to showcase the marvels of our world and take you to your ultimate bucket list destinations.
                </p>
            </main>
            <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center bg-black">
                <h1 class="text-3xl font-extrabold tracking-tight mb-4 text-white">
                    So, where will you go?
                </h1>
            </main>
    </section>
    <!-- ===== CARDS SLIDER (замена старой сетки) ===== -->
    <div class="bg-black">
        <section class="max-w-7xl mx-auto px-4 pb-6 bg-black">
            <div class="relative">
                <!-- arrows -->
                <button id="prev" aria-label="Previous" class="navbtn absolute -left-2 top-1/2 -translate-y-1/2 z-20">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M15.7 5.7a1 1 0 0 1 0 1.4L10.8 12l4.9 4.9a1 1 0 1 1-1.4 1.4l-5.6-5.6a1 1 0 0 1 0-1.4l5.6-5.6a1 1 0 0 1 1.4 0z" /></svg>
                </button>
                <button id="next" aria-label="Next" class="navbtn absolute -right-2 top-1/2 -translate-y-1/2 z-20">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path d="M8.3 18.3a1 1 0 0 1 0-1.4L13.2 12 8.3 7.1a1 1 0 1 1 1.4-1.4l5.6 5.6a1 1 0 0 1 0 1.4l-5.6 5.6a1 1 0 0 1-1.4 0z" /></svg>
                </button>
                <!-- viewport -->
                <div class="overflow-hidden">
                    <ul id="track" class="flex gap-6 will-change-transform transition-transform duration-400 ease-out touch-pan-y">
                        <!-- Slide 1 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="New York 360" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="New York 360°: discovering Manhattan, Brooklyn and Harlem" data-days="8 days • 7 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <span class="absolute left-3 top-3 chip">Top seller</span>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.7</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">
                                        New York 360°:<br> discovering Manhattan, Brooklyn and Harlem
                                    </h3>
                                    <div class="mt-2 flex items-center gap-3 text-[13px]">
                                        <span class="opacity-90">From <span class="font-bold">$ 1,033</span> <span class="line-through opacity-70">$ 1,160</span></span>
                                        <span class="price-pill">-11%</span>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 2 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1505764706515-aa95265c5abc?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Cuba 360" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Cuba 360°: from Havana to Trinidad" data-days="9 days • 8 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <span class="absolute left-3 top-3 chip">Top seller</span>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.7</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">
                                        Cuba 360°: from<br> Havana to Trinidad
                                    </h3>
                                    <div class="mt-2 flex items-center gap-3 text-[13px]">
                                        <span class="opacity-90">From <span class="font-bold">$ 1,335</span></span>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 3 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Sweden" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Sweden: Northern Lights and Lapland" data-days="7 days • 6 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">
                                        Sweden: Northern<br> Lights and Lapland
                                    </h3>
                                    <div class="mt-2 flex items-center gap-3 text-[13px]">
                                        <span class="opacity-90">From <span class="font-bold">$ 1,532</span> <span class="line-through opacity-70">$ 1,800</span></span>
                                        <span class="price-pill">-14%</span>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 4 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1521295121783-8a321d551ad2?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Nepal 360" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Nepal 360°: the temples of Kathmandu and the peaks of Annapurna" data-days="8 days • 7 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">
                                        Nepal 360°: the temples of Kathmandu and the peaks of Annapurna
                                    </h3>
                                    <div class="mt-2 flex items-center gap-3 text-[13px]">
                                        <span class="opacity-90">From <span class="font-bold">$ 893</span> <span class="line-through opacity-70">$ 986</span></span>
                                        <span class="price-pill">-9%</span>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 5 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Iceland" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Iceland: Hunting the Northern Lights" data-days="8 days • 7 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <span class="absolute left-3 top-3 chip">Top seller</span>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">
                                        Iceland: Hunting the<br> Northern Lights
                                    </h3>
                                    <div class="mt-2 flex items-center gap-3 text-[13px]">
                                        <span class="opacity-90">From <span class="font-bold">$ 1,532</span> <span class="line-through opacity-70">$ 1,800</span></span>
                                        <span class="price-pill">-14%</span>
                                    </div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 6 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1549890762-0a3f8933bcf7?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Cuba street" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Havana streets photo walk" data-days="5 days • 4 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">Havana streets photo walk</h3>
                                    <div class="mt-2 text-[13px] opacity-90">From <span class="font-bold">$ 980</span></div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 7 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1526481280698-8fcc13fd0f3b?q=80&w=1200&auto=format&fit=crop" class="w-full h-[370px] object-cover" alt="Peru" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Peru on the road" data-days="10 days • 9 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">Peru on the road</h3>
                                    <div class="mt-2 text-[13px] opacity-90">From <span class="font-bold">$ 1,890</span></div>
                                </div>
                            </article>
                        </li>
                        <!-- Slide 8 -->
                        <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
                            <article class="relative rounded-2xl overflow-hidden">
                                <img src="    https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=1600&auto=format&fit=crop" class="w-full h-[370px] object-contain bg-gray-100" alt="Morocco" />
                                <div class="card-grad"></div>
                                <button class="absolute top-3 right-3 heart cursor-pointer" aria-label="Save to wishlist" data-trip="Morocco Desert & Atlas" data-days="8 days • 7 nights">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" /></svg>
                                </button>
                                <div class="absolute left-3 right-3 bottom-3 text-white">
                                    <div class="flex items-center gap-2 mb-2">
                                        <div class="rating-stars">
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                            <div class="star"><svg viewBox="0 0 24 24">
                                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z" /></svg></div>
                                        </div>
                                        <span class="text-xs font-bold">4.8</span>
                                    </div>
                                    <h3 class="text-[21px] font-extrabold leading-tight">Morocco Desert &amp; Atlas</h3>
                                    <div class="mt-2 text-[13px] opacity-90">From <span class="font-bold">$ 1,290</span></div>
                                </div>
                            </article>
                        </li>
                    </ul>
                </div>
                <!-- dots -->
                <div id="dots" class="flex items-center justify-center gap-2 mt-4"></div>
            </div>
        </section>
        <!-- ===== Modal (wishlist) ===== -->
        <div id="modal" class="fixed inset-0 hidden z-40">
            <div class="absolute inset-0 backdrop"></div>
            <div id="dialog" role="dialog" aria-modal="true" class="modal-enter absolute left-1/2 top-[18vh] -translate-x-1/2 w-[90%] max-w-[520px] rounded-2xl bg-white shadow-2xl p-5">
                <div class="flex items-center justify-between">
                    <h4 class="text-[18px] font-semibold">Save trip in your wishlist</h4>
                    <button id="closeModal" aria-label="Close" class="text-gray-500 hover:text-gray-700">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M6.2 5.2 5.2 6.2 10.99 12 5.2 17.8l1 1 5.8-5.8 5.8 5.8 1-1-5.79-5.8 5.8-5.8-1-1-5.8 5.8L6.2 5.2Z" /></svg>
                    </button>
                </div>
                <div id="tripBox" class="mt-4 flex items-center gap-3 rounded-xl border border-gray-200 p-3">
                    <div class="w-8 h-8 rounded-full bg-gray-100 grid place-items-center">
                        <svg viewBox="0 0 24 24" fill="none" stroke="#111827" stroke-width="1.8" class="w-4 h-4">
                            <path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z" />
                        </svg>
                    </div>
                    <div class="text-sm">
                        <div id="tripName" class="font-semibold">Sweden: Northern Lights and Lapland</div>
                        <div id="tripDays" class="text-gray-600">7 days • 6 nights</div>
                    </div>
                </div>
                <label class="block mt-5 text-sm font-medium">Your email</label>
                <div class="mt-2 flex items-center gap-2">
                    <input id="email" type="email" placeholder="Your email" class="flex-1 rounded-lg border border-gray-300 px-3 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-gray-300 focus:border-gray-300" />
                    <button id="submitWish" class="w-10 h-10 rounded-lg bg-gray-800 text-white grid place-items-center hover:bg-black" aria-label="Save">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" class="w-5 h-5">
                            <path d="M20 6 9 17l-5-5" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    </div>
    </div>
    <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center">
        <h1 class="text-3xl font-extrabold tracking-tight mb-4">
            So, where will you go?
        </h1>
    </main>
    <!-- ===== Slider script (после разметки!) ===== -->
  </div>
</template>
