<!-- // Generated from project/α¡1/typetrips/card-hist.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Classic 360\u00b0 Adventures", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<div class="bg-white rounded-2xl shadow-md overflow-hidden max-w-6xl w-full flex flex-col md:flex-row">

		<!-- Left: Image -->
		<div class="md:w-1/2">
			<img
				src="https://strapi-imaginary.weroad.it/resource/webp-medium/19312/viaggio-nepal-avventura-pokhara-barca-inver.webp"
				alt="Adventure in Nepal" class="w-full h-full object-cover" />
		</div>

		<!-- Right: Text -->
		<div class="md:w-1/2 p-8 flex flex-col justify-center">
			<p class="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-2">
				Classic 360° Adventures
			</p>
			<h2 class="text-2xl font-extrabold text-gray-900 mb-4 leading-snug">
				They are perfect for you if...
			</h2>
			<p class="text-gray-700 leading-relaxed text-sm md:text-base">
				You want to make the most of every minute of the trip to fully experience the local tradition and culture:
				<span class="font-semibold text-gray-900">early wake-ups, long transfers, frequent changes of
					accommodation</span>
				don’t scare you... on the contrary, they <span class="font-semibold text-gray-900">excite</span> you!
				You want that adrenaline that only an <span class="font-semibold text-gray-900">adventure trip around the
					world</span>
				can give you! But that’s not all: you like <span class="font-semibold text-gray-900">authentic
					experiences</span>
				because an adventure is only true if it allows you to discover new sides of the world and of yourself and to
				meet
				new people, from your travel companions to the locals. The hard part is, of course, choosing the destination –
				but we’re here for that, aren’t we?
			</p>
		</div>

	</div>
  </div>
</template>
