<!-- // Generated from project/α¡1/typetrips/roadtr.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "The old continent", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/roadtr-1.js", "defer": true}] });
</script>

<template>
  <div>
<!-- Background section -->
    <section class="relative w-full h-[100vh] bg-center bg-cover flex items-center justify-center mb-5" style="background-image: url('https://strapi-imaginary.weroad.it/resource/webp-cover/21800/.webp');">
        <!-- Overlay -->
        <div class="absolute inset-0 bg-black/30"></div>
        <!-- Title -->
        <h1 class="relative text-white text-4xl md:text-6xl font-extrabold text-center drop-shadow-lg">
            Group road trips
        </h1>
    </section>
    <section class='text-gray-900'>
        <header class="w-full mx-auto center mb-20">
            <nav class="mx-auto max-w-6xl px-4 py-4 center">
                <ol class="flex items-center gap-2 text-sm text-gray-500 justify-center">
                    <!-- home -->
                    <li class="flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m3 10.5 9-7.5 9 7.5M4.5 9.75V21h6v-6h3v6h6V9.75" />
                        </svg>
                        <span>Trip types
                        </span>
                    </li>
                    <li class="text-gray-400">></li>
                    <li class="text-gray-600">On the road
                    </li>
                </ol>
            </nav>
        </header>
        <!-- Hero / Title block -->
        <main class="mx-auto max-w-4xl px-4 pt-6 pb-12 text-center">
            <h1 class="text-3xl font-extrabold tracking-tight mb-4">
                It's about the journey...
            </h1>
            <p class="text-gray-600 leading-relaxed mb-8">
                We’ll start with a quote that sets the tone – because this isn’t your average trip. <em>Our curated collection
                    of on-the-road group adventures is the real deal:</em> journeys on two or four wheels (or sometimes none at
                all — we’re not here to nitpick) designed to help you discover a
                destination the best way there is: slowly. That’s the beauty of a road trip — <em>
                    you call the shots</em>. Stop to soak in a breathtaking view, or stumble upon a hidden café that hasn’t even
                made it to Google Maps. Think<em> Canada, Iceland, the legendary Route 66 in the U.S. So here’s the big
                    question:
                    Where to next? And just as important —
                    what’s your ride?</em>On this page, you'll find all of our group road trips.
            </p>
        </main>
    </section>
    <section class='flex flex-col items-center justify-center pb-12'>
        <section class="grid place-items-center bg-white p-8">
            <!-- просто сделали соседями -->
            <div class="cards">
                <!-- Card 1 -->
                <div class="w-[180px]">
                    <div class="relative w-[180px] h-[174px] rounded-2xl overflow-hidden select-none">
                        <img src="https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1200&auto=format&fit=crop" alt="Iceland waterfall" class="absolute inset-0 w-full h-full object-cover" />
                        <div class="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/65 via-black/20 to-transparent pointer-events-none"></div>
                        <div class="absolute right-2 top-2 grid place-items-center w-7 h-7 rounded-full bg-black/15">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-[20px] h-[20px] wishlist-heart" tabindex="0" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.034-4.5-4.543-4.5-1.59 0-2.99.83-3.75 2.078A4.327 4.327 0 0 0 9 3.75C6.49 3.75 4.5 5.765 4.5 8.25c0 7.125 7.5 10.5 7.5 10.5s9-3.375 9-10.5Z" />
                            </svg>
                        </div>
                        <!-- badge -->
                        <span class="absolute left-2.5 top-28 text-[11px] font-extrabold text-white bg-black rounded px-2 py-[3px] shadow">
                            Top seller
                        </span>
                        <div class="absolute inset-x-0 bottom-2 flex items-center justify-between px-2.5 text-white">
                            <span class="text-[14px] font-extrabold">5 days</span>
                            <span class="flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] h-[18px]" viewBox="0 0 24 24" aria-hidden="true">
                                    <path class="star-fill" d="M12 .9l3.2 6.5 7.2 1.1-5.2 5.1 1.2 7L12 17.7l-6.4 3.9 1.2-7-5.2-5.1 7.2-1.1L12 .9z" />
                                </svg>
                                <span class="text-[14px] font-extrabold">4.8</span>
                            </span>
                        </div>
                    </div>
                    <div style="

        margin-top:10px;

        font-family: Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;

        color:#2b2f36;

        -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;

      ">
                        <div style="font-weight:600; font-size:14px; line-height:20px; letter-spacing:-0.01em;">
                            Iceland Express:<br>
                            Reykjavik and the Golden<br>
                            Circle
                        </div>
                        <div style="margin-top:6px; font-size:13px; color:#8b919a;">
                            From $ 928
                        </div>
                    </div>
                </div>
                <!-- Card 2 -->
                <div class="w-[180px]">
                    <div class="relative w-[180px] h-[174px] rounded-2xl overflow-hidden select-none">
                        <img src="https://images.unsplash.com/photo-1549880338-65ddcdfd017b?q=80&w=1200&auto=format&fit=crop" alt="Iceland waterfall" class="absolute inset-0 w-full h-full object-cover" />
                        <div class="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/65 via-black/20 to-transparent pointer-events-none"></div>
                        <div class="absolute right-2 top-2 grid place-items-center w-7 h-7 rounded-full bg-black/15">
                            <svg xmlns="http://www.w3.org/2000/svg" class="w-[20px] h-[20px] wishlist-heart" tabindex="0" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.034-4.5-4.543-4.5-1.59 0-2.99.83-3.75 2.078A4.327 4.327 0 0 0 9 3.75C6.49 3.75 4.5 5.765 4.5 8.25c0 7.125 7.5 10.5 7.5 10.5s9-3.375 9-10.5Z" />
                            </svg>
                        </div>
                        <!-- badge -->
                        <span class="absolute left-2.5 top-28 text-[11px] font-extrabold text-white bg-black rounded px-2 py-[3px] shadow">
                            Top seller
                        </span>
                        <div class="absolute inset-x-0 bottom-2 flex items-center justify-between px-2.5 text-white">
                            <span class="text-[14px] font-extrabold">5 days</span>
                            <span class="flex items-center gap-1">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-[18px] h-[18px]" viewBox="0 0 24 24" aria-hidden="true">
                                    <path class="star-fill" d="M12 .9l3.2 6.5 7.2 1.1-5.2 5.1 1.2 7L12 17.7l-6.4 3.9 1.2-7-5.2-5.1 7.2-1.1L12 .9z" />
                                </svg>
                                <span class="text-[14px] font-extrabold">4.8</span>
                            </span>
                        </div>
                    </div>
                    <!-- Morocco text + discount -->
                    <div style="

        margin-top:10px;

        font-family: Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif;

        color:#2b2f36;

        -webkit-font-smoothing:antialiased; -moz-osx-font-smoothing:grayscale;

      ">
                        <div style="font-weight:600; font-size:14px; line-height:20px; letter-spacing:-0.01em;">
                            Morocco Express:<br>
                            Marrakech, Essaouira<br>
                            and the Desert
                        </div>
                        <div style="

          margin-top:8px; font-size:13px; color:#8b919a;

          display:flex; align-items:center; gap:8px; flex-wrap:wrap;

        ">
                            <span>From</span>
                            <span style="color:#0d9488; font-weight:600;">$ 603</span>
                            <span style="text-decoration:line-through;">$ 696</span>
                            <span style="

            color:#0d9488; background:#e6f6f3;

            font-weight:700; border-radius:10px; padding:2px 8px; font-size:12px;

          ">-13%</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- wishlist modal (added without touching cards) -->
            <div id="wlOverlay" class="hidden fixed inset-0 z-40 backdrop"></div>
            <section id="wlModal" class="hidden fixed inset-0 z-50 grid place-items-center px-4">
                <div class="bg-white w-full max-w-[560px] md:max-w-[620px] rounded-2xl shadow-xl">
                    <div class="flex items-start justify-between px-6 pt-6">
                        <h3 class="text-[20px] md:text-[22px] font-semibold">Save trip in your wishlist</h3>
                        <button id="wlClose" class="p-2 text-[#6b7280] hover:text-[#111]" aria-label="Close">✕</button>
                    </div>
                    <div class="mx-6 mt-4 rounded-lg border border-[#e8eaee] bg-[#f6f7f9]">
                        <div class="flex gap-3 items-start p-4">
                            <div class="mt-[2px]">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="#8b919a" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M21 8.25c0-2.485-2.034-4.5-4.543-4.5-1.59 0-2.99.83-3.75 2.078A4.327 4.327 0 0 0 9 3.75C6.49 3.75 4.5 5.765 4.5 8.25c0 7.125 7.5 10.5 7.5 10.5s9-3.375 9-10.5Z" />
                                </svg>
                            </div>
                            <div class="flex-1">
                                <div id="wlTitle" class="font-semibold text-[14px] leading-5"></div>
                                <div id="wlMeta" class="mt-1 text-[13px] text-[#6b7280]"></div>
                            </div>
                        </div>
                    </div>
                    <div class="px-6 mt-5 text-[14px]">Your email</div>
                    <form id="wlForm" class="flex items-center gap-3 px-6 pb-6 pt-2">
                        <input id="wlEmail" type="email" required placeholder="Your email" class="flex-1 h-11 px-3 rounded-lg border border-[#dfe3e8] focus:border-[#aab2bd] outline-none" />
                        <button class="grid place-items-center w-12 h-11 rounded-lg bg-[#2b2f36] text-white hover:brightness-95" aria-label="Confirm">✓</button>
                    </form>
                </div>
            </section>
        </section>
    </section>
    <section class='flex items-center justify-center min-h-screen p-4'>
        <div class="bg-white rounded-2xl shadow-md overflow-hidden max-w-6xl w-full flex flex-col md:flex-row">
            <!-- Left: Image -->
            <div class="md:w-1/2">
                <img src="https://strapi-imaginary.weroad.it/resource/webp-medium/21801/.webp" alt="Adventure in Nepal" class="w-full h-full object-cover" />
            </div>
            <!-- Right: Text -->
            <div class="md:w-1/2 p-8 flex flex-col justify-center border-[10px]  border-gray-200">
                <p class="text-xs uppercase tracking-widest text-gray-500 font-semibold mb-2">
                    GROUP ROAD TRIPS
                </p>
                <h2 class="text-2xl font-extrabold text-gray-900 mb-4 leading-snug">
                    Perfect for you if ...
                </h2>
                <p class="text-gray-700 leading-relaxed text-sm md:text-base">
                    You love the thrill of the open road — the kind of travel where the real magic happens between point A and
                    point B. It’s
                    about catching the unexpected, spotting that quirky roadside diner, or pulling over just because the view
                    demands it.
                    You want to be wide awake for the good stuff, not snoozing through it on a bus.<br><br>To you, the open road
                    means freedom, and you’ve got at least eight Spotify playlists to prove it, ranging from
                    <em>
                        shout-your-heart-out anthems to moody granola indie vibes for staring at the horizon and pondering the
                        meaning
                        of life.
                    </em>
                </p>
            </div>
        </div>
    </section>
  </div>
</template>
