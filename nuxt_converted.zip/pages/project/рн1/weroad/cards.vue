<!-- // Generated from project/α¡1/weroad/cards.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "WeRoad \u2014 Overlapping Cards Replica", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Section -->
	<section
		class="relative flex flex-col md:flex-row items-center justify-center py-24 px-6 md:px-20 bg-gradient-to-r from-[#dff1ff] to-[#f4f2ff]">

		<!-- Left overlapping cards -->
		<div class="relative flex items-center justify-center md:w-1/2 mb-10 md:mb-0">

			<!-- Back card -->
			<div class="card w-72 md:w-80 transform translate-x-10 translate-y-8 z-0">
				<img src="https://strapi-imaginary.weroad.it/resource/medium/231556/"
					alt="Tennis Social: Make Friends & Stay Active" class="w-full h-48 object-cover">
				<div class="p-4">
					<div class="flex items-center text-gray-500 text-sm mb-1">
						<span class="flex items-center mr-2">🕒 19:00</span>
						<span class="flex items-center">📍 London</span>
					</div>
					<h3 class="text-gray-900 font-semibold text-sm leading-snug mb-2">
						Tennis Social: Make Friends & Stay Active
					</h3>
					<div class="flex items-center justify-between text-xs text-gray-500 mb-3">
						<span>21 AUG</span>
						<span>London</span>
					</div>
					<div class="flex items-center gap-2 text-xs">
						<span class="bg-gray-100 px-2 py-0.5 rounded">Sport</span>
						<span class="bg-gray-100 px-2 py-0.5 rounded">Free entry</span>
					</div>
					<div class="flex items-center mt-3">
						<img src="https://randomuser.me/api/portraits/men/77.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<img src="https://randomuser.me/api/portraits/women/30.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<img src="https://randomuser.me/api/portraits/men/24.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<span class="text-xs text-gray-500 ml-2">13 going</span>
					</div>
				</div>
			</div>

			<!-- Front card -->
			<div class="absolute top-0 left-0 card w-72 md:w-80 transform -rotate-1 -translate-x-8 -translate-y-6 z-10">
				<img src="https://strapi-imaginary.weroad.it/resource/medium/231555/" alt="Board Games & New Friends"
					class="w-full h-48 object-cover">
				<div class="p-4">
					<div class="flex items-center text-gray-500 text-sm mb-1">
						<span class="flex items-center mr-2">🕒 18:30</span>
						<span class="flex items-center">📍 London</span>
					</div>
					<h3 class="text-gray-900 font-semibold text-sm leading-snug mb-2">
						Board Games & New Friends
					</h3>
					<div class="flex items-center justify-between text-xs text-gray-500 mb-3">
						<span>19 AUG</span>
						<span>London</span>
					</div>
					<div class="flex items-center gap-2 text-xs">
						<span class="bg-gray-100 px-2 py-0.5 rounded">Free entry</span>
						<span class="bg-gray-100 px-2 py-0.5 rounded">Entertainment & Free Time</span>
					</div>
					<div class="flex items-center mt-3">
						<img src="https://randomuser.me/api/portraits/women/68.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<img src="https://randomuser.me/api/portraits/men/32.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<img src="https://randomuser.me/api/portraits/women/12.jpg"
							class="w-6 h-6 rounded-full -ml-1 border border-white" alt="">
						<span class="text-xs text-gray-500 ml-2">10 going</span>
					</div>
				</div>
			</div>

		</div>

		<!-- Right side text -->
		<div class="md:w-1/2 text-center md:text-left md:pl-16">
			<h2 class="text-3xl md:text-4xl font-extrabold text-gray-800 mb-3 leading-snug">
				And if doesn't exist yet…
			</h2>
			<p class="text-gray-600 mb-6 leading-relaxed max-w-md mx-auto md:mx-0">
				We like the proactivity. You bring your ideas and passions, we give you tools and visibility — it’s a double
				win!
			</p>
			<button class="bg-rose-500 hover:bg-rose-600 text-white font-semibold px-8 py-3 rounded-md shadow">
				Create your event!
			</button>
		</div>

	</section>
  </div>
</template>
