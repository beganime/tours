<!-- // Generated from project/α¡1/weroad/good-vb.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Good vibes confirmed", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- Section -->
	<section class="w-full max-w-6xl text-center">
		<h2 class="text-2xl md:text-3xl font-bold text-gray-800 mb-3">
			Good vibes, confirmed!
		</h2>
		<p class="text-gray-500 text-sm md:text-base mb-12">
			You can read the reviews here, but next time we suggest you ask them in real life – you just need to join the next
			event.
		</p>

		<div class="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-6">

			<!-- Card 1 -->
			<div class="text-center">
				<span class="text-2xl text-gray-400 block mb-3">❝</span>
				<p class="text-sm text-gray-700 mb-4 leading-relaxed">
					I really loved the chill and cozy atmosphere.<br>
					Amazing food and made some new friend.
				</p>
				<img src="https://randomuser.me/api/portraits/women/45.jpg" alt="Amy"
					class="w-10 h-10 rounded-full mx-auto mb-2">
				<p class="font-medium text-sm">Amy</p>
				<p class="text-xs text-gray-500">32, Designer</p>
			</div>

			<!-- Card 2 -->
			<div class="text-center">
				<span class="text-2xl text-gray-400 block mb-3">❝</span>
				<p class="text-sm text-gray-700 mb-4 leading-relaxed">
					WeMeet is my happy place. I’ve been waiting<br>
					for a community like this.
				</p>
				<img src="https://randomuser.me/api/portraits/men/54.jpg" alt="Carlos"
					class="w-10 h-10 rounded-full mx-auto mb-2">
				<p class="font-medium text-sm">Carlos</p>
				<p class="text-xs text-gray-500">29, Hairdresser</p>
			</div>

			<!-- Card 3 -->
			<div class="text-center">
				<span class="text-2xl text-gray-400 block mb-3">❝</span>
				<p class="text-sm text-gray-700 mb-4 leading-relaxed">
					I felt like I was back in uni. People were very<br>
					relaxed and everyone was just so nice.
				</p>
				<img src="https://randomuser.me/api/portraits/women/68.jpg" alt="Francesca"
					class="w-10 h-10 rounded-full mx-auto mb-2">
				<p class="font-medium text-sm">Francesca</p>
				<p class="text-xs text-gray-500">31, Engineer</p>
			</div>

		</div>
	</section>
  </div>
</template>
