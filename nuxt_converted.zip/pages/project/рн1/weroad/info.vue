<!-- // Generated from project/α¡1/weroad/info.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "WeMeet Events", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<!-- HEADER -->
	<section class="text-center max-w-3xl">
		<h1 class="text-2xl md:text-3xl font-extrabold mb-2">Events people can't stop talking about</h1>
		<p class="text-gray-600">
			From unforgettable nights to life-changing adventures — these are the experiences our community loves the most.
		</p>
	</section>

	<!-- 1️⃣ Running Club -->
	<section class="flex flex-col md:flex-row items-start gap-8 max-w-6xl w-full">
		<!-- Left Text -->
		<div class="flex-1">
			<button
				class="flex items-center gap-1 px-2 py-1 border border-gray-300 rounded-full text-xs font-medium text-gray-700 mb-3">
				<svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-gray-500" fill="none" viewBox="0 0 24 24"
					stroke="currentColor">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
				</svg>
				Sport
			</button>
			<h2 class="text-2xl font-bold mb-2">Running Club</h2>
			<p class="font-semibold mb-3">Discover the city, one run at a time!</p>
			<p class="text-gray-600 leading-relaxed mb-4">
				Join our Running Club and train with new friends. Whether you’re a newbie, a seasoned runner who loves company,
				or just done with lonely jogs — we got you. Check them out in Dublin, and more cities coming soon!
			</p>
			<a href="#" class="text-[#1b7a72] font-medium underline">Download WeMeet app</NuxtLink>
			<span class="text-gray-700">and train with new friends.</span>
		</div>
		<!-- Right Images -->
		<div class="flex-1 grid grid-cols-2 gap-2">
			<img src="https://strapi-imaginary.weroad.it/resource/original/232907/" alt="Running 1"
				class="w-full h-full object-cover rounded-lg col-span-2 md:col-span-1 md:row-span-2 md:h-[350px]">
			<img src="https://images.unsplash.com/photo-1520975918311-39e34c0b49e9?auto=format&fit=crop&w=400&q=80"
				alt="Running 2" class="rounded-lg object-cover h-44 w-full">
			<img src="https://images.unsplash.com/photo-1605296867304-46d5465a13f1?auto=format&fit=crop&w=400&q=80"
				alt="Running 3" class="rounded-lg object-cover h-44 w-full">
		</div>
	</section>

	<!-- 2️⃣ WeRoad Afterwork -->
	<section class="flex flex-col md:flex-row-reverse items-start gap-8 max-w-6xl w-full">
		<!-- Text -->
		<div class="flex-1">
			<button
				class="flex items-center gap-1 px-2 py-1 border border-gray-300 rounded-full text-xs font-medium text-gray-700 mb-3">
				<svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-gray-500" fill="none" viewBox="0 0 24 24"
					stroke="currentColor">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
				</svg>
				Community & Reunion
			</button>
			<h2 class="text-2xl font-bold mb-2">WeRoad Afterwork</h2>
			<p class="font-semibold mb-3">Because every trip deserves a toast!</p>
			<p class="text-gray-600 leading-relaxed mb-4">
				Ready to taste something new and raise a glass with fresh faces? Our events are the perfect excuse to meet
				like-minded (and not-so-like-minded) people and chat about your next trip!
			</p>
			<p class="text-gray-600 mb-4">
				Check them out in <span class="underline">London</span>, <span class="underline">Manchester</span>, <span
					class="underline">Dublin</span>, <span class="underline">Liverpool</span>, <span
					class="underline">Leeds</span>.
			</p>
			<a href="#" class="text-[#1b7a72] font-medium underline">Download WeMeet app</NuxtLink>
			<span class="text-gray-700">and just bring your good vibes… we’ll handle the rest!</span>
		</div>
		<!-- Images -->
		<div class="flex-1 grid grid-cols-2 gap-2">
			<img src="https://images.unsplash.com/photo-1527769929977-c341ee9f2033?auto=format&fit=crop&w=800&q=80"
				alt="Afterwork 1"
				class="w-full h-full object-cover rounded-lg col-span-2 md:col-span-1 md:row-span-2 md:h-[350px]">
			<img src="https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=400&q=80"
				alt="Afterwork 2" class="rounded-lg object-cover h-44 w-full">
			<img src="https://images.unsplash.com/photo-1589923188900-35a6b9a3d49a?auto=format&fit=crop&w=400&q=80"
				alt="Afterwork 3" class="rounded-lg object-cover h-44 w-full">
		</div>
	</section>

	<!-- 3️⃣ Dinner & New Friends -->
	<section class="flex flex-col md:flex-row items-start gap-8 max-w-6xl w-full">
		<!-- Text -->
		<div class="flex-1">
			<button
				class="flex items-center gap-1 px-2 py-1 border border-gray-300 rounded-full text-xs font-medium text-gray-700 mb-3">
				<svg xmlns="http://www.w3.org/2000/svg" class="h-3.5 w-3.5 text-gray-500" fill="none" viewBox="0 0 24 24"
					stroke="currentColor">
					<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
						d="M4 21v-8a9 9 0 0118 0v8M9 21v-8a3 3 0 016 0v8" />
				</svg>
				Food, Wine & Drinks
			</button>
			<h2 class="text-2xl font-bold mb-2">Dinner & new friends</h2>
			<p class="font-semibold mb-3">Looking to spice up your Thursday nights?</p>
			<p class="text-gray-600 leading-relaxed mb-4">
				Join us for Dinner & New Friends — a weekly culinary journey where you’ll savor mouthwatering food, explore
				hidden gems, and forge new connections.
			</p>
			<a href="#" class="text-[#1b7a72] font-medium underline">Download WeMeet app</NuxtLink>
			<span class="text-gray-700">No pretenses, just good vibes and amazing company.</span>
		</div>
		<!-- Images -->
		<div class="flex-1 grid grid-cols-2 gap-2">
			<img src="https://images.unsplash.com/photo-1564758566841-ccb6caa9b9e6?auto=format&fit=crop&w=800&q=80"
				alt="Dinner 1"
				class="w-full h-full object-cover rounded-lg col-span-2 md:col-span-1 md:row-span-2 md:h-[350px]">
			<img src="https://images.unsplash.com/photo-1579880651718-3b5e0e2d6a48?auto=format&fit=crop&w=400&q=80"
				alt="Dinner 2" class="rounded-lg object-cover h-44 w-full">
			<img src="https://images.unsplash.com/photo-1590080875838-62d0b9df00b3?auto=format&fit=crop&w=400&q=80"
				alt="Dinner 3" class="rounded-lg object-cover h-44 w-full">
		</div>
	</section>
  </div>
</template>
