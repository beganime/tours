<!-- // Generated from project/α¡1/weroad/readytm.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "Ready to make new friends?", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}] });
</script>

<template>
  <div>
<section class="relative w-full overflow-hidden">
		<!-- Текст сверху -->
		<div class="text-center mt-16 mb-8">
			<h2 class="text-xl sm:text-2xl font-extrabold mb-1">Ready to make new friends?</h2>
			<p class="text-sm text-gray-500">
				Then download the app, ’cause it’s the easiest way to join the community and find events near you.
			</p>
		</div>

		<!-- Фоновое изображение -->
		<div class="relative w-full ">
			<img src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=1920&q=80"
				alt="Running people" class="w-full h-[500px] object-cover" />

			<!-- QR код по центру фона -->
			<div class="absolute inset-0 flex items-center justify-center">
				<img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://weroad.it" alt="QR Code"
					class="w-32 h-32 bg-white p-2 rounded-lg shadow-lg" />
			</div>
		</div>
	</section>
  </div>
</template>
