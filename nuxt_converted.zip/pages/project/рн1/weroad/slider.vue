<!-- // Generated from project/α¡1/weroad/slider.html -->
<script setup lang="ts">
definePageMeta({ layout: 'default', hero: true })
useHead({ title: "City Slider \u2014 Tailwind", link: [{"href": "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap", "rel": "stylesheet"}], script: [{"src": "https://cdn.tailwindcss.com"}, {"src": "/inline/slider-1.js", "defer": true}] });
</script>

<template>
  <div>
<!-- Section -->
	<section class="w-full max-w-7xl text-center py-12 px-4 md:px-8">
		<h2 class="text-2xl md:text-3xl font-extrabold mb-2">Wherever you are, something’s happening</h2>
		<p class="text-gray-900 text-sm md:text-base mb-6 max-w-3xl mx-auto leading-relaxed">
			Whether you're chasing sunsets, street food, or new friendships, there's a city with your name on it.
			<a href="#" class="text-[#1b7a72] underline font-bold">Download the app</NuxtLink>, choose a city and start planning
			your next adventure.
		</p>

		<!-- Slider Container -->
		<div class="relative overflow-hidden">
			<div id="slider" class="flex transition-transform duration-700 ease-in-out">

				<!-- Slides (5 total, 6 cards each) -->
				<!-- Slide 1 -->
				<div class="slide min-w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 justify-center px-2 md:px-4">
					<template id="slide-template-1"></template>
				</div>

				<!-- Slide 2 -->
				<div class="slide min-w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 justify-center px-2 md:px-4">
					<template id="slide-template-2"></template>
				</div>

				<!-- Slide 3 -->
				<div class="slide min-w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 justify-center px-2 md:px-4">
					<template id="slide-template-3"></template>
				</div>

				<!-- Slide 4 -->
				<div class="slide min-w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 justify-center px-2 md:px-4">
					<template id="slide-template-4"></template>
				</div>

				<!-- Slide 5 -->
				<div class="slide min-w-full grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 justify-center px-2 md:px-4">
					<template id="slide-template-5"></template>
				</div>

			</div>

			<!-- Dots -->
			<div class="flex justify-center mt-6 space-x-2">
				<div class="dot w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-gray-300 cursor-pointer" onclick="moveToSlide(0)">
				</div>
				<div class="dot w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-gray-300 cursor-pointer" onclick="moveToSlide(1)">
				</div>
				<div class="dot w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-gray-300 cursor-pointer" onclick="moveToSlide(2)">
				</div>
				<div class="dot w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-gray-300 cursor-pointer" onclick="moveToSlide(3)">
				</div>
				<div class="dot w-2.5 h-2.5 md:w-3 md:h-3 rounded-full bg-gray-300 cursor-pointer" onclick="moveToSlide(4)">
				</div>
			</div>
		</div>
	</section>
  </div>
</template>
