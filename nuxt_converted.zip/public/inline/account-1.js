/* ===== Toggle helpers ===== */
		const show = id => document.getElementById(id).classList.remove('hidden')
		const hide = id => document.getElementById(id).classList.add('hidden')

		document.getElementById('nameEditBtn').onclick = () => show('nameForm')
		document.getElementById('phoneEditBtn').onclick = () => show('phoneForm')
		document.getElementById('passEditBtn').onclick = () => show('passForm')
		document.getElementById('emailEditBtn').onclick = () => show('emailForm')
		document.querySelectorAll('.cancelBtn').forEach(b => {
			b.addEventListener('click', () => hide(b.dataset.cancel + 'Form'))
		})

		/* ===== Name save (демо) ===== */
		document.getElementById('nameSave').onclick = () => {
			const f = document.getElementById('firstName').value.trim()
			const l = document.getElementById('lastName').value.trim()
			document.getElementById('nameView').textContent = (f + ' ' + l).trim()
			hide('nameForm')
		}

		/* ===== Password / Email demo save ===== */
		document.getElementById('passSave').onclick = () => hide('passForm')
		document.getElementById('emailSave').onclick = () => {
			const e = document.getElementById('emailInput').value.trim()
			if (e) document.getElementById('emailView').textContent = e
			hide('emailForm')
		}

		/* ===== Phone via intl-tel-input ===== */
		const phoneInput = document.getElementById('phoneField')
		const iti = window.intlTelInput(phoneInput, {
			// главный зелёный стиль совпадает с проектом
			separateDialCode: true,
			initialCountry: "ru",
			preferredCountries: ["ru", "kz", "kg", "by", "ua", "tr"],
			// автоплейсхолдер и форматирование
			autoPlaceholder: "aggressive",
			nationalMode: false, // чтобы getNumber возвращал в E.164
			utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/utils.js"
		})

		// Сохранение телефона в блок просмотра (демо)
		document.getElementById('phoneSave').onclick = () => {
			const full = iti.getNumber() // +7XXXXXXXXXX
			const data = iti.getSelectedCountryData() // { dialCode, iso2, name, … }
			// Красиво выведем: +7 ХХХ ХХХ-ХХ-ХХ (в демо без маски — можно добавить по желанию)
			document.getElementById('phoneView').textContent = full || (data ? '+' + data.dialCode : '')
			hide('phoneForm')
		}

		// При первом открытии формы — прокидываем текущий номер из просмотра (если есть)
		document.getElementById('phoneEditBtn').addEventListener('click', () => {
			const current = document.getElementById('phoneView').textContent.replace(/\s/g, '')
			if (current.startsWith('+')) {
				iti.setNumber(current)
			}
		});