const overlay = document.getElementById('wlOverlay');

    const modal = document.getElementById('wlModal');

    const tEl = document.getElementById('wlTitle');

    const mEl = document.getElementById('wlMeta');

    const cBtn = document.getElementById('wlClose');

    const email = document.getElementById('wlEmail');



    function openModal(title, meta) {

        tEl.textContent = title;

        mEl.textContent = meta;

        overlay.classList.remove('hidden');

        modal.classList.remove('hidden');

        document.body.style.overflow = 'hidden';

        setTimeout(() => email.focus(), 50);

    }

    function closeModal() {

        overlay.classList.add('hidden');

        modal.classList.add('hidden');

        document.body.style.overflow = '';

    }

    overlay.addEventListener('click', closeModal);

    cBtn.addEventListener('click', closeModal);

    window.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });



    // Attach to existing hearts (no markup changes)

    document.querySelectorAll('.wishlist-heart').forEach(svg => {

        svg.closest('div').classList.add('wishlist-heart'); // for cursor/focus style

        svg.addEventListener('click', () => {

            const card = svg.closest('.w-\\[180px\\]');

            // title from the text block under the image

            const titleDiv = card.parentElement.querySelector('div[style*="font-weight:600"]');

            const title = titleDiv ? titleDiv.innerText.replace(/\s+\n/g, ' ').trim() : 'Selected trip';

            // meta from “X days” -> nights = days-1

            const daysSpan = card.querySelector('.absolute.inset-x-0 span.text-\\[14px\\]');

            let meta = '5 days • 4 nights';

            if (daysSpan) {

                const d = parseInt(daysSpan.textContent) || 5;

                meta = `${d} days • ${Math.max(d-1,1)} nights`;

            }

            openModal(title, meta);

        });

        svg.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                svg.click();
            }
        });

    });



    document.getElementById('wlForm').addEventListener('submit', e => {

        e.preventDefault();

        closeModal();

        alert('Saved to wishlist!');

    });