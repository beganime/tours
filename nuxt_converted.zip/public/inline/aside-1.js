const toggleButton = document.getElementById('toggleButton');
    const articlesList = document.getElementById('articlesList');
    const arrowIcon = document.getElementById('arrowIcon');

    toggleButton.addEventListener('click', () => {
        if (articlesList.classList.contains('max-h-0')) {
            articlesList.classList.remove('max-h-0');
            articlesList.classList.add('max-h-96');
            arrowIcon.classList.add('rotate-180');
        } else {
            articlesList.classList.add('max-h-0');
            articlesList.classList.remove('max-h-96');
            arrowIcon.classList.remove('rotate-180');
        }
    });