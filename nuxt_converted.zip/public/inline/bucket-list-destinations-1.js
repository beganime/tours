const track = document.getElementById('track');
    const prev = document.getElementById('prev');
    const next = document.getElementById('next');
    const dotsWrap = document.getElementById('dots');

    /* ---------- ДАННЫЕ СЛАЙДОВ (редактируй тут) ---------- */
    const slides = [{
            img: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?q=80&w=1200&auto=format&fit=crop",
            alt: "New York 360",
            title: "New York 360°:<br> discovering Manhattan, Brooklyn and Harlem",
            rating: "4.7",
            from: "$ 1,033",
            old: "$ 1,160",
            discount: "-11%",
            chip: "Top seller",
            trip: "New York 360°: discovering Manhattan, Brooklyn and Harlem",
            days: "8 days • 7 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1505764706515-aa95265c5abc?q=80&w=1200&auto=format&fit=crop",
            alt: "Cuba 360",
            title: "Cuba 360°: from<br> Havana to Trinidad",
            rating: "4.7",
            from: "$ 1,335",
            chip: "Top seller",
            trip: "Cuba 360°: from Havana to Trinidad",
            days: "9 days • 8 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?q=80&w=1200&auto=format&fit=crop",
            alt: "Sweden",
            title: "Sweden: Northern<br> Lights and Lapland",
            rating: "4.8",
            from: "$ 1,532",
            old: "$ 1,800",
            discount: "-14%",
            trip: "Sweden: Northern Lights and Lapland",
            days: "7 days • 6 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1521295121783-8a321d551ad2?q=80&w=1200&auto=format&fit=crop",
            alt: "Nepal 360",
            title: "Nepal 360°: the temples of Kathmandu and the peaks of Annapurna",
            rating: "4.8",
            from: "$ 893",
            old: "$ 986",
            discount: "-9%",
            trip: "Nepal 360°: the temples of Kathmandu and the peaks of Annapurna",
            days: "8 days • 7 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1504384308090-c894fdcc538d?q=80&w=1200&auto=format&fit=crop",
            alt: "Iceland",
            title: "Iceland: Hunting the<br> Northern Lights",
            rating: "4.8",
            from: "$ 1,532",
            old: "$ 1,800",
            discount: "-14%",
            chip: "Top seller",
            trip: "Iceland: Hunting the Northern Lights",
            days: "8 days • 7 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1549890762-0a3f8933bcf7?q=80&w=1200&auto=format&fit=crop",
            alt: "Cuba street",
            title: "Havana streets photo walk",
            rating: "4.8",
            from: "$ 980",
            chip: "Top seller",
            trip: "Havana streets photo walk",
            days: "5 days • 4 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1526481280698-8fcc13fd0f3b?q=80&w=1200&auto=format&fit=crop",
            alt: "Peru",
            title: "Peru on the road",
            rating: "4.8",
            from: "$ 1,890",
            trip: "Peru on the road",
            days: "10 days • 9 nights"
        },
        {
            img: "    https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=1600&auto=format&fit=crop",
            alt: "Morocco",
            title: "Morocco Desert &amp; Atlas",
            rating: "4.8",
            from: "$ 1,290",
            contain: true,
            chip: "Top seller",
            trip: "Morocco Desert & Atlas",
            days: "8 days • 7 nights"
        }
    ];

    /* ---------- РЕНДЕР МАРКУПА ИЗ ДАННЫХ ---------- */
    const esc = s => String(s)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

    function slideItem(s) {
        const imgClass = s.contain ? 'object-contain bg-gray-100' : 'object-cover';
        const rating = s.rating ?
            `<div class="flex items-center gap-2 mb-2">
           <div class="rating-stars">
             <div class="star"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z"/></svg></div>
             <div class="star"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z"/></svg></div>
             <div class="star"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z"/></svg></div>
             <div class="star"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z"/></svg></div>
             <div class="star"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87-.69 6.9L12 18.5l-4.31 2.6-.69-6.9-5-4.87L9 8.26 12 2z"/></svg></div>
           </div>
           <span class="text-xs font-bold">${esc(s.rating)}</span>
         </div>` : '';
        const chip = s.chip ? `<span class="absolute left-3 top-3 chip">${esc(s.chip)}</span>` : '';
        const price = (s.old && s.discount) ?
            `<span class="opacity-90">From <span class="font-bold">${esc(s.from)}</span> <span class="line-through opacity-70">${esc(s.old)}</span></span>
         <span class="price-pill">${esc(s.discount)}</span>` :
            `<span class="opacity-90">From <span class="font-bold">${esc(s.from)}</span>${s.old?` <span class="line-through opacity-70">${esc(s.old)}</span>`:''}</span>`;

        return `
      <li class="shrink-0 w-[calc(100vw-2rem)] sm:w-[330px] lg:w-[340px]">
        <article class="relative rounded-2xl overflow-hidden">
          <img src="${esc(s.img)}" alt="${esc(s.alt||'')}" class="w-full h-[370px] ${imgClass}" />
          <div class="card-grad"></div>
          <button class="absolute top-3 right-3 heart cursor-pointer"
                  aria-label="Save to wishlist"
                  data-trip="${esc(s.trip || s.title)}"
                  data-days="${esc(s.days || '')}">
            <svg viewBox="0 0 24 24"><path d="M12.1 20.3 12 20.4l-.1-.1C7.14 16.24 4 13.39 4 10.25 4 8.1 5.6 6.5 7.75 6.5c1.3 0 2.56.6 3.25 1.54A4.16 4.16 0 0 1 14.25 6.5C16.4 6.5 18 8.1 18 10.25c0 3.14-3.14 5.99-5.9 10.05Z"/></svg>
          </button>
          ${chip}
          <div class="absolute left-3 right-3 bottom-3 text-white">
            ${rating}
            <h3 class="text-[21px] font-extrabold leading-tight">${s.title}</h3>
            <div class="mt-2 flex items-center gap-3 text-[13px]">${price}</div>
          </div>
        </article>
      </li>`;
    }

    function renderSlidesFromData() {
        track.innerHTML = slides.map(slideItem).join('');
    }

    /* ---------- СЛАЙДЕР-ЛОГИКА (как было у тебя) ---------- */
    let page = 0,
        pages = 1,
        gap = 24;

    function cardW() {
        const first = track.children[0];
        if (!first) return 0;
        return first.getBoundingClientRect().width;
    }

    function viewportW() { return track.parentElement.getBoundingClientRect().width; }

    function compute() {
        const cW = cardW();
        const vW = viewportW();
        const perView = Math.max(1, Math.floor((vW + gap) / (cW + gap)));
        const total = track.children.length;
        pages = Math.max(1, total - perView + 1);
        page = ((page % pages) + pages) % pages;
        renderDots();
        move(false);
    }

    function offsetForPage(p) { return -((cardW() + gap) * p); }

    function move(animate = true) {
        track.style.transition = animate ? 'transform 380ms ease' : 'none';
        track.style.transform = `translateX(${offsetForPage(page)}px)`;
        highlightDot();
    }

    function nextPage() {
        page = (page + 1) % pages;
        move();
    }

    function prevPage() {
        page = (page - 1 + pages) % pages;
        move();
    }

    function renderDots() {
        dotsWrap.innerHTML = '';
        for (let i = 0; i < pages; i++) {
            const b = document.createElement('button');
            b.className = 'dot' + (i === page ? ' dot-active' : '');
            b.setAttribute('aria-label', `Go to page ${i + 1}`);
            b.addEventListener('click', () => {
                page = i;
                move();
            });
            dotsWrap.appendChild(b);
        }
    }

    function highlightDot() {
        [...dotsWrap.children].forEach((d, i) => d.classList.toggle('dot-active', i === page));
    }

    prev.addEventListener('click', prevPage);
    next.addEventListener('click', nextPage);
    window.addEventListener('resize', compute);

    /* ---------- РЕНДЕР СЛАЙДОВ И СТАРТ ---------- */
    renderSlidesFromData();
    compute();

    /* ---------- Связываем сердечки с модалкой ---------- */
    const modal = document.getElementById('modal');
    const closeModal = document.getElementById('closeModal');
    const tripName = document.getElementById('tripName');
    const tripDays = document.getElementById('tripDays');
    const email = document.getElementById('email');

    function bindHeartHandlers() {
        document.querySelectorAll('.heart').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                tripName.textContent = btn.dataset.trip || 'Trip';
                tripDays.textContent = btn.dataset.days || '';
                modal.classList.remove('hidden');
                setTimeout(() => email && email.focus(), 50);
            });
        });
    }
    bindHeartHandlers();

    closeModal.addEventListener('click', () => modal.classList.add('hidden'));
    modal.addEventListener('click', (e) => { if (e.target === modal) modal.classList.add('hidden'); });
    document.getElementById('submitWish').addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    /* ---------- Swipe ---------- */
    let startX = 0,
        deltaX = 0,
        isTouching = false;
    const threshold = 50;
    track.addEventListener('touchstart', (e) => {
        isTouching = true;
        startX = e.touches[0].clientX;
        deltaX = 0;
        track.style.transition = 'none';
    }, { passive: true });
    track.addEventListener('touchmove', (e) => {
        if (!isTouching) return;
        deltaX = e.touches[0].clientX - startX;
        track.style.transform = `translateX(${offsetForPage(page) + deltaX}px)`;
    }, { passive: true });
    track.addEventListener('touchend', () => {
        if (!isTouching) return;
        isTouching = false;
        if (Math.abs(deltaX) > threshold) {
            if (deltaX < 0) nextPage();
            else prevPage();
        } else move();
    });