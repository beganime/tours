tailwind.config = {
			theme: {
				extend: {
					colors: {
						page: '#f7f8fa',
						card: '#ffffff',
						border: '#e5e7eb',
						text: '#111827',
						subtext: '#6b7280',
						toggle: '#e5e7eb',
					},
					borderRadius: {
						card: '12px',
					},
					boxShadow: {
						smooth: '0 1px 2px rgba(0,0,0,0.05)',
					}
				}
			}
		}