lucide.createIcons()

	const btn = document.getElementById('typesBtn')
	const menu = document.getElementById('typesMenu')
	const summary = document.getElementById('typesSummary')
	const checkboxes = Array.from(document.querySelectorAll('.typesOpt'))
	const LIMIT = 3

	// начальное состояние
	function renderSummary() {
		const selected = checkboxes.filter(c => c.checked).map(c => c.value)
		if (selected.length === 0) {
			summary.textContent = 'Select…'
			summary.classList.remove('text-indigo-600')
			summary.classList.add('text-gray-400')
		} else {
			summary.textContent = selected.join(', ')
			summary.classList.add('text-indigo-600')
			summary.classList.remove('text-gray-400')
		}

		// лимит 3: блокируем остальные
		const over = selected.length >= LIMIT
		checkboxes.forEach(cb => {
			if (!cb.checked) {
				cb.disabled = over
				cb.classList.toggle('opacity-40', over)
				cb.parentElement.classList.toggle('cursor-not-allowed', over)
			} else {
				cb.disabled = false
				cb.classList.remove('opacity-40')
				cb.parentElement.classList.remove('cursor-not-allowed')
			}
		})
	}
	renderSummary()

	// открыть/закрыть
	btn.addEventListener('click', () => menu.classList.toggle('hidden'))

	// клики по чекбоксам
	checkboxes.forEach(cb => cb.addEventListener('change', renderSummary))

	// закрывать при клике вне
	document.addEventListener('click', (e) => {
		if (!btn.contains(e.target) && !menu.contains(e.target)) {
			menu.classList.add('hidden')
		}
	})

	// закрывать по Esc
	document.addEventListener('keydown', (e) => {
		if (e.key === 'Escape') menu.classList.add('hidden')
	});