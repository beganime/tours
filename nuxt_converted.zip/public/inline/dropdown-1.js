tailwind.config = {
			theme: {
				extend: {
					colors: {
						page: '#f7f8fa',
						card: '#ffffff',
						border: '#e5e7eb',
						text: '#111827',
						sub: '#6b7280',
						fieldBg: '#f3f4f6',
						toggle: '#e5e7eb'
					},
					borderRadius: { card: '12px' },
					boxShadow: {
						smooth: '0 1px 2px rgba(0,0,0,0.05)',
						dropdown: '0 10px 30px rgba(0,0,0,0.08)'
					}
				}
			}
		}