// иконки
		lucide.createIcons()

		// === MAIN TYPE (radio) ===
		const mainBtn = document.getElementById('mainTypeBtn')
		const mainMenu = document.getElementById('mainTypeMenu')
		const mainSummary = document.getElementById('mainTypeSummary')
		const mainRadios = Array.from(document.querySelectorAll('.mainTypeOpt'))
		const mainRadioDots = Array.from(document.querySelectorAll('.mainTypeRadio'))

		function renderMainSummary() {
			const checked = mainRadios.find(r => r.checked)
			if (!checked) {
				mainSummary.textContent = 'Select…'
				mainSummary.classList.add('text-gray-400')
				mainSummary.classList.remove('text-indigo-600')
			} else {
				mainSummary.textContent = checked.value
				mainSummary.classList.remove('text-gray-400')
				mainSummary.classList.add('text-indigo-600')
			}
			// стилизуем кружки (радио-дот)
			mainRadios.forEach((r, idx) => {
				const dot = mainRadioDots[idx]
				dot.classList.toggle('border-indigo-500', r.checked)
				dot.classList.toggle('ring-2', r.checked)
				dot.classList.toggle('ring-indigo-100', r.checked)
				dot.innerHTML = r.checked ? '<span class="block w-2 h-2 rounded-full bg-indigo-600"></span>' : ''
			})
		}
		renderMainSummary()

		mainBtn.addEventListener('click', () => mainMenu.classList.toggle('hidden'))
		mainRadios.forEach(r => r.addEventListener('change', () => {
			renderMainSummary()
			// закрываем после выбора (как обычно в single-select)
			mainMenu.classList.add('hidden')
		}))

		// === ADDITIONAL TYPES (multi, max 3) ===
		const btn = document.getElementById('typesBtn')
		const menu = document.getElementById('typesMenu')
		const summary = document.getElementById('typesSummary')
		const checkboxes = Array.from(document.querySelectorAll('.typesOpt'))
		const LIMIT = 3

		function renderSummary() {
			const selected = checkboxes.filter(c => c.checked).map(c => c.value)
			if (selected.length === 0) {
				summary.textContent = 'Select…'
				summary.classList.remove('text-indigo-600')
				summary.classList.add('text-gray-400')
			} else {
				summary.textContent = selected.join(', ')
				summary.classList.add('text-indigo-600')
				summary.classList.remove('text-gray-400')
			}
			const lock = selected.length >= LIMIT
			checkboxes.forEach(cb => {
				if (!cb.checked) {
					cb.disabled = lock
					cb.parentElement.classList.toggle('opacity-40', lock)
					cb.parentElement.classList.toggle('cursor-not-allowed', lock)
				} else {
					cb.disabled = false
					cb.parentElement.classList.remove('opacity-40', 'cursor-not-allowed')
				}
			})
		}
		renderSummary()

		btn.addEventListener('click', () => menu.classList.toggle('hidden'))
		checkboxes.forEach(cb => cb.addEventListener('change', renderSummary))

		// Закрытие меню при кликах вне и по Esc
		document.addEventListener('click', (e) => {
			if (!btn.contains(e.target) && !menu.contains(e.target)) menu.classList.add('hidden')
			if (!mainBtn.contains(e.target) && !mainMenu.contains(e.target)) mainMenu.classList.add('hidden')
		})
		document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { menu.classList.add('hidden'); mainMenu.classList.add('hidden') } });