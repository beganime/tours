tailwind.config = {
			theme: {
				extend: {
					colors: {
						ytPurple: '#6C2BD9',   /* фиолетовый заголовков */
						ytLime: '#B2D235',     /* зелёный в логотипе */
					},
				},
			},
		}