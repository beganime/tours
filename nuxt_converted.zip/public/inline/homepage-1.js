const rating = 4.7; // ← Измени это число (например 4.3, 4.5, 4.9)
    const totalStars = 5;
    const starsContainer = document.getElementById('stars');

    const starSVG = color => `
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="w-3.5 h-3.5">
        <path fill="${color}" d="M12 .587l3.668 7.431 8.2 1.193-5.934 5.784 1.402 8.175L12 18.896l-7.336 3.864 1.402-8.175L.132 9.211l8.2-1.193z"/>
      </svg>
    `;

    for (let i = 1; i <= totalStars; i++) {
        const wrapper = document.createElement('div');
        wrapper.className = "relative w-5 h-5 rounded-sm bg-[#00B67A] flex items-center justify-center overflow-hidden";

        if (i <= Math.floor(rating)) {
            wrapper.innerHTML = starSVG("white");
        } else if (i === Math.floor(rating) + 1 && rating % 1 !== 0) {
            const fillPercent = Math.round((rating % 1) * 100);
            wrapper.innerHTML = `
          <div class="absolute inset-0 overflow-hidden" style="clip-path: inset(0 ${100 - fillPercent}% 0 0); background-color:#00B67A;">
            <div class="flex items-center justify-center w-full h-full">${starSVG("white")}</div>
          </div>
          <div class="absolute inset-0 overflow-hidden" style="clip-path: inset(0 0 0 ${fillPercent}%); background-color:#E5E7EB;">
            <div class="flex items-center justify-center w-full h-full">${starSVG("white")}</div>
          </div>
        `;
        } else {
            wrapper.classList.add("bg-gray-200");
            wrapper.innerHTML = starSVG("white");
        }

        starsContainer.appendChild(wrapper);
    }

    document.getElementById('ratingText').textContent = rating.toFixed(1);