// Простая утилита для выпадающих меню и фильтрации
    (function() {
        const state = {
            team: 'all',
            location: 'all'
        };

        // Открытие/закрытие
        document.querySelectorAll('[data-dropdown]').forEach(box => {
            const key = box.getAttribute('data-dropdown');
            const btn = box.querySelector(`[data-btn="${key}"]`);
            const menu = box.querySelector(`[data-menu="${key}"]`);

            btn.addEventListener('click', e => {
                e.stopPropagation();
                closeAll();
                menu.classList.toggle('hidden');
            });

            // выбор значения
            menu.querySelectorAll('a').forEach(a => {
                a.addEventListener('click', e => {
                    e.preventDefault();
                    const val = a.getAttribute('data-value');
                    btn.querySelector('span').textContent = val === 'all' ?
                        (key === 'teams' ? 'All Teams' : 'All locations') :
                        val;
                    state[key === 'teams' ? 'team' : 'location'] = val;
                    menu.classList.add('hidden');
                    applyFilters();
                });
            });
        });

        function closeAll() {
            document.querySelectorAll('.menu').forEach(m => m.classList.add('hidden'));
        }
        window.addEventListener('click', closeAll);
        window.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeAll(); });

        function applyFilters() {
            const rows = document.querySelectorAll('#jobs .job');
            rows.forEach(r => {
                const t = r.getAttribute('data-team');
                const l = r.getAttribute('data-location');
                const okTeam = state.team === 'all' || state.team === t;
                const okLoc = state.location === 'all' || state.location === l;
                r.style.display = (okTeam && okLoc) ? '' : 'none';
            });
        }
    })();