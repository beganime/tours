/* ============ License type dropdown (бОльшие чекбоксы) ============ */
		const wrap = document.getElementById('licenseWrap')
		const btn = document.getElementById('licenseBtn')
		const menu = document.getElementById('licenseMenu')
		const text = document.getElementById('licenseText')
		const apply = document.getElementById('licenseApply')
		const clear = document.getElementById('licenseClear')

		function openMenu() { menu.classList.remove('hidden'); btn.setAttribute('aria-expanded', 'true') }
		function closeMenu() { menu.classList.add('hidden'); btn.setAttribute('aria-expanded', 'false') }
		function updateText() {
			const checked = [...document.querySelectorAll('.licenseOpt:checked')].map(i => i.value)
			if (!checked.length) { text.textContent = 'License type'; text.classList.add('text-gray-500') }
			else if (checked.length <= 2) { text.textContent = checked.join(', '); text.classList.remove('text-gray-500') }
			else { text.textContent = `${checked[0]}, ${checked[1]} +${checked.length - 2}`; text.classList.remove('text-gray-500') }
		}
		btn.addEventListener('click', e => { e.stopPropagation(); menu.classList.contains('hidden') ? openMenu() : closeMenu() })
		apply.addEventListener('click', e => { e.stopPropagation(); updateText(); closeMenu() })
		clear.addEventListener('click', e => { e.stopPropagation(); document.querySelectorAll('.licenseOpt').forEach(i => i.checked = false); updateText() })
		document.addEventListener('click', e => { if (!wrap.contains(e.target)) closeMenu() })
		document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu() })
		updateText()

		/* ============ Upload files (chips like on screenshot) ============ */
		const allowed = ['image/png', 'image/jpeg', 'image/webp', 'application/pdf']
		const maxSize = 10 * 1024 * 1024 // 10MB
		const fileInput = document.getElementById('fileInput')
		const uploadBtn = document.getElementById('uploadBtn')
		const fileList = document.getElementById('fileList')
		const fileError = document.getElementById('fileError')

		// внутреннее «хранилище» выбранных файлов (File объекты)
		let store = [] // [{id:number, file:File}]

		uploadBtn.addEventListener('click', () => fileInput.click())

		fileInput.addEventListener('change', (e) => {
			fileError.classList.add('hidden'); fileError.textContent = ''
			const files = Array.from(e.target.files || [])
			files.forEach(f => {
				if (!allowed.includes(f.type)) {
					fileError.textContent = 'Unsupported file type. Allowed: PNG, JPG, JPEG, WEBP, PDF'
					fileError.classList.remove('hidden')
					return
				}
				if (f.size > maxSize) {
					fileError.textContent = 'File is too large. Max size is 10 MB.'
					fileError.classList.remove('hidden')
					return
				}
				store.push({ id: Date.now() + Math.random(), file: f })
			})
			fileInput.value = '' // сброс, чтобы можно было выбрать те же файлы снова
			renderFiles()
		})

		function renderFiles() {
			fileList.innerHTML = ''
			if (!store.length) return
			store.forEach(item => {
				const f = item.file
				const chip = document.createElement('div')
				chip.className = 'flex items-center justify-between rounded-xl border border-gray-200 bg-white px-3 py-2 shadow-sm max-w-md'

				const left = document.createElement('div')
				left.className = 'flex items-center gap-2'
				const iconWrap = document.createElement('span')
				iconWrap.className = 'inline-flex items-center justify-center w-7 h-7 rounded-full bg-gray-100'
				const icon = document.createElement('iconify-icon')
				icon.setAttribute('icon', f.type === 'application/pdf' ? 'mdi:file-pdf-box' : 'mdi:file-image-outline')
				icon.setAttribute('width', '18')
				icon.className = f.type === 'application/pdf' ? 'text-red-500' : 'text-gray-500'
				iconWrap.appendChild(icon)

				const meta = document.createElement('div')
				meta.className = 'text-xs'
				const name = document.createElement('div')
				name.className = 'text-gray-800 truncate max-w-[200px]'
				name.textContent = f.name
				const size = document.createElement('div')
				size.className = 'text-gray-500'
				size.textContent = humanSize(f.size)
				meta.appendChild(name); meta.appendChild(size)

				left.appendChild(iconWrap); left.appendChild(meta)

				const del = document.createElement('button')
				del.className = 'ml-3 inline-flex w-7 h-7 items-center justify-center rounded-full hover:bg-gray-100'
				del.innerHTML = '<iconify-icon icon="mdi:close" width="18"></iconify-icon>'
				del.addEventListener('click', () => {
					store = store.filter(x => x.id !== item.id)
					renderFiles()
				})

				chip.appendChild(left); chip.appendChild(del)
				fileList.appendChild(chip)
			})
		}

		function humanSize(bytes) {
			if (bytes < 1024) return bytes + ' B'
			const kb = bytes / 1024
			if (kb < 1024) return kb.toFixed(2) + ' KB'
			const mb = kb / 1024
			return mb.toFixed(2) + ' MB'
		}