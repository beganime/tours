// SMS functional switch (knob + spring)
		const smsInput = document.getElementById('smsInput')
		const smsTrack = document.getElementById('smsTrack')
		const smsKnob = document.getElementById('smsKnob')

		function renderSms() {
			const on = smsInput.checked
			smsTrack.classList.toggle('bg-[#abc323]', on)
			smsTrack.classList.toggle('bg-gray-300', !on)
			smsKnob.style.transform = on ? 'translateX(1.5rem)' : 'translateX(0)'
		}
		smsTrack.addEventListener('click', () => { smsInput.checked = !smsInput.checked; renderSms() })
		smsTrack.addEventListener('keydown', e => {
			if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); smsInput.checked = !smsInput.checked; renderSms() }
		})
		smsTrack.tabIndex = 0; renderSms()

		// Modal open/close with bottom-up animation
		const modal = document.getElementById('modal')
		const panel = document.getElementById('panel')
		const backdrop = document.getElementById('backdrop')
		const openBtn = document.getElementById('openModal')
		const closeBtn = document.getElementById('closeModal')

		function openModal() {
			modal.classList.remove('hidden')
			// start state
			backdrop.classList.remove('opacity-100'); backdrop.classList.add('opacity-0')
			panel.classList.add('opacity-0', 'translate-y-10')
			// animate to visible
			requestAnimationFrame(() => {
				backdrop.classList.remove('opacity-0'); backdrop.classList.add('opacity-100')
				panel.classList.remove('translate-y-10', 'opacity-0')
				panel.classList.add('opacity-100', 'translate-y-0')
			})
		}
		function closeModal() {
			backdrop.classList.remove('opacity-100'); backdrop.classList.add('opacity-0')
			panel.classList.remove('opacity-100'); panel.classList.add('opacity-0', 'translate-y-10')
			setTimeout(() => modal.classList.add('hidden'), 300)
		}
		openBtn.addEventListener('click', openModal)
		closeBtn.addEventListener('click', closeModal)
		backdrop.addEventListener('click', closeModal)
		// Esc to close
		document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeModal() });