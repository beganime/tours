document.addEventListener('DOMContentLoaded', function () {
			// Получаем кнопки и инпуты для пароля
			const toggleNewPassword = document.getElementById('toggle-new-password')
			const toggleConfirmPassword = document.getElementById('toggle-confirm-password')
			const newPasswordInput = document.getElementById('new-password')
			const confirmPasswordInput = document.getElementById('confirm-password')

			// Обработчик для нового пароля
			toggleNewPassword.addEventListener('click', function () {
				togglePasswordVisibility(newPasswordInput, this.querySelector('i'))
			})

			// Обработчик для подтверждения пароля
			toggleConfirmPassword.addEventListener('click', function () {
				togglePasswordVisibility(confirmPasswordInput, this.querySelector('i'))
			})

			// Функция для переключения видимости пароля
			function togglePasswordVisibility(input, icon) {
				if (input.type === 'password') {
					input.type = 'text' // Показываем пароль
					icon.classList.remove('fa-eye')
					icon.classList.add('fa-eye-slash') // Меняем иконку на перечеркнутый глаз
				} else {
					input.type = 'password' // Скрываем пароль
					icon.classList.remove('fa-eye-slash')
					icon.classList.add('fa-eye') // Меняем иконку обратно на глаз
				}
			}
		});