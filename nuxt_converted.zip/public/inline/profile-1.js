const avatarBox = document.getElementById('avatarBox')
		const avatarInput = document.getElementById('avatarInput')
		const avatarImg = document.getElementById('avatarImg')
		avatarBox.onclick = () => avatarInput.click()
		avatarInput.onchange = e => {
			const file = e.target.files[0]
			if (file && file.type.startsWith('image/')) {
				const r = new FileReader()
				r.onload = ev => avatarImg.src = ev.target.result
				r.readAsDataURL(file)
			}
		};