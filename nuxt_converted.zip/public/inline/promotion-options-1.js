const intro = document.getElementById('screen-intro')
		const options = document.getElementById('screen-options')
		const btnOpen = document.getElementById('openOptions')
		const btnBack = document.getElementById('goBack')

		function showOptions() {
			intro.classList.add('opacity-0', '-translate-y-2')
			setTimeout(() => { intro.classList.add('hidden') }, 200)
			options.classList.remove('hidden')
			requestAnimationFrame(() => {
				options.classList.remove('opacity-0', 'translate-y-6')
				options.classList.add('opacity-100', 'translate-y-0')
				window.scrollTo({ top: 0, behavior: 'smooth' })
			})
		}

		function showIntro() {
			options.classList.add('opacity-0', 'translate-y-6')
			setTimeout(() => { options.classList.add('hidden') }, 200)
			intro.classList.remove('hidden')
			requestAnimationFrame(() => {
				intro.classList.remove('opacity-0', '-translate-y-2')
				window.scrollTo({ top: 0, behavior: 'smooth' })
			})
		}

		btnOpen.addEventListener('click', showOptions)
		btnBack.addEventListener('click', showIntro);