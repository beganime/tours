const slider = document.getElementById('slider')
		const dots = document.querySelectorAll('.dot')
		let index = 0
		const totalSlides = 5

		const cities = [
			{ country: 'Spain', city: 'Barcelona' },
			{ country: 'Italy', city: 'Milan' },
			{ country: 'Spain', city: 'Madrid' },
			{ country: 'Italy', city: 'Rome' },
			{ country: 'France', city: 'Marseille' },
			{ country: 'Germany', city: 'Munich' },
			{ country: 'Netherlands', city: 'Amsterdam' },
			{ country: 'Portugal', city: 'Lisbon' },
			{ country: 'Greece', city: 'Athens' },
			{ country: 'Turkey', city: 'Istanbul' },
			{ country: 'Czech Republic', city: 'Prague' },
			{ country: 'Poland', city: 'Warsaw' },
			{ country: 'Hungary', city: 'Budapest' },
			{ country: 'Austria', city: 'Vienna' },
			{ country: 'Switzerland', city: 'Zurich' },
			{ country: 'Croatia', city: 'Dubrovnik' },
			{ country: 'Norway', city: 'Oslo' },
			{ country: 'Sweden', city: 'Stockholm' },
			{ country: 'Denmark', city: 'Copenhagen' },
			{ country: 'Finland', city: 'Helsinki' },
			{ country: 'Iceland', city: 'Reykjavik' },
			{ country: 'UK', city: 'London' },
			{ country: 'Ireland', city: 'Dublin' },
			{ country: 'Belgium', city: 'Brussels' },
			{ country: 'Luxembourg', city: 'Luxembourg' },
			{ country: 'Slovenia', city: 'Ljubljana' },
			{ country: 'Estonia', city: 'Tallinn' },
			{ country: 'Latvia', city: 'Riga' },
			{ country: 'Lithuania', city: 'Vilnius' },
			{ country: 'Malta', city: 'Valletta' },
		]

		function createCard(country, city) {
			return `
        <div class="relative w-full h-52 sm:h-56 md:h-60 lg:h-64 rounded-xl overflow-hidden shadow-md">
          <img src="https://via.placeholder.com/400x300?text=${city}" class="absolute inset-0 w-full h-full object-cover" alt="${city}">
          <div class="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3 text-left">
            <p class="text-white text-sm md:text-base font-medium">${country}</p>
            <h3 class="text-white text-lg md:text-xl font-semibold">${city}</h3>
          </div>
        </div>`
		}

		function populateSlides() {
			const slides = document.querySelectorAll('.slide')
			let cityIndex = 0
			slides.forEach(slide => {
				for (let i = 0; i < 6; i++) {
					if (cityIndex < cities.length) {
						slide.innerHTML += createCard(cities[cityIndex].country, cities[cityIndex].city)
						cityIndex++
					}
				}
			})
		}

		populateSlides()

		function updateSlider() {
			slider.style.transform = `translateX(-${index * 100}%)`
			dots.forEach((dot, i) => dot.classList.toggle('active', i === index))
		}

		function moveToSlide(i) {
			index = i
			updateSlider()
		}

		setInterval(() => {
			index = (index + 1) % totalSlides
			updateSlider()
		}, 4500)

		updateSlider();