tailwind.config = {
			theme: {
				extend: {
					colors: { ytPurple: '#6C2BD9' },
				},
			},
		};